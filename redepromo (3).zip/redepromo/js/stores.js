// ==========================================
// LOJAS E RENDERIZAÇÃO
// ==========================================

import { collection, doc, getDoc, onSnapshot, query, where, orderBy } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const db = window.firebaseDb;

const Stores = {
    data: [],
    currentFilter: 'all',
    searchQuery: '',

    init() {
        this.setupRealtimeListener();
    },

    setupRealtimeListener() {
        const q = query(collection(db, 'stores'), orderBy('createdAt', 'desc'));
        
        onSnapshot(q, (snapshot) => {
            this.data = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            }));
            
            this.updateStats();
            this.renderAll();
            this.renderPromoStores();
            this.renderDestaques();
        });
    },

    updateStats() {
        const statStores = document.getElementById('statStores');
        const statProducts = document.getElementById('statProducts');
        const statPromos = document.getElementById('statPromos');
        const heroStats = document.getElementById('heroStats');

        if (statStores) statStores.textContent = this.data.length;
        
        const totalProducts = this.data.reduce((acc, s) => acc + (s.items?.length || 0), 0);
        if (statProducts) statProducts.textContent = totalProducts;

        const totalPromos = this.data.reduce((acc, s) => 
            acc + (s.items?.filter(i => i.promotions?.some(p => p.active)).length || 0), 0);
        if (statPromos) statPromos.textContent = totalPromos;

        if (heroStats) heroStats.textContent = `+${this.data.length} lojas parceiras`;
    },

    getFilteredStores() {
        let filtered = this.data;

        // Filtrar por cidade
        const currentCity = window.Cities?.currentCity;
        if (currentCity) {
            filtered = filtered.filter(s => s.cityId === currentCity);
        }

        // Filtrar por categoria
        if (this.currentFilter !== 'all') {
            filtered = filtered.filter(s => s.category === this.currentFilter);
        }

        // Filtrar por busca
        if (this.searchQuery) {
            const q = this.searchQuery.toLowerCase();
            filtered = filtered.filter(s => 
                s.name.toLowerCase().includes(q) ||
                s.description?.toLowerCase().includes(q)
            );
        }

        return filtered;
    },

    renderAll() {
        const container = document.getElementById('allStoresGrid');
        if (!container) return;

        const stores = this.getFilteredStores();

        if (stores.length === 0) {
            container.innerHTML = `
                <div class="col-span-full text-center py-8 text-gray-500">
                    <i class="fas fa-store text-3xl mb-4"></i>
                    <p>Nenhuma loja encontrada</p>
                    ${window.Cities?.currentCity ? '<p class="text-sm mt-2">Tente selecionar outra cidade</p>' : ''}
                </div>
            `;
            return;
        }

        container.innerHTML = stores.map(store => this.renderStoreCard(store)).join('');
    },

    renderPromoStores() {
        const container = document.getElementById('promoStoresGrid');
        if (!container) return;

        let stores = this.data.filter(s => 
            s.hasPromotion || s.items?.some(i => i.promotions?.some(p => p.active))
        );

        // Filtrar por cidade
        const currentCity = window.Cities?.currentCity;
        if (currentCity) {
            stores = stores.filter(s => s.cityId === currentCity);
        }

        if (stores.length === 0) {
            container.innerHTML = `
                <div class="col-span-full text-center py-8 text-gray-500">
                    <i class="fas fa-store-slash text-3xl mb-4"></i>
                    <p>Nenhuma loja com promoção</p>
                </div>
            `;
            return;
        }

        container.innerHTML = stores.map(store => this.renderStoreCardLarge(store)).join('');
    },

    renderDestaques() {
        const container = document.getElementById('destaquesGrid');
        if (!container) return;

        const produtosEmPromo = [];
        
        this.data.forEach(store => {
            // Filtrar por cidade
            const currentCity = window.Cities?.currentCity;
            if (currentCity && store.cityId !== currentCity) return;

            store.items?.forEach(item => {
                const promosAtivas = item.promotions?.filter(p => p.active) || [];
                if (promosAtivas.length > 0) {
                    produtosEmPromo.push({
                        ...item,
                        storeId: store.id,
                        storeName: store.name,
                        storeLogo: store.logo,
                        promo: promosAtivas[0],
                        deliveryOptions: store.deliveryOptions || { allowDelivery: true, allowPickup: true }
                    });
                }
            });
        });

        document.getElementById('destaquesCount').textContent = `${produtosEmPromo.length} produtos em oferta`;

        if (produtosEmPromo.length === 0) {
            container.innerHTML = `
                <div class="col-span-full text-center py-12 text-gray-500">
                    <i class="fas fa-fire text-4xl mb-4 opacity-50"></i>
                    <p>Nenhuma promoção ativa no momento</p>
                </div>
            `;
            return;
        }

        container.innerHTML = produtosEmPromo.map(product => `
            <div class="glass rounded-2xl overflow-hidden cursor-pointer group hover:ring-2 ring-orange-500 transition-all" 
                 onclick="Stores.openProductDetail('${product.id}', '${product.storeId}')">
                <div class="aspect-square overflow-hidden relative">
                    <img src="${product.image}" class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110">
                    <div class="absolute top-2 left-2 promotion-badge text-white text-xs font-bold px-2 py-1 rounded">
                        ${product.promo.highlight}
                    </div>
                    <div class="absolute bottom-2 right-2 w-8 h-8 rounded-full bg-white/90 flex items-center justify-center">
                        <img src="${product.storeLogo}" class="w-6 h-6 rounded-full">
                    </div>
                    ${product.deliveryOptions.allowDelivery ? '<div class="absolute top-2 right-2 delivery-badge text-white text-[10px] px-1.5 py-0.5 rounded"><i class="fas fa-truck"></i></div>' : ''}
                </div>
                <div class="p-3">
                    <h3 class="font-bold text-sm mb-1 line-clamp-1">${product.name}</h3>
                    <div class="flex items-center gap-2">
                        <span class="text-primary font-bold">R$ ${product.price.toFixed(2)}</span>
                        ${product.oldPrice ? `<span class="text-gray-500 text-xs line-through">R$ ${product.oldPrice.toFixed(2)}</span>` : ''}
                    </div>
                    <p class="text-xs text-gray-400 mt-1">${product.storeName}</p>
                </div>
            </div>
        `).join('');
    },

    renderStoreCard(store) {
        const deliveryOptions = store.deliveryOptions || { allowDelivery: true, allowPickup: true };
        
        return `
            <div class="store-card glass rounded-2xl overflow-hidden cursor-pointer group" onclick="Stores.openModal('${store.id}')">
                <div class="h-40 overflow-hidden relative">
                    <img src="${store.image}" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110">
                    ${store.hasPromotion ? `<div class="absolute top-2 right-2 bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-full animate-pulse">PROMO</div>` : ''}
                    <div class="absolute bottom-2 left-2 flex gap-1">
                        ${deliveryOptions.allowDelivery ? '<span class="delivery-badge text-white text-[10px] px-1.5 py-0.5 rounded"><i class="fas fa-truck"></i></span>' : ''}
                        ${deliveryOptions.allowPickup ? '<span class="pickup-badge text-white text-[10px] px-1.5 py-0.5 rounded"><i class="fas fa-store"></i></span>' : ''}
                    </div>
                </div>
                <div class="p-3">
                    <h3 class="font-bold text-white text-sm mb-1 line-clamp-1">${store.name}</h3>
                    <div class="flex items-center gap-1 text-yellow-400 text-xs mb-2">
                        <i class="fas fa-star"></i> ${store.rating || '5.0'}
                    </div>
                    <p class="text-gray-400 text-sm mb-2 line-clamp-2">${store.description || ''}</p>
                    <div class="flex items-center justify-between text-xs">
                        <span class="text-gray-500 capitalize">${store.category}</span>
                        <span class="text-primary font-medium">${store.items?.length || 0} itens</span>
                    </div>
                </div>
            </div>
        `;
    },

    renderStoreCardLarge(store) {
        const deliveryOptions = store.deliveryOptions || { allowDelivery: true, allowPickup: true };
        
        return `
            <div class="store-card glass rounded-2xl overflow-hidden cursor-pointer group" onclick="Stores.openModal('${store.id}')">
                <div class="h-48 overflow-hidden relative">
                    <img src="${store.image}" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110">
                    <div class="absolute top-3 right-3">
                        <span class="bg-gradient-to-r from-orange-500 to-red-500 text-white text-xs font-bold px-3 py-1 rounded-full animate-pulse">
                            ${store.promotionDiscount || 'PROMO'}
                        </span>
                    </div>
                    ${deliveryOptions.allowDelivery ? `
                        <div class="absolute bottom-3 right-3 delivery-badge text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                            <i class="fas fa-truck"></i> Entrega
                        </div>
                    ` : ''}
                    ${deliveryOptions.allowPickup ? `
                        <div class="absolute bottom-3 left-3 pickup-badge text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                            <i class="fas fa-store"></i> Retirada
                        </div>
                    ` : ''}
                </div>
                <div class="p-4">
                    <div class="flex items-center gap-3 mb-2">
                        <img src="${store.logo}" class="w-10 h-10 rounded-full">
                        <div>
                            <h3 class="font-bold text-lg">${store.name}</h3>
                            <div class="flex items-center gap-1 text-yellow-400 text-xs">
                                <i class="fas fa-star"></i> ${store.rating || '5.0'}
                            </div>
                        </div>
                    </div>
                    <p class="text-gray-400 text-sm mb-3 line-clamp-2">${store.description || ''}</p>
                    <div class="flex items-center justify-between text-xs text-gray-500">
                        <span><i class="fas fa-box mr-1"></i> ${store.items?.length || 0} produtos</span>
                        <span class="capitalize">${store.category}</span>
                    </div>
                </div>
            </div>
        `;
    },

    async openModal(storeId) {
        const store = this.data.find(s => s.id === storeId);
        if (!store) return;

        const modal = document.getElementById('storeModal');
        const content = document.getElementById('storeModalContent');
        const deliveryOptions = store.deliveryOptions || { allowDelivery: true, allowPickup: true };

        content.innerHTML = `
            <div class="relative">
                <div class="h-48 md:h-64 overflow-hidden relative">
                    <img src="${store.banner || store.image}" class="w-full h-full object-cover">
                    <div class="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
                    <button onclick="Stores.closeModal()" class="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/50 hover:bg-black/70 flex items-center justify-center transition-colors">
                        <i class="fas fa-times text-white"></i>
                    </button>
                </div>
                
                <div class="px-6 md:px-8 -mt-16 relative mb-6">
                    <div class="flex flex-col md:flex-row md:items-end gap-4">
                        <img src="${store.logo}" class="w-24 h-24 md:w-32 md:h-32 rounded-2xl border-4 border-gray-800 shadow-2xl">
                        <div class="flex-1">
                            <h2 class="text-3xl font-bold text-white mb-1">${store.name}</h2>
                            <div class="flex items-center gap-4 text-sm text-gray-400">
                                <span class="flex items-center gap-1"><i class="fas fa-star text-yellow-400"></i> ${store.rating || '5.0'}</span>
                                <span class="flex items-center gap-1"><i class="fas fa-box text-primary"></i> ${store.items?.length || 0} produtos</span>
                            </div>
                            <div class="flex gap-2 mt-2">
                                ${deliveryOptions.allowDelivery ? '<span class="delivery-badge text-white text-xs px-2 py-1 rounded-full"><i class="fas fa-truck mr-1"></i>Entrega</span>' : ''}
                                ${deliveryOptions.allowPickup ? '<span class="pickup-badge text-white text-xs px-2 py-1 rounded-full"><i class="fas fa-store mr-1"></i>Retirada</span>' : ''}
                            </div>
                        </div>
                    </div>
                </div>

                <div class="px-6 md:px-8 pb-8">
                    <p class="text-gray-300 mb-6">${store.description || 'Sem descrição'}</p>
                    
                    ${store.hasPromotion ? `
                        <div class="bg-gradient-to-r from-orange-500/20 to-red-500/20 border border-orange-500/30 rounded-2xl p-6 mb-8">
                            <h3 class="text-xl font-bold text-orange-400 mb-1"><i class="fas fa-fire"></i> ${store.promotionTitle || 'Promoção Especial'}</h3>
                            <p class="text-2xl font-bold">${store.promotionDiscount || ''}</p>
                            <p class="text-sm text-gray-400">${store.promotionValid || ''}</p>
                        </div>
                    ` : ''}

                    <h3 class="text-xl font-bold mb-4">Produtos (${store.items?.length || 0})</h3>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        ${store.items?.map(item => {
                            const activePromos = item.promotions?.filter(p => p.active) || [];
                            const discount = item.oldPrice ? Math.round((1 - item.price/item.oldPrice) * 100) : 0;
                            return `
                                <div class="glass rounded-xl overflow-hidden cursor-pointer product-card" onclick="Stores.openProductDetail('${item.id}', '${store.id}')">
                                    <div class="aspect-square overflow-hidden relative">
                                        <img src="${item.image}" class="w-full h-full object-cover">
                                        ${discount > 0 ? `<div class="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">-${discount}%</div>` : ''}
                                        ${activePromos.length > 0 ? `<div class="absolute top-2 right-2 promotion-badge text-white text-xs font-bold px-2 py-1 rounded animate-pulse">${activePromos[0].highlight}</div>` : ''}
                                    </div>
                                    <div class="p-3">
                                        <h4 class="font-medium text-sm text-gray-200 mb-1 line-clamp-1">${item.name}</h4>
                                        <div class="flex items-center gap-2">
                                            <span class="text-primary font-bold">R$ ${item.price.toFixed(2)}</span>
                                            ${item.oldPrice ? `<span class="text-gray-500 text-xs line-through">R$ ${item.oldPrice.toFixed(2)}</span>` : ''}
                                        </div>
                                        <button onclick="event.stopPropagation(); Payment.openCheckout('${item.id}', '${store.id}')" 
                                                class="w-full mt-2 py-2 bg-primary/20 hover:bg-primary/30 text-primary rounded-lg text-sm font-medium transition-colors">
                                            Comprar
                                        </button>
                                    </div>
                                </div>
                            `;
                        }).join('') || '<p class="text-gray-500 col-span-full text-center py-8">Nenhum produto cadastrado</p>'}
                    </div>
                </div>
            </div>
        `;

        modal.classList.remove('hidden');
        setTimeout(() => content.classList.add('show'), 10);
    },

    closeModal() {
        const modal = document.getElementById('storeModal');
        const content = document.getElementById('storeModalContent');
        content.classList.remove('show');
        setTimeout(() => modal.classList.add('hidden'), 300);
    },

    async openProductDetail(productId, storeId) {
        const store = this.data.find(s => s.id === storeId);
        if (!store) return;

        const product = store.items.find(i => i.id === productId);
        if (!product) return;

        const modal = document.getElementById('productDetailModal');
        const content = document.getElementById('productDetailContent');
        const activePromos = product.promotions?.filter(p => p.active) || [];
        const discount = product.oldPrice ? Math.round((1 - product.price/product.oldPrice) * 100) : 0;

        content.innerHTML = `
            <div class="relative">
                <div class="aspect-square overflow-hidden relative">
                    <img src="${product.image}" class="w-full h-full object-cover">
                    <button onclick="Stores.closeProductDetail()" class="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/50 hover:bg-black/70 flex items-center justify-center">
                        <i class="fas fa-times text-white"></i>
                    </button>
                    ${discount > 0 ? `<div class="absolute top-4 left-4 bg-red-500 text-white text-lg font-bold px-3 py-1 rounded">-${discount}%</div>` : ''}
                    ${activePromos.length > 0 ? `<div class="absolute bottom-4 left-4 promotion-badge text-white font-bold px-3 py-1 rounded">${activePromos[0].highlight}</div>` : ''}
                </div>
                
                <div class="p-6">
                    <div class="flex items-center gap-2 mb-2">
                        <img src="${store.logo}" class="w-6 h-6 rounded-full">
                        <span class="text-sm text-gray-400">${store.name}</span>
                    </div>
                    
                    <h2 class="text-2xl font-bold mb-2">${product.name}</h2>
                    
                    <div class="flex items-center gap-3 mb-4">
                        <span class="text-3xl font-bold text-primary">R$ ${product.price.toFixed(2)}</span>
                        ${product.oldPrice ? `<span class="text-xl text-gray-500 line-through">R$ ${product.oldPrice.toFixed(2)}</span>` : ''}
                    </div>

                    <p class="text-gray-300 mb-6">${product.description || 'Sem descrição'}</p>

                    ${product.variations?.length > 0 ? `
                        <div class="mb-4">
                            <h4 class="font-medium mb-2">Variações</h4>
                            ${product.variations.map(v => `
                                <div class="mb-2">
                                    <span class="text-sm text-gray-400">${v.name}:</span>
                                    <div class="flex gap-2 mt-1">
                                        ${v.options.map(o => `
                                            <button class="px-3 py-1 rounded-lg bg-gray-800 text-sm hover:bg-primary/20 hover:text-primary transition-colors">${o}</button>
                                        `).join('')}
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    ` : ''}

                    <div class="flex gap-3">
                        <button onclick="Payment.openCheckout('${product.id}', '${store.id}')" 
                                class="flex-1 py-3 bg-gradient-to-r from-primary to-secondary rounded-xl font-bold text-lg">
                            Comprar Agora
                        </button>
                        <button onclick="Stores.addToCart('${product.id}', '${store.id}')" 
                                class="px-4 py-3 glass rounded-xl hover:bg-white/10">
                            <i class="fas fa-cart-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;

        modal.classList.remove('hidden');
        setTimeout(() => content.classList.add('show'), 10);
    },

    closeProductDetail() {
        const modal = document.getElementById('productDetailModal');
        const content = document.getElementById('productDetailContent');
        content.classList.remove('show');
        setTimeout(() => modal.classList.add('hidden'), 300);
    },

    filter(category) {
        this.currentFilter = category;
        
        // Atualizar botões ativos
        document.querySelectorAll('#stores button').forEach(btn => {
            btn.classList.remove('bg-primary/20', 'text-primary');
            btn.classList.add('glass', 'text-gray-400');
        });
        event.target.classList.remove('glass', 'text-gray-400');
        event.target.classList.add('bg-primary/20', 'text-primary');
        
        this.renderAll();
    },

    search(query) {
        this.searchQuery = query;
        this.renderAll();
    },

    addToCart(productId, storeId) {
        // Implementar carrinho se necessário
        Utils.showToast('Info', 'Adicionado ao carrinho (funcionalidade em desenvolvimento)');
    }
};

window.Stores = Stores;
export default Stores;