// ==========================================
// SISTEMA DE ALUGUEL - COBRANÇA RECORRENTE
// Você cobra mensalidade dos lojistas!
// ==========================================

const Rental = {
    // Criar cobrança de aluguel para um lojista
    async createRentalCharge(storeId, amount, dueDay = 5) {
        const store = Stores.data.find(s => s.id === storeId);
        if (!store) throw new Error('Loja não encontrada');

        // Usar Asaas (melhor para recorrência) ou criar lembrete manual
        if (store.asaas?.apiKey) {
            return this.createAsaasSubscription(storeId, amount);
        } else {
            return this.createManualRentalRecord(storeId, amount, dueDay);
        }
    },

    // Assinatura Asaas (automática!)
    async createAsaasSubscription(storeId, amount) {
        const store = Stores.data.find(s => s.id === storeId);
        
        const config = {
            apiKey: store.asaas.apiKey,
            sandbox: store.asaas.sandbox !== false,
            baseUrl: store.asaas.sandbox !== false 
                ? 'https://sandbox.asaas.com/api/v3'
                : 'https://api.asaas.com/v3'
        };

        // Criar/Obter cliente (você é o cliente que paga o lojista? Não, é o contrário!)
        // Na verdade, o lojista é cliente de VOCÊ
        // Você precisa de uma conta Asaas própria!

        // Simplificando: Registrar cobrança manual
        return this.createManualRentalRecord(storeId, amount);
    },

    // Registro manual de aluguel (quando não tem gateway automático)
    async createManualRentalRecord(storeId, amount, dueDay = 5) {
        const db = window.firebaseDb;
        const { doc, setDoc, serverTimestamp } = await import("https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js");

        const rentalData = {
            id: Utils.generateId(),
            storeId: storeId,
            amount: amount,
            dueDay: dueDay, // Dia do vencimento (ex: todo dia 5)
            status: 'pending', // pending, paid, overdue, cancelled
            month: new Date().toISOString().slice(0, 7), // 2024-01
            description: `Aluguel ${new Date().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}`,
            createdAt: serverTimestamp(),
            paidAt: null,
            paymentMethod: null,
            notes: ''
        };

        await setDoc(doc(db, 'rentals', rentalData.id), rentalData);
        
        // Notificar lojista
        this.notifyStoreOwner(storeId, rentalData);
        
        return rentalData;
    },

    // Verificar aluguéis vencidos
    async checkOverdueRentals() {
        const db = window.firebaseDb;
        const { collection, getDocs, query, where, updateDoc, doc } = await import("https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js");

        const today = new Date();
        const currentMonth = today.toISOString().slice(0, 7);
        
        const q = query(
            collection(db, 'rentals'),
            where('month', '==', currentMonth),
            where('status', '==', 'pending')
        );

        const snapshot = await getDocs(q);
        const overdue = [];

        snapshot.forEach(docSnap => {
            const rental = docSnap.data();
            const dueDate = new Date(today.getFullYear(), today.getMonth(), rental.dueDay);
            
            if (today > dueDate) {
                overdue.push({ id: docSnap.id, ...rental });
                
                // Atualizar status
                updateDoc(doc(db, 'rentals', docSnap.id), {
                    status: 'overdue',
                    updatedAt: serverTimestamp()
                });
            }
        });

        return overdue;
    },

    // Lojista marcar como pago (quando paga fora do sistema)
    async markAsPaid(rentalId, paymentInfo) {
        const db = window.firebaseDb;
        const { updateDoc, doc, serverTimestamp } = await import("https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js");

        await updateDoc(doc(db, 'rentals', rentalId), {
            status: 'paid',
            paidAt: serverTimestamp(),
            paymentMethod: paymentInfo.method || 'manual',
            paymentProof: paymentInfo.proof || null, // URL do comprovante
            notes: paymentInfo.notes || '',
            updatedAt: serverTimestamp()
        });

        Utils.showToast('Sucesso', 'Pagamento registrado! Aguardando confirmação do administrador.');
    },

    // Admin confirmar pagamento
    async confirmPayment(rentalId) {
        if (!Auth.isAdmin()) {
            Utils.showToast('Erro', 'Apenas administradores', 'error');
            return;
        }

        const db = window.firebaseDb;
        const { updateDoc, doc, serverTimestamp } = await import("https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js");

        await updateDoc(doc(db, 'rentals', rentalId), {
            status: 'confirmed',
            confirmedBy: Auth.userData.id,
            confirmedAt: serverTimestamp(),
            updatedAt: serverTimestamp()
        });

        Utils.showToast('Sucesso', 'Pagamento confirmado!');
    },

    // Gerar boleto de aluguel (via Asaas da sua conta)
    async generateRentalBoleto(storeId, amount) {
        // Isso seria feito na SUA conta Asaas (não do lojista)
        // Você precisa ter uma conta Asaas para emitir cobranças
        
        Utils.showToast('Info', 'Emissão de boleto em desenvolvimento');
    },

    // Notificar lojista
    notifyStoreOwner(storeId, rentalData) {
        // Aqui você poderia enviar email, WhatsApp, etc
        console.log(`Notificar loja ${storeId}: Aluguel de R$ ${rentalData.amount} vence dia ${rentalData.dueDay}`);
    },

    // Renderizar painel de aluguel para admin
    renderRentalDashboard(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        // Buscar dados
        this.loadRentalData().then(data => {
            container.innerHTML = `
                <div class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div class="glass rounded-xl p-4 text-center">
                            <div class="text-2xl font-bold text-green-400">${data.paid}</div>
                            <div class="text-sm text-gray-400">Pagos</div>
                        </div>
                        <div class="glass rounded-xl p-4 text-center">
                            <div class="text-2xl font-bold text-yellow-400">${data.pending}</div>
                            <div class="text-sm text-gray-400">Pendentes</div>
                        </div>
                        <div class="glass rounded-xl p-4 text-center">
                            <div class="text-2xl font-bold text-red-400">${data.overdue}</div>
                            <div class="text-sm text-gray-400">Atrasados</div>
                        </div>
                        <div class="glass rounded-xl p-4 text-center">
                            <div class="text-2xl font-bold text-primary">R$ ${data.totalRevenue.toFixed(2)}</div>
                            <div class="text-sm text-gray-400">Receita Prevista</div>
                        </div>
                    </div>

                    <div class="glass rounded-xl p-6">
                        <h3 class="font-bold text-lg mb-4">Cobranças do Mês</h3>
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Loja</th>
                                        <th>Valor</th>
                                        <th>Vencimento</th>
                                        <th>Status</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${data.rentals.map(r => {
                                        const store = Stores.data.find(s => s.id === r.storeId);
                                        const statusClass = {
                                            paid: 'status-paid',
                                            pending: 'status-pending',
                                            overdue: 'status-overdue',
                                            confirmed: 'status-delivered'
                                        }[r.status] || 'status-pending';
                                        
                                        return `
                                            <tr>
                                                <td>${store?.name || 'Loja removida'}</td>
                                                <td>R$ ${r.amount.toFixed(2)}</td>
                                                <td>Dia ${r.dueDay}</td>
                                                <td><span class="px-2 py-1 rounded text-xs ${statusClass}">${r.status}</span></td>
                                                <td>
                                                    ${r.status === 'pending' ? `
                                                        <button onclick="Rental.markAsPaid('${r.id}', {method: 'manual'})" class="text-green-400 hover:text-green-300 mr-2">
                                                            <i class="fas fa-check"></i> Paguei
                                                        </button>
                                                    ` : ''}
                                                    ${Auth.isAdmin() && r.status === 'paid' ? `
                                                        <button onclick="Rental.confirmPayment('${r.id}')" class="text-blue-400 hover:text-blue-300">
                                                            <i class="fas fa-check-double"></i> Confirmar
                                                        </button>
                                                    ` : ''}
                                                </td>
                                            </tr>
                                        `;
                                    }).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;
        });
    },

    async loadRentalData() {
        const db = window.firebaseDb;
        const { collection, getDocs, query, where } = await import("https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js");

        const currentMonth = new Date().toISOString().slice(0, 7);
        const q = query(collection(db, 'rentals'), where('month', '==', currentMonth));
        
        const snapshot = await getDocs(q);
        const rentals = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));

        return {
            rentals,
            paid: rentals.filter(r => r.status === 'paid' || r.status === 'confirmed').length,
            pending: rentals.filter(r => r.status === 'pending').length,
            overdue: rentals.filter(r => r.status === 'overdue').length,
            totalRevenue: rentals.reduce((sum, r) => sum + (r.amount || 0), 0)
        };
    }
};

window.Rental = Rental;
export default Rental;