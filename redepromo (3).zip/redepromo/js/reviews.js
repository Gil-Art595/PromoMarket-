// ==========================================
// SISTEMA DE AVALIAÇÕES E REVIEWS
// ==========================================

import { collection, doc, getDocs, getDoc, setDoc, updateDoc, deleteDoc, query, where, orderBy, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const db = window.firebaseDb;

const Reviews = {
    // Criar nova avaliação
    async create(data) {
        try {
            // Verificar se usuário já avaliou
            const existing = await this.getUserReview(data.storeId, data.productId, data.userId);
            if (existing) {
                Utils.showToast('Erro', 'Você já avaliou este item', 'error');
                return false;
            }

            const reviewData = {
                id: Utils.generateId(),
                storeId: data.storeId,
                productId: data.productId || null,
                orderId: data.orderId,
                userId: data.userId,
                userName: data.userName,
                userAvatar: data.userAvatar,
                rating: data.rating, // 1-5 estrelas
                title: data.title || '',
                comment: data.comment,
                images: data.images || [],
                verifiedPurchase: data.verifiedPurchase || false,
                helpful: 0,
                status: 'pending', // pending, approved, rejected
                reply: null, // Resposta do lojista
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            };

            await setDoc(doc(db, 'reviews', reviewData.id), reviewData);

            // Atualizar média da loja/produto
            await this.updateAverageRating(data.storeId, data.productId);

            Utils.showToast('Sucesso', 'Avaliação enviada! Aguardando aprovação.');
            return reviewData;

        } catch (error) {
            console.error('Erro ao criar avaliação:', error);
            Utils.showToast('Erro', 'Não foi possível enviar avaliação', 'error');
            return false;
        }
    },

    // Responder avaliação (lojista)
    async reply(reviewId, replyText) {
        try {
            const review = await getDoc(doc(db, 'reviews', reviewId));
            if (!review.exists()) {
                Utils.showToast('Erro', 'Avaliação não encontrada', 'error');
                return false;
            }

            // Verificar se é dono da loja
            const reviewData = review.data();
            if (reviewData.storeId !== window.currentUserStore?.id && !Auth.isAdmin()) {
                Utils.showToast('Erro', 'Sem permissão', 'error');
                return false;
            }

            await updateDoc(doc(db, 'reviews', reviewId), {
                reply: {
                    text: replyText,
                    createdAt: serverTimestamp(),
                    updatedAt: serverTimestamp()
                },
                updatedAt: serverTimestamp()
            });

            Utils.showToast('Sucesso', 'Resposta enviada!');
            return true;

        } catch (error) {
            Utils.showToast('Erro', 'Erro ao responder', 'error');
            return false;
        }
    },

    // Aprovar/rejeitar avaliação (admin)
    async moderate(reviewId, status) {
        if (!Auth.isAdmin()) {
            Utils.showToast('Erro', 'Apenas administradores', 'error');
            return false;
        }

        try {
            await updateDoc(doc(db, 'reviews', reviewId), {
                status: status,
                moderatedBy: Auth.userData.id,
                moderatedAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });

            const review = await getDoc(doc(db, 'reviews', reviewId));
            const data = review.data();

            // Se aprovou, atualizar média
            if (status === 'approved') {
                await this.updateAverageRating(data.storeId, data.productId);
            }

            Utils.showToast('Sucesso', `Avaliação ${status === 'approved' ? 'aprovada' : 'rejeitada'}`);
            return true;

        } catch (error) {
            Utils.showToast('Erro', 'Erro ao moderar', 'error');
            return false;
        }
    },

    // Marcar avaliação como útil
    async markHelpful(reviewId) {
        const userId = Auth.userData?.id;
        if (!userId) {
            Utils.showToast('Erro', 'Faça login para marcar como útil', 'error');
            return;
        }

        const helpfulKey = `helpful_${reviewId}_${userId}`;
        const alreadyMarked = localStorage.getItem(helpfulKey);

        if (alreadyMarked) {
            Utils.showToast('Info', 'Você já marcou esta avaliação');
            return;
        }

        try {
            const review = await getDoc(doc(db, 'reviews', reviewId));
            const currentHelpful = review.data().helpful || 0;

            await updateDoc(doc(db, 'reviews', reviewId), {
                helpful: currentHelpful + 1,
                updatedAt: serverTimestamp()
            });

            localStorage.setItem(helpfulKey, 'true');
            Utils.showToast('Sucesso', 'Marcado como útil!');

        } catch (error) {
            Utils.showToast('Erro', 'Erro ao marcar', 'error');
        }
    },

    // Buscar avaliações de uma loja
    async getStoreReviews(storeId, options = {}) {
        const { status = 'approved', limit = 20, lastDoc } = options;

        let q = query(
            collection(db, 'reviews'),
            where('storeId', '==', storeId),
            where('status', '==', status),
            orderBy('createdAt', 'desc')
        );

        if (lastDoc) {
            q = query(q, startAfter(lastDoc), limit(limit));
        }

        const snapshot = await getDocs(q);
        return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
    },

    // Buscar avaliações de um produto
    async getProductReviews(productId, options = {}) {
        const { status = 'approved', limit = 20 } = options;

        const q = query(
            collection(db, 'reviews'),
            where('productId', '==', productId),
            where('status', '==', status),
            orderBy('createdAt', 'desc'),
            limit(limit)
        );

        const snapshot = await getDocs(q);
        return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
    },

    // Verificar se usuário já avaliou
    async getUserReview(storeId, productId, userId) {
        let q;
        
        if (productId) {
            q = query(
                collection(db, 'reviews'),
                where('productId', '==', productId),
                where('userId', '==', userId)
            );
        } else {
            q = query(
                collection(db, 'reviews'),
                where('storeId', '==', storeId),
                where('userId', '==', userId),
                where('productId', '==', null)
            );
        }

        const snapshot = await getDocs(q);
        return snapshot.empty ? null : { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
    },

    // Atualizar média de avaliações
    async updateAverageRating(storeId, productId) {
        // Média da loja
        const storeReviewsQuery = query(
            collection(db, 'reviews'),
            where('storeId', '==', storeId),
            where('status', '==', 'approved')
        );
        
        const storeSnapshot = await getDocs(storeReviewsQuery);
        const storeRatings = storeSnapshot.docs.map(d => d.data().rating);
        const storeAverage = storeRatings.length > 0 
            ? (storeRatings.reduce((a, b) => a + b, 0) / storeRatings.length).toFixed(1)
            : 0;

        await updateDoc(doc(db, 'stores', storeId), {
            rating: parseFloat(storeAverage),
            reviewCount: storeRatings.length,
            updatedAt: serverTimestamp()
        });

        // Média do produto (se aplicável)
        if (productId) {
            const productReviewsQuery = query(
                collection(db, 'reviews'),
                where('productId', '==', productId),
                where('status', '==', 'approved')
            );
            
            const productSnapshot = await getDocs(productReviewsQuery);
            const productRatings = productSnapshot.docs.map(d => d.data().rating);
            const productAverage = productRatings.length > 0
                ? (productRatings.reduce((a, b) => a + b, 0) / productRatings.length).toFixed(1)
                : 0;

            // Atualizar no array de items da loja
            const storeDoc = await getDoc(doc(db, 'stores', storeId));
            const items = storeDoc.data().items || [];
            const itemIndex = items.findIndex(i => i.id === productId);
            
            if (itemIndex !== -1) {
                items[itemIndex].rating = parseFloat(productAverage);
                items[itemIndex].reviewCount = productRatings.length;
                
                await updateDoc(doc(db, 'stores', storeId), {
                    items: items,
                    updatedAt: serverTimestamp()
                });
            }
        }
    },

    // Renderizar estrelas
    renderStars(rating, size = 'md') {
        const sizes = {
            sm: 'text-xs',
            md: 'text-sm',
            lg: 'text-lg',
            xl: 'text-2xl'
        };

        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

        let html = `<div class="flex items-center gap-1 ${sizes[size]}">`;
        
        // Estrelas cheias
        for (let i = 0; i < fullStars; i++) {
            html += '<i class="fas fa-star text-yellow-400"></i>';
        }
        
        // Meia estrela
        if (hasHalfStar) {
            html += '<i class="fas fa-star-half-alt text-yellow-400"></i>';
        }
        
        // Estrelas vazias
        for (let i = 0; i < emptyStars; i++) {
            html += '<i class="far fa-star text-gray-400"></i>';
        }
        
        html += `<span class="ml-2 text-gray-400">${rating.toFixed(1)}</span></div>`;
        
        return html;
    },

    // Renderizar formulário de avaliação
    renderReviewForm(containerId, storeId, productId = null, orderId = null) {
        const container = document.getElementById(containerId);
        if (!container) return;

        // Verificar se já avaliou
        this.getUserReview(storeId, productId, Auth.userData?.id).then(existing => {
            if (existing) {
                container.innerHTML = `
                    <div class="glass rounded-xl p-6 text-center">
                        <i class="fas fa-check-circle text-green-400 text-3xl mb-3"></i>
                        <p class="text-gray-300">Você já avaliou este item!</p>
                        <div class="mt-3">${this.renderStars(existing.rating)}</div>
                        <p class="text-sm text-gray-400 mt-2">"${existing.comment}"</p>
                    </div>
                `;
                return;
            }

            container.innerHTML = `
                <div class="glass rounded-xl p-6">
                    <h3 class="font-bold text-lg mb-4">Avaliar ${productId ? 'Produto' : 'Loja'}</h3>
                    <form onsubmit="Reviews.handleSubmit(event, '${storeId}', '${productId}', '${orderId}')" class="space-y-4">
                        <div>
                            <label class="form-label">Sua avaliação</label>
                            <div class="flex gap-2 text-2xl" id="starRating">
                                ${[1,2,3,4,5].map(i => `
                                    <button type="button" onclick="Reviews.setRating(${i})" 
                                            class="star-btn text-gray-400 hover:text-yellow-400 transition-colors"
                                            data-rating="${i}">
                                        <i class="far fa-star"></i>
                                    </button>
                                `).join('')}
                            </div>
                            <input type="hidden" id="reviewRating" required>
                        </div>
                        
                        <div>
                            <label class="form-label">Título (opcional)</label>
                            <input type="text" id="reviewTitle" class="input-field w-full rounded-xl px-4 py-3" 
                                   placeholder="Ex: Excelente atendimento!">
                        </div>
                        
                        <div>
                            <label class="form-label">Comentário *</label>
                            <textarea id="reviewComment" required rows="4" class="input-field w-full rounded-xl px-4 py-3 resize-none"
                                      placeholder="Conte sua experiência..."></textarea>
                        </div>
                        
                        <div>
                            <label class="form-label">Fotos (opcional)</label>
                            <input type="file" id="reviewImages" multiple accept="image/*" class="hidden" onchange="Reviews.previewImages(this)">
                            <label for="reviewImages" class="cursor-pointer block p-4 border-2 border-dashed border-gray-600 rounded-xl text-center hover:border-primary transition-colors">
                                <i class="fas fa-camera text-2xl mb-2"></i>
                                <p class="text-sm text-gray-400">Clique para adicionar fotos</p>
                            </label>
                            <div id="reviewImagePreview" class="flex gap-2 mt-2 flex-wrap"></div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-full">
                            <i class="fas fa-paper-plane mr-2"></i> Enviar Avaliação
                        </button>
                    </form>
                </div>
            `;
        });
    },

    currentRating: 0,

    setRating(rating) {
        this.currentRating = rating;
        document.getElementById('reviewRating').value = rating;
        
        document.querySelectorAll('.star-btn').forEach(btn => {
            const btnRating = parseInt(btn.dataset.rating);
            const icon = btn.querySelector('i');
            
            if (btnRating <= rating) {
                icon.classList.remove('far');
                icon.classList.add('fas', 'text-yellow-400');
                btn.classList.remove('text-gray-400');
                btn.classList.add('text-yellow-400');
            } else {
                icon.classList.remove('fas', 'text-yellow-400');
                icon.classList.add('far');
                btn.classList.remove('text-yellow-400');
                btn.classList.add('text-gray-400');
            }
        });
    },

    previewImages(input) {
        const container = document.getElementById('reviewImagePreview');
        container.innerHTML = '';
        
        Array.from(input.files).forEach(file => {
            const reader = new FileReader();
            reader.onload = (e) => {
                container.innerHTML += `
                    <div class="relative w-20 h-20">
                        <img src="${e.target.result}" class="w-full h-full object-cover rounded-lg">
                    </div>
                `;
            };
            reader.readAsDataURL(file);
        });
    },

    async handleSubmit(e, storeId, productId, orderId) {
        e.preventDefault();
        
        if (!this.currentRating) {
            Utils.showToast('Erro', 'Selecione uma avaliação de 1 a 5 estrelas', 'error');
            return;
        }

        const btn = e.target.querySelector('button[type="submit"]');
        btn.classList.add('btn-loading');

        // Processar imagens
        const imageFiles = document.getElementById('reviewImages')?.files;
        const images = [];
        
        if (imageFiles) {
            for (let file of imageFiles) {
                const optimized = await Products.optimizeAndUpload(file);
                images.push(optimized.url);
            }
        }

        const success = await this.create({
            storeId,
            productId: productId || null,
            orderId,
            userId: Auth.userData.id,
            userName: Auth.userData.name,
            userAvatar: Auth.userData.avatar,
            rating: this.currentRating,
            title: document.getElementById('reviewTitle').value,
            comment: document.getElementById('reviewComment').value,
            images,
            verifiedPurchase: !!orderId
        });

        btn.classList.remove('btn-loading');
        
        if (success) {
            e.target.reset();
            this.currentRating = 0;
            document.getElementById('reviewImagePreview').innerHTML = '';
            this.renderReviewForm(e.target.closest('[id]').id, storeId, productId, orderId);
        }
    },

    // Renderizar lista de avaliações
    renderReviewsList(containerId, reviews, showReply = false) {
        const container = document.getElementById(containerId);
        if (!container) return;

        if (reviews.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-comment-slash text-3xl mb-3"></i>
                    <p>Sem avaliações ainda</p>
                    <p class="text-sm">Seja o primeiro a avaliar!</p>
                </div>
            `;
            return;
        }

        container.innerHTML = reviews.map(review => `
            <div class="glass rounded-xl p-4 mb-4 ${review.verifiedPurchase ? 'border-l-4 border-green-500' : ''}">
                <div class="flex items-start gap-3">
                    <img src="${review.userAvatar}" class="w-10 h-10 rounded-full">
                    <div class="flex-1">
                        <div class="flex items-center gap-2 mb-1">
                            <span class="font-medium">${review.userName}</span>
                            ${review.verifiedPurchase ? '<span class="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded">Compra verificada</span>' : ''}
                            <span class="text-xs text-gray-500">${Utils.formatDate(review.createdAt)}</span>
                        </div>
                        
                        ${this.renderStars(review.rating, 'sm')}
                        
                        ${review.title ? `<p class="font-medium mt-2">${review.title}</p>` : ''}
                        <p class="text-gray-300 mt-1">${review.comment}</p>
                        
                        ${review.images?.length > 0 ? `
                            <div class="flex gap-2 mt-3">
                                ${review.images.map(img => `
                                    <img src="${img}" class="w-16 h-16 object-cover rounded-lg cursor-pointer hover:opacity-80" onclick="window.open('${img}')">
                                `).join('')}
                            </div>
                        ` : ''}
                        
                        <div class="flex items-center gap-4 mt-3 text-sm">
                            <button onclick="Reviews.markHelpful('${review.id}')" class="text-gray-400 hover:text-primary flex items-center gap-1">
                                <i class="fas fa-thumbs-up"></i> Útil (${review.helpful || 0})
                            </button>
                            ${Auth.userData?.id === review.userId ? `
                                <button onclick="Reviews.delete('${review.id}')" class="text-red-400 hover:text-red-300">
                                    <i class="fas fa-trash"></i> Excluir
                                </button>
                            ` : ''}
                        </div>
                        
                        ${review.reply ? `
                            <div class="mt-4 pl-4 border-l-2 border-primary/30">
                                <div class="flex items-center gap-2 mb-1">
                                    <i class="fas fa-store text-primary"></i>
                                    <span class="font-medium text-sm">Resposta do lojista</span>
                                    <span class="text-xs text-gray-500">${Utils.formatDate(review.reply.createdAt)}</span>
                                </div>
                                <p class="text-gray-300 text-sm">${review.reply.text}</p>
                            </div>
                        ` : ''}
                        
                        ${showReply && !review.reply ? `
                            <div class="mt-4">
                                <form onsubmit="Reviews.handleReply(event, '${review.id}')" class="flex gap-2">
                                    <input type="text" name="reply" placeholder="Responder avaliação..." 
                                           class="input-field flex-1 rounded-lg px-3 py-2 text-sm" required>
                                    <button type="submit" class="btn btn-primary text-sm px-4">
                                        <i class="fas fa-reply"></i>
                                    </button>
                                </form>
                            </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        `).join('');
    },

    async handleReply(e, reviewId) {
        e.preventDefault();
        const text = e.target.reply.value;
        const success = await this.reply(reviewId, text);
        if (success) {
            e.target.reset();
            // Recarregar reviews
            const review = await getDoc(doc(db, 'reviews', reviewId));
            const data = review.data();
            this.renderReviewsList('reviewsList', [data], true);
        }
    },

    async delete(reviewId) {
        if (!confirm('Tem certeza que deseja excluir sua avaliação?')) return;

        try {
            await deleteDoc(doc(db, 'reviews', reviewId));
            Utils.showToast('Sucesso', 'Avaliação excluída');
            // Recarregar
            location.reload();
        } catch (error) {
            Utils.showToast('Erro', 'Erro ao excluir', 'error');
        }
    }
};

window.Reviews = Reviews;
export default Reviews;