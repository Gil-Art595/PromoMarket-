// ==========================================
// SISTEMA DE CUPONS DE DESCONTO
// ==========================================

import { collection, doc, getDocs, getDoc, setDoc, updateDoc, query, where, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const db = window.firebaseDb;

const Coupons = {
    // Validar cupom
    async validate(code, storeId = null, cartTotal = 0) {
        try {
            const q = query(
                collection(db, 'coupons'),
                where('code', '==', code.toUpperCase()),
                where('active', '==', true)
            );

            const snapshot = await getDocs(q);
            if (snapshot.empty) {
                return { valid: false, error: 'Cupom não encontrado' };
            }

            const coupon = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };

            // Verificar expiração
            if (coupon.expiresAt && coupon.expiresAt.toDate() < new Date()) {
                return { valid: false, error: 'Cupom expirado' };
            }

            // Verificar uso máximo
            if (coupon.maxUses && coupon.usedCount >= coupon.maxUses) {
                return { valid: false, error: 'Limite de usos atingido' };
            }

            // Verificar loja específica
            if (coupon.storeId && coupon.storeId !== storeId) {
                return { valid: false, error: 'Cupom não válido para esta loja' };
            }

            // Verificar valor mínimo
            if (coupon.minPurchase && cartTotal < coupon.minPurchase) {
                return { valid: false, error: `Valor mínimo de R$ ${coupon.minPurchase.toFixed(2)}` };
            }

            // Verificar uso por usuário
            if (coupon.maxUsesPerUser) {
                const userUsage = await this.getUserUsage(coupon.id, Auth.userData?.id);
                if (userUsage >= coupon.maxUsesPerUser) {
                    return { valid: false, error: 'Você já usou este cupom' };
                }
            }

            // Calcular desconto
            let discount = 0;
            if (coupon.type === 'percentage') {
                discount = cartTotal * (coupon.value / 100);
                if (coupon.maxDiscount) {
                    discount = Math.min(discount, coupon.maxDiscount);
                }
            } else {
                discount = coupon.value;
            }

            return {
                valid: true,
                coupon: coupon,
                discount: discount,
                finalTotal: Math.max(0, cartTotal - discount)
            };

        } catch (error) {
            console.error('Erro ao validar cupom:', error);
            return { valid: false, error: 'Erro ao validar cupom' };
        }
    },

    // Aplicar cupom ao pedido
    async apply(code, orderData) {
        const validation = await this.validate(code, orderData.storeId, orderData.subtotal);
        
        if (!validation.valid) {
            return validation;
        }

        // Registrar uso
        await this.recordUsage(validation.coupon.id, orderData.id, Auth.userData?.id);

        return {
            success: true,
            discount: validation.discount,
            finalTotal: validation.finalTotal,
            couponId: validation.coupon.id
        };
    },

    // Registrar uso do cupom
    async recordUsage(couponId, orderId, userId) {
        // Incrementar contador
        const couponRef = doc(db, 'coupons', couponId);
        const couponDoc = await getDoc(couponRef);
        const currentCount = couponDoc.data().usedCount || 0;

        await updateDoc(couponRef, {
            usedCount: currentCount + 1,
            updatedAt: serverTimestamp()
        });

        // Registrar uso individual
        await setDoc(doc(db, 'couponUsages', `${couponId}_${userId}_${orderId}`), {
            couponId: couponId,
            orderId: orderId,
            userId: userId,
            usedAt: serverTimestamp()
        });
    },

    // Verificar uso por usuário
    async getUserUsage(couponId, userId) {
        const q = query(
            collection(db, 'couponUsages'),
            where('couponId', '==', couponId),
            where('userId', '==', userId)
        );

        const snapshot = await getDocs(q);
        return snapshot.size;
    },

    // Criar cupom (admin/lojista)
    async create(data) {
        try {
            const code = data.code.toUpperCase().replace(/[^A-Z0-9]/g, '');
            
            // Verificar se código já existe
            const existing = await getDocs(query(collection(db, 'coupons'), where('code', '==', code)));
            if (!existing.empty) {
                Utils.showToast('Erro', 'Código já existe', 'error');
                return false;
            }

            const couponData = {
                id: Utils.generateId(),
                code: code,
                type: data.type, // 'percentage' ou 'fixed'
                value: parseFloat(data.value),
                description: data.description || '',
                storeId: data.storeId || null, // null = válido para todas as lojas
                minPurchase: parseFloat(data.minPurchase) || 0,
                maxDiscount: parseFloat(data.maxDiscount) || null,
                maxUses: parseInt(data.maxUses) || null,
                maxUsesPerUser: parseInt(data.maxUsesPerUser) || 1,
                usedCount: 0,
                active: true,
                startsAt: data.startsAt ? new Date(data.startsAt) : serverTimestamp(),
                expiresAt: data.expiresAt ? new Date(data.expiresAt) : null,
                createdBy: Auth.userData.id,
                createdAt: serverTimestamp()
            };

            await setDoc(doc(db, 'coupons', couponData.id), couponData);
            
            Utils.showToast('Sucesso', `Cupom ${code} criado!`);
            return couponData;

        } catch (error) {
            console.error('Erro ao criar cupom:', error);
            Utils.showToast('Erro', 'Erro ao criar cupom', 'error');
            return false;
        }
    },

    // Desativar cupom
    async deactivate(couponId) {
        try {
            await updateDoc(doc(db, 'coupons', couponId), {
                active: false,
                updatedAt: serverTimestamp()
            });
            Utils.showToast('Sucesso', 'Cupom desativado');
            return true;
        } catch (error) {
            Utils.showToast('Erro', 'Erro ao desativar', 'error');
            return false;
        }
    },

    // Renderizar campo de cupom no checkout
    renderCouponInput(containerId, onApply) {
        const container = document.getElementById(containerId);
        if (!container) return;

        container.innerHTML = `
            <div class="glass rounded-xl p-4 border border-gray-700">
                <label class="form-label flex items-center gap-2">
                    <i class="fas fa-ticket-alt text-primary"></i>
                    Cupom de desconto
                </label>
                <div class="flex gap-2 mt-2">
                    <input type="text" id="couponCode" placeholder="Digite o código" 
                           class="input-field flex-1 rounded-xl px-4 py-3 uppercase">
                    <button onclick="Coupons.handleApply()" class="btn btn-primary px-6">
                        Aplicar
                    </button>
                </div>
                <div id="couponMessage" class="mt-2 text-sm"></div>
            </div>
        `;

        this.onApplyCallback = onApply;
    },

    async handleApply() {
        const code = document.getElementById('couponCode').value;
        const messageDiv = document.getElementById('couponMessage');
        
        if (!code) {
            messageDiv.innerHTML = '<span class="text-red-400">Digite um código</span>';
            return;
        }

        messageDiv.innerHTML = '<i class="fas fa-spinner fa-spin text-primary"></i> Validando...';

        // Aqui você precisaria do contexto (storeId, cartTotal)
        // Por enquanto, validação simples
        const result = await this.validate(code);

        if (result.valid) {
            messageDiv.innerHTML = `<span class="text-green-400">✓ Cupom aplicado! Desconto: R$ ${result.discount.toFixed(2)}</span>`;
            if (this.onApplyCallback) {
                this.onApplyCallback(result);
            }
        } else {
            messageDiv.innerHTML = `<span class="text-red-400">✗ ${result.error}</span>`;
        }
    },

    // Renderizar lista de cupons (admin/lojista)
    async renderCouponList(containerId, storeId = null) {
        const container = document.getElementById(containerId);
        if (!container) return;

        let q;
        if (storeId) {
            q = query(collection(db, 'coupons'), where('storeId', '==', storeId));
        } else if (Auth.isAdmin()) {
            q = query(collection(db, 'coupons'));
        } else {
            container.innerHTML = '<p class="text-red-400">Sem permissão</p>';
            return;
        }

        const snapshot = await getDocs(q);
        const coupons = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));

        container.innerHTML = `
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Desconto</th>
                            <th>Usos</th>
                            <th>Status</th>
                            <th>Validade</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${coupons.map(c => `
                            <tr>
                                <td class="font-mono font-bold">${c.code}</td>
                                <td>
                                    ${c.type === 'percentage' ? `${c.value}%` : `R$ ${c.value.toFixed(2)}`}
                                    ${c.maxDiscount ? `<br><span class="text-xs text-gray-500">máx R$ ${c.maxDiscount.toFixed(2)}</span>` : ''}
                                </td>
                                <td>${c.usedCount}${c.maxUses ? `/${c.maxUses}` : ''}</td>
                                <td>
                                    <span class="px-2 py-1 rounded text-xs ${c.active ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}">
                                        ${c.active ? 'Ativo' : 'Inativo'}
                                    </span>
                                </td>
                                <td>
                                    ${c.expiresAt ? Utils.formatDate(c.expiresAt).split(' ')[0] : 'Sem expiração'}
                                </td>
                                <td>
                                    ${c.active ? `
                                        <button onclick="Coupons.deactivate('${c.id}')" class="text-red-400 hover:text-red-300">
                                            <i class="fas fa-ban"></i> Desativar
                                        </button>
                                    ` : '-'}
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    },

    // Formulário de criação
    renderCreateForm(containerId, storeId = null) {
        const container = document.getElementById(containerId);
        if (!container) return;

        container.innerHTML = `
            <div class="glass rounded-xl p-6">
                <h3 class="font-bold text-lg mb-4">Criar Cupom</h3>
                <form onsubmit="Coupons.handleCreate(event, '${storeId}')" class="space-y-4">
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Código *</label>
                            <input type="text" name="code" required class="input-field w-full rounded-xl px-4 py-3 uppercase" 
                                   placeholder="PROMO10">
                        </div>
                        <div>
                            <label class="form-label">Tipo *</label>
                            <select name="type" class="input-field w-full rounded-xl px-4 py-3">
                                <option value="percentage">Porcentagem (%)</option>
                                <option value="fixed">Valor Fixo (R$)</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Valor do desconto *</label>
                            <input type="number" name="value" required step="0.01" class="input-field w-full rounded-xl px-4 py-3" 
                                   placeholder="10">
                        </div>
                        <div>
                            <label class="form-label">Desconto máximo (opcional)</label>
                            <input type="number" name="maxDiscount" step="0.01" class="input-field w-full rounded-xl px-4 py-3" 
                                   placeholder="R$ 50,00">
                        </div>
                    </div>
                    
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Compra mínima (opcional)</label>
                            <input type="number" name="minPurchase" step="0.01" class="input-field w-full rounded-xl px-4 py-3" 
                                   placeholder="R$ 0,00">
                        </div>
                        <div>
                            <label class="form-label">Limite de usos (opcional)</label>
                            <input type="number" name="maxUses" class="input-field w-full rounded-xl px-4 py-3" 
                                   placeholder="Ilimitado">
                        </div>
                    </div>
                    
                    <div>
                        <label class="form-label">Descrição</label>
                        <input type="text" name="description" class="input-field w-full rounded-xl px-4 py-3" 
                               placeholder="Ex: 10% de desconto na primeira compra">
                    </div>
                    
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Data de início</label>
                            <input type="datetime-local" name="startsAt" class="input-field w-full rounded-xl px-4 py-3">
                        </div>
                        <div>
                            <label class="form-label">Data de expiração</label>
                            <input type="datetime-local" name="expiresAt" class="input-field w-full rounded-xl px-4 py-3">
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-full">
                        <i class="fas fa-plus mr-2"></i> Criar Cupom
                    </button>
                </form>
            </div>
        `;
    },

    async handleCreate(e, storeId) {
        e.preventDefault();
        const btn = e.target.querySelector('button[type="submit"]');
        btn.classList.add('btn-loading');

        const formData = new FormData(e.target);
        
        const success = await this.create({
            code: formData.get('code'),
            type: formData.get('type'),
            value: formData.get('value'),
            description: formData.get('description'),
            storeId: storeId,
            minPurchase: formData.get('minPurchase'),
            maxDiscount: formData.get('maxDiscount'),
            maxUses: formData.get('maxUses'),
            startsAt: formData.get('startsAt'),
            expiresAt: formData.get('expiresAt')
        });

        btn.classList.remove('btn-loading');
        
        if (success) {
            e.target.reset();
            // Recarregar lista
            this.renderCouponList('couponList', storeId);
        }
    }
};

window.Coupons = Coupons;
export default Coupons;