// ==========================================
// SISTEMA DE PAGAMENTO - MULTI-GATEWAY
// ==========================================

import { doc, setDoc, updateDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const db = window.firebaseDb;

const Payment = {
    currentProduct: null,
    currentStore: null,
    paymentMethod: 'card',
    selectedGateway: null,
    gatewayInstance: null,

    async openCheckout(productId, storeId) {
        const store = Stores.data.find(s => s.id === storeId);
        if (!store) {
            Utils.showToast('Erro', 'Loja não encontrada', 'error');
            return;
        }

        const product = store.items.find(i => i.id === productId);
        if (!product) {
            Utils.showToast('Erro', 'Produto não encontrado', 'error');
            return;
        }

        // Verificar gateways disponíveis
        const availableGateways = this.getAvailableGateways(store);
        
        if (availableGateways.length === 0) {
            Utils.showToast('Erro', 'Esta loja não está configurada para receber pagamentos', 'error');
            return;
        }

        this.currentProduct = product;
        this.currentStore = store;
        this.selectedGateway = availableGateways[0]; // Default: primeiro disponível

        this.renderCheckout(availableGateways);
    },

    getAvailableGateways(store) {
        const gateways = [];
        
        if (store.mercadoPago?.accessToken) {
            gateways.push({ id: 'mercadopago', name: 'Mercado Pago', icon: 'fas fa-credit-card' });
        }
        
        if (store.asaas?.apiKey) {
            gateways.push({ id: 'asaas', name: 'Asaas', icon: 'fas fa-university' });
        }
        
        if (store.picpay?.picpayToken) {
            gateways.push({ id: 'picpay', name: 'PicPay', icon: 'fas fa-mobile-alt' });
        }
        
        if (store.pixKey || store.mercadoPago?.pixKey) {
            gateways.push({ id: 'pixdirect', name: 'PIX Direto', icon: 'fas fa-qrcode' });
        }
        
        return gateways;
    },

    renderCheckout(availableGateways) {
        const modal = document.getElementById('checkoutModal');
        const content = document.getElementById('checkoutModalContent');

        // Atualizar título com seleção de gateway
        const gatewaySelector = availableGateways.length > 1 ? `
            <div class="mb-4">
                <label class="text-sm text-gray-400 mb-2 block">Forma de pagamento</label>
                <div class="flex gap-2">
                    ${availableGateways.map(g => `
                        <button onclick="Payment.selectGateway('${g.id}')" 
                                class="gateway-btn flex-1 py-2 px-3 rounded-lg border ${this.selectedGateway.id === g.id ? 'border-primary bg-primary/20 text-primary' : 'border-gray-700 text-gray-400'} text-sm flex items-center justify-center gap-2">
                            <i class="${g.icon}"></i>
                            ${g.name}
                        </button>
                    `).join('')}
                </div>
            </div>
        ` : '';

        document.getElementById('checkoutStoreName').textContent = this.currentStore.name;
        document.getElementById('checkoutTotal').textContent = `R$ ${this.currentProduct.price.toFixed(2)}`;
        document.getElementById('btnPaymentAmount').textContent = this.currentProduct.price.toFixed(2);

        document.getElementById('checkoutItems').innerHTML = `
            <div class="flex items-center gap-3 p-3 bg-gray-800/50 rounded-lg">
                <img src="${this.currentProduct.image}" class="w-16 h-16 object-cover rounded-lg">
                <div class="flex-1">
                    <p class="font-medium">${this.currentProduct.name}</p>
                    <p class="text-sm text-gray-400">R$ ${this.currentProduct.price.toFixed(2)}</p>
                </div>
            </div>
            ${gatewaySelector}
        `;

        this.renderDeliveryOptions();
        this.renderPaymentSection();

        modal.classList.remove('hidden');
        setTimeout(() => content.classList.add('show'), 10);
    },

    selectGateway(gatewayId) {
        this.selectedGateway = this.getAvailableGateways(this.currentStore).find(g => g.id === gatewayId);
        this.renderCheckout(this.getAvailableGateways(this.currentStore));
    },

    renderDeliveryOptions() {
        const deliveryOptions = this.currentStore.deliveryOptions || { allowDelivery: true, allowPickup: true };
        const choicesDiv = document.getElementById('deliveryChoices');
        
        let choicesHTML = '';
        
        if (deliveryOptions.allowPickup) {
            choicesHTML += `
                <label class="flex items-center gap-3 p-4 bg-gray-800/50 rounded-xl cursor-pointer hover:bg-gray-800 transition-colors border border-transparent focus-within:border-primary">
                    <input type="radio" name="deliveryType" value="pickup" checked onchange="Payment.onDeliveryChange()" class="text-primary w-4 h-4">
                    <div class="flex-1">
                        <div class="flex items-center gap-2">
                            <i class="fas fa-store text-blue-400"></i>
                            <span class="font-medium">Retirar na Loja</span>
                        </div>
                        <p class="text-sm text-gray-400">Grátis - Você busca no endereço da loja</p>
                    </div>
                    <span class="text-green-400 font-bold">Grátis</span>
                </label>
            `;
        }
        
        if (deliveryOptions.allowDelivery) {
            const fee = deliveryOptions.deliveryFee || 0;
            choicesHTML += `
                <label class="flex items-center gap-3 p-4 bg-gray-800/50 rounded-xl cursor-pointer hover:bg-gray-800 transition-colors border border-transparent focus-within:border-primary">
                    <input type="radio" name="deliveryType" value="delivery" ${!deliveryOptions.allowPickup ? 'checked' : ''} onchange="Payment.onDeliveryChange()" class="text-primary w-4 h-4">
                    <div class="flex-1">
                        <div class="flex items-center gap-2">
                            <i class="fas fa-truck text-green-400"></i>
                            <span class="font-medium">Entrega</span>
                        </div>
                        <p class="text-sm text-gray-400">Receba em seu endereço</p>
                    </div>
                    <span class="font-bold">${fee > 0 ? `R$ ${fee.toFixed(2)}` : 'Grátis'}</span>
                </label>
            `;
        }
        
        choicesDiv.innerHTML = choicesHTML;
    },

    renderPaymentSection() {
        const cardSection = document.getElementById('cardPayment');
        const pixSection = document.getElementById('pixPayment');

        // Configurar baseado no gateway selecionado
        if (this.selectedGateway.id === 'pixdirect' || this.selectedGateway.id === 'asaas') {
            // PIX disponível
            document.getElementById('tabPix').classList.remove('hidden');
        } else {
            document.getElementById('tabPix').classList.add('hidden');
            this.paymentMethod = 'card';
        }

        if (this.paymentMethod === 'card') {
            cardSection.classList.remove('hidden');
            pixSection.classList.add('hidden');
            this.initCardForm();
        } else {
            cardSection.classList.add('hidden');
            pixSection.classList.remove('hidden');
            this.generatePix();
        }
    },

    initCardForm() {
        const container = document.getElementById('cardPaymentForm');
        
        if (this.selectedGateway.id === 'mercadopago' && this.currentStore.mercadoPago?.publicKey) {
            this.initMercadoPagoCard(container);
        } else if (this.selectedGateway.id === 'asaas') {
            this.initAsaasCard(container);
        } else {
            container.innerHTML = `
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    <div>
                        <p class="font-medium">Pagamento na entrega</p>
                        <p class="text-sm">Esta loja aceita pagamento na entrega/retirada. Selecione PIX para pagar agora.</p>
                    </div>
                </div>
            `;
        }
    },

    initMercadoPagoCard(container) {
        try {
            const mp = new MercadoPago(this.currentStore.mercadoPago.publicKey, {
                locale: 'pt-BR'
            });

            const cardForm = mp.cardForm({
                amount: String(this.getTotal()),
                autoMount: true,
                form: {
                    id: 'form-checkout',
                    cardholderName: { id: 'form-checkout__cardholderName', placeholder: 'Nome no cartão' },
                    cardholderEmail: { id: 'form-checkout__cardholderEmail', placeholder: 'Email' },
                    cardNumber: { id: 'form-checkout__cardNumber', placeholder: 'Número do cartão' },
                    cardExpirationMonth: { id: 'form-checkout__cardExpirationMonth', placeholder: 'MM' },
                    cardExpirationYear: { id: 'form-checkout__cardExpirationYear', placeholder: 'AA' },
                    securityCode: { id: 'form-checkout__securityCode', placeholder: 'CVV' },
                    installments: { id: 'form-checkout__installments', placeholder: 'Parcelas' },
                    issuer: { id: 'form-checkout__issuer', placeholder: 'Banco' }
                },
                callbacks: {
                    onFormMounted: error => {
                        if (error) console.error('Form mounted error:', error);
                    },
                    onSubmit: event => {
                        event.preventDefault();
                        this.processMercadoPagoPayment(cardForm);
                    }
                }
            });

            this.gatewayInstance = cardForm;
        } catch (error) {
            container.innerHTML = `<div class="alert alert-error">Erro ao carregar formulário. Tente PIX.</div>`;
        }
    },

    initAsaasCard(container) {
        // Formulário próprio para Asaas
        container.innerHTML = `
            <div class="space-y-3">
                <input type="text" id="cardHolderName" placeholder="Nome no cartão" class="input-field w-full rounded-xl px-4 py-3">
                <input type="text" id="cardNumber" placeholder="Número do cartão (somente números)" maxlength="16" class="input-field w-full rounded-xl px-4 py-3">
                <div class="grid grid-cols-3 gap-3">
                    <input type="text" id="cardExpiryMonth" placeholder="MM" maxlength="2" class="input-field w-full rounded-xl px-4 py-3">
                    <input type="text" id="cardExpiryYear" placeholder="AAAA" maxlength="4" class="input-field w-full rounded-xl px-4 py-3">
                    <input type="text" id="cardCVV" placeholder="CVV" maxlength="4" class="input-field w-full rounded-xl px-4 py-3">
                </div>
            </div>
        `;
    },

    async generatePix() {
        const qrContainer = document.getElementById('pixQRCode');
        qrContainer.innerHTML = '<div class="text-center"><i class="fas fa-spinner fa-spin text-2xl"></i><p class="text-sm mt-2">Gerando PIX...</p></div>';

        let pixPayload;

        if (this.selectedGateway.id === 'asaas') {
            // Gerar via Asaas
            const result = await this.createAsaasPixCharge();
            pixPayload = result.invoiceUrl || result.payload;
        } else {
            // PIX Direto
            const pixKey = this.currentStore.pixKey || this.currentStore.mercadoPago?.pixKey;
            pixPayload = Gateways.generatePixPayload({
                key: pixKey,
                amount: this.getTotal(),
                description: `Pedido ${this.currentProduct.name}`,
                merchantName: this.currentStore.name,
                transactionId: Utils.generateId()
            });
        }

        // Gerar QR Code
        qrContainer.innerHTML = '';
        new QRCode(qrContainer, {
            text: pixPayload,
            width: 200,
            height: 200,
            colorDark: '#000000',
            colorLight: '#ffffff',
            correctLevel: QRCode.CorrectLevel.M
        });

        document.getElementById('pixCode').textContent = pixPayload;
    },

    async createAsaasPixCharge() {
        const config = {
            apiKey: this.currentStore.asaas.apiKey,
            sandbox: this.currentStore.asaas.sandbox !== false,
            baseUrl: this.currentStore.asaas.sandbox !== false 
                ? 'https://sandbox.asaas.com/api/v3'
                : 'https://api.asaas.com/v3'
        };

        const customer = await this.getOrCreateAsaasCustomer(config);
        
        const response = await fetch(`${config.baseUrl}/payments`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'access_token': config.apiKey
            },
            body: JSON.stringify({
                customer: customer.id,
                billingType: 'PIX',
                value: this.getTotal(),
                dueDate: new Date().toISOString().split('T')[0],
                description: `Pedido RedePromo - ${this.currentProduct.name}`,
                externalReference: Utils.generateId()
            })
        });

        return await response.json();
    },

    async getOrCreateAsaasCustomer(config) {
        const user = Auth.userData;
        
        // Buscar existente
        const search = await fetch(`${config.baseUrl}/customers?email=${user.email}`, {
            headers: { 'access_token': config.apiKey }
        });
        const searchData = await search.json();

        if (searchData.data?.length > 0) {
            return searchData.data[0];
        }

        // Criar novo
        const response = await fetch(`${config.baseUrl}/customers`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'access_token': config.apiKey
            },
            body: JSON.stringify({
                name: user.name,
                email: user.email,
                phone: user.phone,
                cpfCnpj: user.cpf || '00000000000' // Idealmente coletar CPF no cadastro
            })
        });

        return await response.json();
    },

    async processPayment() {
        const btn = document.getElementById('btnFinalizePayment');
        btn.classList.add('btn-loading');

        try {
            if (this.paymentMethod === 'pix') {
                await this.processPixOrder();
            } else {
                await this.processCardOrder();
            }
        } catch (error) {
            console.error(error);
            Utils.showToast('Erro', error.message || 'Erro no pagamento', 'error');
        } finally {
            btn.classList.remove('btn-loading');
        }
    },

    async processPixOrder() {
        // Criar pedido pendente
        const order = await this.createOrder('pix');
        
        // Se for PIX direto, já pode fechar
        if (this.selectedGateway.id === 'pixdirect') {
            Utils.showToast('Sucesso', 'Pedido criado! Escaneie o QR Code para pagar.');
            this.monitorOrder(order.id);
        } else {
            Utils.showToast('Sucesso', 'PIX gerado! Complete o pagamento no seu app bancário.');
        }
    },

    async processCardOrder() {
        if (this.selectedGateway.id === 'mercadopago') {
            // O cardForm já vai chamar o callback
            return;
        }
        
        if (this.selectedGateway.id === 'asaas') {
            await this.processAsaasCard();
        }
    },

    async processAsaasCard() {
        const config = {
            apiKey: this.currentStore.asaas.apiKey,
            sandbox: this.currentStore.asaas.sandbox !== false,
            baseUrl: this.currentStore.asaas.sandbox !== false 
                ? 'https://sandbox.asaas.com/api/v3'
                : 'https://api.asaas.com/v3'
        };

        const customer = await this.getOrCreateAsaasCustomer(config);
        
        const cardData = {
            holderName: document.getElementById('cardHolderName').value,
            number: document.getElementById('cardNumber').value.replace(/\D/g, ''),
            expiryMonth: document.getElementById('cardExpiryMonth').value,
            expiryYear: document.getElementById('cardExpiryYear').value,
            ccv: document.getElementById('cardCVV').value
        };

        const response = await fetch(`${config.baseUrl}/payments`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'access_token': config.apiKey
            },
            body: JSON.stringify({
                customer: customer.id,
                billingType: 'CREDIT_CARD',
                value: this.getTotal(),
                dueDate: new Date().toISOString().split('T')[0],
                description: `Pedido RedePromo - ${this.currentProduct.name}`,
                externalReference: Utils.generateId(),
                creditCard: cardData,
                creditCardHolderInfo: {
                    name: customer.name,
                    email: customer.email,
                    cpfCnpj: customer.cpfCnpj,
                    phone: customer.phone
                }
            })
        });

        const result = await response.json();

        if (result.status === 'CONFIRMED' || result.status === 'RECEIVED') {
            const order = await this.createOrder('credit_card', result.id);
            Utils.showToast('Sucesso', 'Pagamento aprovado!');
            this.closeCheckout();
        } else {
            throw new Error(result.errors?.[0]?.description || 'Pagamento não aprovado');
        }
    },

    async processMercadoPagoPayment(cardForm) {
        const formData = cardForm.getCardFormData();
        
        // Aqui você enviaria para seu backend ou processaria
        // Como é frontend-only, vamos simular criando o pedido
        
        const order = await this.createOrder('credit_card');
        Utils.showToast('Sucesso', 'Processando pagamento...');
        
        // Em produção, redirecionar para página de processamento
    },

    async createOrder(paymentMethod, gatewayTransactionId = null) {
        const deliveryType = document.querySelector('input[name="deliveryType"]:checked').value;
        const fee = deliveryType === 'delivery' ? (this.currentStore.deliveryOptions?.deliveryFee || 0) : 0;
        
        const orderData = {
            id: Utils.generateId(),
            storeId: this.currentStore.id,
            storeName: this.currentStore.name,
            productId: this.currentProduct.id,
            productName: this.currentProduct.name,
            productImage: this.currentProduct.image,
            productPrice: this.currentProduct.price,
            deliveryFee: fee,
            total: this.getTotal(),
            deliveryType: deliveryType,
            deliveryAddress: deliveryType === 'delivery' ? {
                street: document.getElementById('deliveryStreet')?.value,
                number: document.getElementById('deliveryNumber')?.value,
                complement: document.getElementById('deliveryComplement')?.value,
                neighborhood: document.getElementById('deliveryNeighborhood')?.value
            } : null,
            customerId: Auth.userData?.id,
            customerName: Auth.userData?.name,
            customerEmail: Auth.userData?.email,
            customerPhone: Auth.userData?.phone,
            paymentMethod: paymentMethod,
            gateway: this.selectedGateway.id,
            gatewayTransactionId: gatewayTransactionId,
            status: paymentMethod === 'pix' ? 'pending_payment' : 'processing',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
        };

        // Salvar na loja
        const storeRef = doc(db, 'stores', this.currentStore.id);
        const storeDoc = await getDoc(storeRef);
        const currentOrders = storeDoc.data().orders || [];
        
        await updateDoc(storeRef, {
            orders: [...currentOrders, orderData],
            updatedAt: serverTimestamp()
        });

        // Salvar na coleção global de pedidos
        await setDoc(doc(db, 'orders', orderData.id), orderData);

        // Atualizar local
        this.currentStore.orders = [...currentOrders, orderData];

        return orderData;
    },

    getTotal() {
        const deliveryType = document.querySelector('input[name="deliveryType"]:checked')?.value || 'pickup';
        const fee = deliveryType === 'delivery' ? (this.currentStore.deliveryOptions?.deliveryFee || 0) : 0;
        return this.currentProduct.price + fee;
    },

    onDeliveryChange() {
        const type = document.querySelector('input[name="deliveryType"]:checked').value;
        document.getElementById('deliveryAddressSection').classList.toggle('hidden', type !== 'delivery');
        
        document.getElementById('checkoutTotal').textContent = `R$ ${this.getTotal().toFixed(2)}`;
        document.getElementById('btnPaymentAmount').textContent = this.getTotal().toFixed(2);
    },

    switchPaymentTab(method) {
        this.paymentMethod = method;
        
        document.getElementById('tabCard').className = method === 'card' 
            ? 'flex-1 py-2 rounded-lg bg-primary/20 text-primary text-sm font-medium border border-primary/30'
            : 'flex-1 py-2 rounded-lg glass text-gray-400 text-sm font-medium hover:text-white';
            
        document.getElementById('tabPix').className = method === 'pix'
            ? 'flex-1 py-2 rounded-lg bg-primary/20 text-primary text-sm font-medium border border-primary/30'
            : 'flex-1 py-2 rounded-lg glass text-gray-400 text-sm font-medium hover:text-white';

        this.renderPaymentSection();
    },

    copyPixCode() {
        const code = document.getElementById('pixCode').textContent;
        Utils.copyToClipboard(code).then(() => {
            Utils.showToast('Copiado!', 'Código PIX copiado para a área de transferência');
        });
    },

    async monitorOrder(orderId) {
        // Simplificado - em produção, usar polling ou websocket
        console.log('Monitorando pedido:', orderId);
    },

    closeCheckout() {
        const modal = document.getElementById('checkoutModal');
        const content = document.getElementById('checkoutModalContent');
        
        content.classList.remove('show');
        setTimeout(() => {
            modal.classList.add('hidden');
            this.currentProduct = null;
            this.currentStore = null;
            this.gatewayInstance = null;
            this.selectedGateway = null;
        }, 300);
    }
};

window.Payment = Payment;
export default Payment;