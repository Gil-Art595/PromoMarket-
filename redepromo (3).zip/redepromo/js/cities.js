// ==========================================
// SISTEMA DE CIDADES
// ==========================================

import { collection, doc, getDocs, setDoc, deleteDoc, onSnapshot, query, orderBy } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const db = window.firebaseDb;

const Cities = {
    data: [],
    currentCity: null,
    listeners: [],

    // Inicializar
    async init() {
        this.loadCurrentCity();
        await this.loadCities();
        this.setupRealtimeListener();
        this.populateSelectors();
    },

    // Carregar cidades do Firestore
    async loadCities() {
        try {
            const q = query(collection(db, 'cities'), orderBy('name'));
            const snapshot = await getDocs(q);
            
            this.data = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            }));
            
            console.log(`🏙️ ${this.data.length} cidades carregadas`);
            return this.data;
        } catch (error) {
            console.error('Erro ao carregar cidades:', error);
            return [];
        }
    },

    // Listener em tempo real
    setupRealtimeListener() {
        const q = query(collection(db, 'cities'), orderBy('name'));
        
        onSnapshot(q, (snapshot) => {
            this.data = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            }));
            
            this.populateSelectors();
            this.notifyListeners();
            
            // Atualizar contador no hero
            const statCities = document.getElementById('statCities');
            if (statCities) {
                statCities.textContent = this.data.length;
            }
        });
    },

    // Popular selects de cidade
    populateSelectors() {
        const selectors = [
            document.getElementById('regCity'),
            document.getElementById('navCitySelector'),
            document.getElementById('mobileCitySelector'),
            document.getElementById('storeCity') // no modal de loja
        ];

        selectors.forEach(select => {
            if (!select) return;
            
            const currentValue = select.value;
            select.innerHTML = '<option value="">Todas as cidades</option>';
            
            this.data.forEach(city => {
                const option = document.createElement('option');
                option.value = city.id;
                option.textContent = city.name;
                select.appendChild(option);
            });
            
            // Restaurar valor se ainda existir
            if (currentValue && this.data.find(c => c.id === currentValue)) {
                select.value = currentValue;
            }
        });
    },

    // Mudar cidade atual do usuário
    changeCity(cityId) {
        this.currentCity = cityId;
        
        if (cityId) {
            localStorage.setItem('redepromo_city', cityId);
            const city = this.data.find(c => c.id === cityId);
            
            // Atualizar texto do hero
            const heroCityText = document.getElementById('heroCityText');
            if (heroCityText && city) {
                heroCityText.textContent = `em ${city.name}`;
            }
            
            // Atualizar dropdown do usuário
            const dropdownCity = document.querySelector('#dropdownCity span');
            if (dropdownCity && city) {
                dropdownCity.textContent = city.name;
            }
            
            Utils.showToast('Cidade alterada', `Mostrando promoções de ${city?.name || 'todas as cidades'}`);
        } else {
            localStorage.removeItem('redepromo_city');
            const heroCityText = document.getElementById('heroCityText');
            if (heroCityText) {
                heroCityText.textContent = 'na sua cidade';
            }
            Utils.showToast('Cidade alterada', 'Mostrando todas as cidades');
        }
        
        // Recarregar lojas filtradas
        if (window.Stores) {
            window.Stores.renderAll();
            window.Stores.renderPromoStores();
            window.Stores.renderDestaques();
        }
        
        this.notifyListeners();
    },

    // Carregar cidade salva
    loadCurrentCity() {
        const saved = localStorage.getItem('redepromo_city');
        if (saved) {
            this.currentCity = saved;
            
            // Atualizar selects
            setTimeout(() => {
                const navSelector = document.getElementById('navCitySelector');
                const mobileSelector = document.getElementById('mobileCitySelector');
                if (navSelector) navSelector.value = saved;
                if (mobileSelector) mobileSelector.value = saved;
            }, 1000);
        }
    },

    // Adicionar listener de mudança
    onChange(callback) {
        this.listeners.push(callback);
    },

    // Notificar listeners
    notifyListeners() {
        this.listeners.forEach(cb => cb(this.currentCity, this.data));
    },

    // Criar nova cidade (admin)
    async create(cityData) {
        try {
            const id = Utils.slugify(cityData.name);
            await setDoc(doc(db, 'cities', id), {
                name: cityData.name,
                state: cityData.state || '',
                active: true,
                createdAt: new Date(),
                ...cityData
            });
            
            Utils.showToast('Sucesso', `Cidade ${cityData.name} criada!`);
            return true;
        } catch (error) {
            console.error('Erro ao criar cidade:', error);
            Utils.showToast('Erro', 'Não foi possível criar a cidade', 'error');
            return false;
        }
    },

    // Deletar cidade (admin)
    async delete(cityId) {
        try {
            // Verificar se há lojas na cidade
            const storesSnapshot = await getDocs(collection(db, 'stores'));
            const storesInCity = storesSnapshot.docs.filter(d => d.data().cityId === cityId);
            
            if (storesInCity.length > 0) {
                Utils.showToast('Erro', `Não pode deletar: ${storesInCity.length} lojas nesta cidade`, 'error');
                return false;
            }
            
            await deleteDoc(doc(db, 'cities', cityId));
            Utils.showToast('Sucesso', 'Cidade removida');
            return true;
        } catch (error) {
            console.error('Erro ao deletar cidade:', error);
            Utils.showToast('Erro', 'Não foi possível remover a cidade', 'error');
            return false;
        }
    },

    // Renderizar lista para admin
    renderAdminList(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        if (this.data.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-city text-3xl mb-3"></i>
                    <p>Nenhuma cidade cadastrada</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = `
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Cidade</th>
                            <th>Estado</th>
                            <th>Lojas</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${this.data.map(city => `
                            <tr>
                                <td class="font-medium">${city.name}</td>
                                <td>${city.state || '-'}</td>
                                <td>
                                    <span class="px-2 py-1 rounded-full bg-primary/20 text-primary text-xs">
                                        ${city.storeCount || 0} lojas
                                    </span>
                                </td>
                                <td>
                                    <button onclick="Cities.delete('${city.id}')" 
                                            class="text-red-400 hover:text-red-300 p-2">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    },

    // Formulário para criar cidade (admin)
    renderCreateForm(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        container.innerHTML = `
            <div class="glass rounded-xl p-6 border border-gray-700">
                <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
                    <i class="fas fa-plus-circle text-primary"></i>
                    Nova Cidade
                </h3>
                <form onsubmit="Cities.handleCreate(event)" class="space-y-4">
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Nome da Cidade *</label>
                            <input type="text" name="cityName" required 
                                   class="input-field w-full rounded-xl px-4 py-3"
                                   placeholder="Ex: São Paulo">
                        </div>
                        <div>
                            <label class="form-label">Estado *</label>
                            <input type="text" name="cityState" required 
                                   class="input-field w-full rounded-xl px-4 py-3"
                                   placeholder="Ex: SP">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-full">
                        <i class="fas fa-save mr-2"></i> Criar Cidade
                    </button>
                </form>
            </div>
        `;
    },

    // Handler do formulário
    async handleCreate(e) {
        e.preventDefault();
        const form = e.target;
        const btn = form.querySelector('button[type="submit"]');
        
        btn.classList.add('btn-loading');
        
        const success = await this.create({
            name: form.cityName.value,
            state: form.cityState.value.toUpperCase()
        });
        
        btn.classList.remove('btn-loading');
        
        if (success) {
            form.reset();
        }
    },

    // Filtrar lojas por cidade
    filterStoresByCity(stores, cityId = this.currentCity) {
        if (!cityId) return stores;
        return stores.filter(s => s.cityId === cityId);
    }
};

// Exportar global
window.Cities = Cities;
export default Cities;