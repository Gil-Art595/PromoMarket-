// ==========================================
// INTERFACE DE ALUGUEL - ADMIN E OWNER
// ==========================================

import RentalManager from './rental-manager.js';

const RentalUI = {
    // ==========================================
    // PAINEL ADMIN - CONFIGURAR ALUGUEL POR LOJA
    // ==========================================
    
    renderAdminRentalConfig(container, storeId) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="glass rounded-xl p-6">
                    <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
                        <i class="fas fa-cog text-primary"></i>
                        Configurar Aluguel da Loja
                    </h3>
                    
                    <form id="rentalConfigForm" class="space-y-4">
                        <div class="grid md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Valor Mensal (R$)</label>
                                <input type="number" id="rentalAmount" step="0.01" required
                                       class="input-field w-full rounded-xl px-4 py-3"
                                       placeholder="99.90">
                            </div>
                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Dia do Vencimento</label>
                                <input type="number" id="rentalDueDay" min="1" max="28" required
                                       class="input-field w-full rounded-xl px-4 py-3"
                                       placeholder="5">
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Descrição</label>
                            <input type="text" id="rentalDescription"
                                   class="input-field w-full rounded-xl px-4 py-3"
                                   placeholder="Aluguel mensal RedePromo">
                        </div>
                        
                        <div class="flex items-center gap-4">
                            <label class="toggle">
                                <input type="checkbox" id="rentalEnabled" checked>
                                <span class="toggle-slider"></span>
                                <span class="ml-3 text-sm">Aluguel Ativo</span>
                            </label>
                            
                            <label class="toggle">
                                <input type="checkbox" id="rentalAuto" checked>
                                <span class="toggle-slider"></span>
                                <span class="ml-3 text-sm">Gerar Automático</span>
                            </label>
                        </div>
                        
                        <div class="flex gap-3 pt-4">
                            <button type="submit" class="btn btn-primary flex-1">
                                <i class="fas fa-save mr-2"></i> Salvar Configuração
                            </button>
                            <button type="button" onclick="RentalUI.generateNow('${storeId}')" 
                                    class="btn btn-secondary">
                                <i class="fas fa-plus"></i> Gerar Agora
                            </button>
                        </div>
                    </form>
                </div>
                
                <!-- Histórico de cobranças -->
                <div class="glass rounded-xl p-6">
                    <h3 class="font-bold text-lg mb-4">Histórico de Cobranças</h3>
                    <div id="rentalHistory" class="space-y-2">
                        <p class="text-gray-400 text-center py-4">Carregando...</p>
                    </div>
                </div>
            </div>
        `;
        
        // Carregar config atual
        this.loadRentalConfig(storeId);
        
        // Setup form
        document.getElementById('rentalConfigForm').onsubmit = (e) => {
            e.preventDefault();
            this.saveRentalConfig(storeId);
        };
        
        // Carregar histórico
        this.loadRentalHistory(storeId);
    },
    
    async loadRentalConfig(storeId) {
        const config = await RentalManager.getRentalConfig(storeId);
        if (config) {
            document.getElementById('rentalAmount').value = config.amount;
            document.getElementById('rentalDueDay').value = config.dueDay;
            document.getElementById('rentalDescription').value = config.description || '';
            document.getElementById('rentalEnabled').checked = config.enabled;
            document.getElementById('rentalAuto').checked = config.autoGenerate;
        }
    },
    
    async saveRentalConfig(storeId) {
        const btn = event.target.querySelector('button[type="submit"]');
        btn.classList.add('btn-loading');
        
        const result = await RentalManager.saveRentalConfig(storeId, {
            amount: document.getElementById('rentalAmount').value,
            dueDay: document.getElementById('rentalDueDay').value,
            description: document.getElementById('rentalDescription').value,
            enabled: document.getElementById('rentalEnabled').checked,
            autoGenerate: document.getElementById('rentalAuto').checked
        });
        
        btn.classList.remove('btn-loading');
        
        if (window.AdminSecurity) {
            AdminSecurity.showToast(
                result.success ? 'Sucesso' : 'Erro',
                result.message,
                result.success ? 'success' : 'error'
            );
        }
    },
    
    async generateNow(storeId) {
        if (!confirm('Gerar cobrança para este mês?')) return;
        
        const result = await RentalManager.generateRentalInvoice(storeId);
        
        if (window.AdminSecurity) {
            AdminSecurity.showToast(
                result.success ? 'Sucesso' : 'Erro',
                result.message,
                result.success ? 'success' : 'error'
            );
        }
        
        if (result.success) {
            this.loadRentalHistory(storeId);
        }
    },
    
    async loadRentalHistory(storeId) {
        const container = document.getElementById('rentalHistory');
        // Implementar busca no Firestore
        container.innerHTML = '<p class="text-gray-400 text-center">Funcionalidade em desenvolvimento</p>';
    },
    
    // ==========================================
    // PAINEL OWNER - LOJISTA VER E PAGAR
    // ==========================================
    
    renderOwnerRentals(container, storeId) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between">
                    <h3 class="font-bold text-lg flex items-center gap-2">
                        <i class="fas fa-money-bill-wave text-primary"></i>
                        Meu Aluguel
                    </h3>
                    <button onclick="RentalUI.syncRentals('${storeId}')" class="text-sm text-primary">
                        <i class="fas fa-sync-alt"></i> Atualizar
                    </button>
                </div>
                
                <div id="currentRental" class="glass rounded-xl p-6">
                    <p class="text-gray-400 text-center">Carregando...</p>
                </div>
                
                <div class="glass rounded-xl p-6">
                    <h4 class="font-medium mb-4">Histórico de Pagamentos</h4>
                    <div id="rentalHistoryOwner" class="space-y-2">
                        <p class="text-gray-400 text-center py-4">Carregando...</p>
                    </div>
                </div>
            </div>
        `;
        
        this.loadCurrentRental(storeId);
        this.loadOwnerHistory(storeId);
    },
    
    async loadCurrentRental(storeId) {
        const container = document.getElementById('currentRental');
        
        try {
            // Buscar cobrança atual (mês atual)
            const currentMonth = new Date().toISOString().slice(0, 7);
            const { query, where, getDocs, collection } = await import("https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js");
            
            const q = query(
                collection(window.firebaseDb || window.firebaseDbAdmin, 'rentals'),
                where('storeId', '==', storeId),
                where('month', '==', currentMonth)
            );
            
            const snapshot = await getDocs(q);
            
            if (snapshot.empty) {
                container.innerHTML = `
                    <div class="text-center py-6">
                        <i class="fas fa-check-circle text-green-400 text-4xl mb-3"></i>
                        <p class="text-gray-300">Nenhuma cobrança para este mês</p>
                        <p class="text-sm text-gray-500 mt-1">Você está em dia!</p>
                    </div>
                `;
                return;
            }
            
            const rental = snapshot.docs[0].data();
            const statusColors = {
                paid: 'text-green-400',
                pending: 'text-yellow-400',
                overdue: 'text-red-400'
            };
            
            container.innerHTML = `
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <p class="text-sm text-gray-400">Mês de referência</p>
                        <p class="font-bold text-lg">${rental.month}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-sm text-gray-400">Valor</p>
                        <p class="font-bold text-2xl text-primary">R$ ${rental.amount?.toFixed(2)}</p>
                    </div>
                </div>
                
                <div class="flex items-center justify-between mb-4 p-3 bg-gray-800/50 rounded-lg">
                    <span class="text-sm text-gray-400">Status</span>
                    <span class="font-bold ${statusColors[rental.status] || 'text-gray-400'}">
                        ${rental.status?.toUpperCase()}
                    </span>
                </div>
                
                ${rental.status !== 'paid' ? `
                    <div class="space-y-3">
                        <p class="text-sm text-gray-400 mb-2">Pagar com:</p>
                        
                        ${rental.pixQrCode ? `
                            <button onclick="RentalUI.showPix('${snapshot.docs[0].id}')" 
                                    class="w-full py-3 bg-green-500/20 text-green-400 rounded-xl font-medium flex items-center justify-center gap-2">
                                <i class="fas fa-qrcode"></i> PIX
                            </button>
                        ` : ''}
                        
                        ${rental.invoiceUrl ? `
                            <a href="${rental.invoiceUrl}" target="_blank"
                               class="w-full py-3 bg-blue-500/20 text-blue-400 rounded-xl font-medium flex items-center justify-center gap-2">
                                <i class="fas fa-external-link-alt"></i> Pagar no Asaas
                            </a>
                        ` : ''}
                        
                        ${rental.bankSlipUrl ? `
                            <a href="${rental.bankSlipUrl}" target="_blank"
                               class="w-full py-3 bg-gray-500/20 text-gray-400 rounded-xl font-medium flex items-center justify-center gap-2">
                                <i class="fas fa-barcode"></i> Boleto
                            </a>
                        ` : ''}
                    </div>
                ` : `
                    <div class="text-center py-4">
                        <i class="fas fa-check-circle text-green-400 text-3xl mb-2"></i>
                        <p class="text-green-400 font-medium">Pagamento confirmado!</p>
                        ${rental.paidAt ? `
                            <p class="text-sm text-gray-500 mt-1">
                                Pago em: ${new Date(rental.paidAt.toDate()).toLocaleDateString('pt-BR')}
                            </p>
                        ` : ''}
                    </div>
                `}
            `;
            
        } catch (error) {
            console.error('Erro:', error);
            container.innerHTML = `<p class="text-red-400 text-center">Erro ao carregar</p>`;
        }
    },
    
    showPix(rentalId) {
        // Mostrar modal com QR Code PIX
        alert('Funcionalidade PIX em desenvolvimento');
    },
    
    async syncRentals(storeId) {
        // Sincronizar status com Asaas
        alert('Sincronizando...');
    },
    
    async loadOwnerHistory(storeId) {
        const container = document.getElementById('rentalHistoryOwner');
        container.innerHTML = '<p class="text-gray-400 text-center">Histórico em desenvolvimento</p>';
    }
};

export default RentalUI;
window.RentalUI = RentalUI;