// ==========================================
// CONFIGURAÇÃO FIREBASE - REDEPROMO
// ==========================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-auth.js";
import { getFirestore, enableIndexedDbPersistence } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-storage.js";

// Configuração do seu projeto
const firebaseConfig = {
    apiKey: "AIzaSyAQ58oORwzmU2S39DQMUxHNZpiMvglStdA",
    authDomain: "promomarket-gill.firebaseapp.com",
    projectId: "promomarket-gill",
    storageBucket: "promomarket-gill.firebasestorage.app",
    messagingSenderId: "304705286483",
    appId: "1:304705286483:web:c6d40c6e48b3fa1b9a31a6"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// Habilitar persistência offline
try {
    enableIndexedDbPersistence(db);
    console.log("✅ Persistência offline ativada");
} catch (err) {
    console.log("ℹ️ Persistência já habilitada ou não suportada");
}

// Exportar para uso global
window.firebaseApp = app;
window.firebaseAuth = auth;
window.firebaseDb = db;
window.firebaseStorage = storage;

// Exportar módulos
export { app, auth, db, storage };

console.log("🔥 Firebase inicializado - RedePromo");