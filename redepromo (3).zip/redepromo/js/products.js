// ==========================================
// PRODUTOS E OTIMIZAÇÃO DE IMAGEM
// ==========================================

import { doc, updateDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";
import { ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-storage.js";

const db = window.firebaseDb;
const storage = window.firebaseStorage;

// Configuração de compressão de imagem
const IMAGE_CONFIG = {
    maxSizeMB: 0.4,
    maxWidthOrHeight: 800,
    useWebWorker: true,
    fileType: 'image/jpeg',
    initialQuality: 0.7
};

const Products = {
    currentEditing: null,
    tempVariations: [],
    tempPromotions: [],

    // Preview de imagem otimizada
    async previewImage(event) {
        const file = event.target.files[0];
        if (!file) return;

        if (!file.type.startsWith('image/')) {
            Utils.showToast('Erro', 'Arquivo deve ser uma imagem', 'error');
            event.target.value = '';
            return;
        }

        if (file.size > 10 * 1024 * 1024) {
            Utils.showToast('Erro', 'Imagem muito grande. Máximo 10MB.', 'error');
            event.target.value = '';
            return;
        }

        // Preview rápido
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById('editProductImagePreview');
            if (preview) {
                preview.src = e.target.result;
                preview.dataset.hasNewImage = 'true';
            }
        };
        reader.readAsDataURL(file);

        Utils.showToast('Info', 'Otimizando imagem...', 'info');
    },

    // Limpar imagem
    clearImage() {
        const input = document.getElementById('editProductImage');
        const preview = document.getElementById('editProductImagePreview');

        if (input) input.value = '';
        if (preview) {
            preview.src = 'https://via.placeholder.com/400x400?text=Clique+para+adicionar+foto';
            preview.dataset.hasNewImage = 'false';
        }
    },

    // Otimizar e fazer upload da imagem
    async optimizeAndUpload(file) {
        console.log('📸 Original:', (file.size / 1024).toFixed(2), 'KB');

        let compressedFile;
        try {
            compressedFile = await imageCompression(file, IMAGE_CONFIG);
            console.log('✅ Comprimida:', (compressedFile.size / 1024).toFixed(2), 'KB');
        } catch (error) {
            console.error('❌ Erro compressão:', error);
            compressedFile = file;
        }

        const base64 = await Utils.fileToBase64(compressedFile);
        const base64Size = Utils.base64Size(base64);

        console.log('📊 Base64 size:', (base64Size / 1024).toFixed(2), 'KB');

        if (base64Size < 400 * 1024) {
            console.log('💚 GRÁTIS: Usando Base64 no Firestore');
            return {
                url: base64,
                provider: 'base64-free',
                size: base64Size,
                savings: '100%'
            };
        } else {
            console.log('💛 Storage: Enviando otimizada');
            return await this.uploadToStorage(compressedFile);
        }
    },

    // Upload para Firebase Storage
    async uploadToStorage(file) {
        const storageRef = ref(storage, `products/${Date.now()}_${Math.random().toString(36).substr(2, 9)}.jpg`);
        await uploadBytes(storageRef, file);
        const url = await getDownloadURL(storageRef);

        return {
            url: url,
            path: storageRef.fullPath,
            provider: 'firebase-storage',
            size: file.size
        };
    },

    // Abrir modal de edição
    openEditModal(product = null, storeId = null) {
        this.currentEditing = product;
        this.tempVariations = product?.variations ? [...product.variations] : [];
        this.tempPromotions = product?.promotions ? [...product.promotions] : [];

        const modal = document.getElementById('editProductModal');
        const title = document.getElementById('editProductModalTitle');
        const form = document.getElementById('editProductForm');

        title.textContent = product ? 'Editar Produto' : 'Novo Produto';

        // Preencher campos
        document.getElementById('editProductId').value = product?.id || '';
        document.getElementById('editProductName').value = product?.name || '';
        document.getElementById('editProductCategory').value = product?.category || 'geral';
        document.getElementById('editProductPrice').value = product?.price || '';
        document.getElementById('editProductOldPrice').value = product?.oldPrice || '';
        document.getElementById('editProductStock').value = product?.stock || '';
        document.getElementById('editProductDescription').value = product?.description || '';

        // Imagem
        const preview = document.getElementById('editProductImagePreview');
        preview.src = product?.image || 'https://via.placeholder.com/400x400?text=Clique+para+adicionar+foto';
        preview.dataset.hasNewImage = 'false';

        // Renderizar variações e promoções
        this.renderVariations();
        this.renderPromotions();

        modal.classList.remove('hidden');
        setTimeout(() => {
            document.getElementById('editProductModalContent').classList.add('show');
        }, 10);
    },

    // Fechar modal
    closeEditModal() {
        const modal = document.getElementById('editProductModal');
        const content = document.getElementById('editProductModalContent');
        
        content.classList.remove('show');
        setTimeout(() => {
            modal.classList.add('hidden');
            this.currentEditing = null;
            this.tempVariations = [];
            this.tempPromotions = [];
        }, 300);
    },

    // ✅ CORREÇÃO: Salvar produto sem serverTimestamp no array
    async handleSave(e) {
        e.preventDefault();

        const btn = e.target.querySelector('button[type="submit"]');
        btn.classList.add('btn-loading');

        try {
            const fileInput = document.getElementById('editProductImage');
            const preview = document.getElementById('editProductImagePreview');
            const productId = document.getElementById('editProductId').value;

            let imageUrl = preview?.src || 'https://via.placeholder.com/400x400?text=Produto';
            let imageProvider = 'url';

            // Processar nova imagem
            if (fileInput?.files?.[0] && preview?.dataset?.hasNewImage === 'true') {
                const uploadResult = await this.optimizeAndUpload(fileInput.files[0]);
                imageUrl = uploadResult.url;
                imageProvider = uploadResult.provider;

                if (uploadResult.provider === 'base64-free') {
                    Utils.showToast('Sucesso', 'Imagem otimizada (100% GRÁTIS!)', 'success');
                } else {
                    Utils.showToast('Sucesso', 'Imagem enviada otimizada', 'success');
                }
            }

            const isNew = !productId;
            
            // ✅ CORREÇÃO: Usar new Date().toISOString() em vez de serverTimestamp() dentro do array
            const productData = {
                id: isNew ? Utils.generateId() : productId,
                name: document.getElementById('editProductName').value.trim(),
                category: document.getElementById('editProductCategory').value,
                price: parseFloat(document.getElementById('editProductPrice').value) || 0,
                oldPrice: parseFloat(document.getElementById('editProductOldPrice').value) || null,
                stock: parseInt(document.getElementById('editProductStock').value) || 0,
                description: document.getElementById('editProductDescription').value.trim(),
                image: imageUrl,
                imageProvider: imageProvider,
                variations: this.tempVariations,
                promotions: this.tempPromotions,
                updatedAt: new Date().toISOString()  // ✅ Data normal, não serverTimestamp
            };

            if (!productData.name) throw new Error('Nome do produto é obrigatório');
            if (productData.price <= 0) throw new Error('Preço deve ser maior que zero');

            const store = window.currentUserStore;
            if (!store) throw new Error('Sem loja selecionada');

            const items = [...(store.items || [])];

            if (isNew) {
                items.push(productData);
            } else {
                const index = items.findIndex(i => i.id === productId);
                if (index !== -1) items[index] = productData;
            }

            // ✅ serverTimestamp() só aqui, fora do array
            await updateDoc(doc(db, 'stores', store.id), {
                items,
                updatedAt: serverTimestamp()  // ✅ Aqui pode usar serverTimestamp!
            });

            // Atualizar flag de promoção da loja
            const hasActivePromo = items.some(i => i.promotions?.some(p => p.active));
            if (hasActivePromo !== store.hasPromotion) {
                await updateDoc(doc(db, 'stores', store.id), { hasPromotion: hasActivePromo });
            }

            Utils.showToast('Sucesso', isNew ? 'Produto criado!' : 'Produto atualizado!');
            this.closeEditModal();
            
            if (window.Owner) {
                window.Owner.showTab('products');
            }

        } catch (error) {
            console.error('❌ Erro:', error);
            Utils.showToast('Erro', error.message || 'Falha ao salvar', 'error');
        } finally {
            btn.classList.remove('btn-loading');
        }
    },

    // Adicionar variação
    addVariation() {
        const name = prompt('Nome da variação (ex: Tamanho, Cor):');
        if (!name) return;

        const options = prompt('Opções separadas por vírgula (ex: P, M, G):');
        if (!options) return;

        this.tempVariations.push({
            name: name.trim(),
            options: options.split(',').map(o => o.trim())
        });

        this.renderVariations();
    },

    // Remover variação
    removeVariation(index) {
        this.tempVariations.splice(index, 1);
        this.renderVariations();
    },

    // Renderizar variações
    renderVariations() {
        const container = document.getElementById('productVariations');
        if (!container) return;

        if (this.tempVariations.length === 0) {
            container.innerHTML = '<p class="text-gray-500 text-sm">Nenhuma variação</p>';
            return;
        }

        container.innerHTML = this.tempVariations.map((v, i) => `
            <div class="flex items-center justify-between p-2 bg-gray-800/50 rounded-lg">
                <div>
                    <span class="font-medium text-sm">${v.name}</span>
                    <span class="text-gray-400 text-xs ml-2">${v.options.join(', ')}</span>
                </div>
                <button onclick="Products.removeVariation(${i})" class="text-red-400 hover:text-red-300">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `).join('');
    },

    // Adicionar promoção
    addPromotion() {
        const highlight = prompt('Destaque da promoção (ex: 20% OFF, Leve 3 Pague 2):');
        if (!highlight) return;

        const discount = prompt('Valor do desconto em % (número apenas):');
        if (!discount || isNaN(discount)) return;

        this.tempPromotions.push({
            id: Utils.generateId(),
            highlight: highlight.trim(),
            discount: parseInt(discount),
            active: true,
            startDate: new Date().toISOString(),
            endDate: null
        });

        this.renderPromotions();
    },

    // Remover promoção
    removePromotion(index) {
        this.tempPromotions.splice(index, 1);
        this.renderPromotions();
    },

    // Toggle promoção ativa
    togglePromotion(index) {
        this.tempPromotions[index].active = !this.tempPromotions[index].active;
        this.renderPromotions();
    },

    // Renderizar promoções
    renderPromotions() {
        const container = document.getElementById('productPromotionsList');
        const noMsg = document.getElementById('noPromotionsMsg');
        
        if (!container) return;

        if (this.tempPromotions.length === 0) {
            container.innerHTML = '';
            noMsg?.classList.remove('hidden');
            return;
        }

        noMsg?.classList.add('hidden');

        container.innerHTML = this.tempPromotions.map((p, i) => `
            <div class="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border ${p.active ? 'border-orange-500/30' : 'border-gray-700'}">
                <div class="flex items-center gap-3">
                    <button onclick="Products.togglePromotion(${i})" class="${p.active ? 'text-green-400' : 'text-gray-500'}">
                        <i class="fas ${p.active ? 'fa-check-circle' : 'fa-circle'}"></i>
                    </button>
                    <div>
                        <span class="font-medium text-sm ${p.active ? 'text-orange-400' : 'text-gray-400'}">${p.highlight}</span>
                        <span class="text-gray-500 text-xs ml-2">${p.discount}% OFF</span>
                    </div>
                </div>
                <button onclick="Products.removePromotion(${i})" class="text-red-400 hover:text-red-300">
                    <i class="fas fa-trash text-xs"></i>
                </button>
            </div>
        `).join('');
    },

    // Deletar produto
    async delete(productId, storeId) {
        if (!confirm('Tem certeza que deseja excluir este produto?')) return;

        try {
            const store = window.currentUserStore;
            if (!store) throw new Error('Sem loja');

            const items = store.items.filter(i => i.id !== productId);

            // ✅ serverTimestamp fora do array
            await updateDoc(doc(db, 'stores', store.id), {
                items,
                updatedAt: serverTimestamp()
            });

            Utils.showToast('Sucesso', 'Produto removido');
            
            if (window.Owner) {
                window.Owner.showTab('products');
            }

        } catch (error) {
            Utils.showToast('Erro', 'Erro ao remover produto', 'error');
        }
    }
};

window.Products = Products;
export default Products;