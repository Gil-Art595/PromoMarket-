// ==========================================
// PAINEL DO LOJISTA - REDEPROMO (COMPLETO)
// ==========================================

import { doc, getDoc, updateDoc, serverTimestamp, collection, query, where, onSnapshot, orderBy } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const db = window.firebaseDb;

const Owner = {
    currentTab: 'overview',
    store: null,
    ordersUnsubscribe: null,
    chatsUnsubscribe: null,

    async toggle() {
        const modal = document.getElementById('ownerModal');
        
        if (modal.classList.contains('hidden')) {
            if (!window.currentUserStore) {
                Utils.showToast('Erro', 'Você não tem uma loja cadastrada', 'error');
                return;
            }
            
            // Recarregar dados frescos da loja
            await this.refreshStoreData();
            
            modal.classList.remove('hidden');
            setTimeout(() => {
                document.getElementById('ownerModalContent').classList.add('show');
            }, 10);
            
            this.showTab('overview');
        } else {
            this.closeModal();
        }
    },

    closeModal() {
        const modal = document.getElementById('ownerModal');
        const content = document.getElementById('ownerModalContent');
        
        // Limpar listeners
        if (this.ordersUnsubscribe) {
            this.ordersUnsubscribe();
            this.ordersUnsubscribe = null;
        }
        if (this.chatsUnsubscribe) {
            this.chatsUnsubscribe();
            this.chatsUnsubscribe = null;
        }
        
        content.classList.remove('show');
        setTimeout(() => {
            modal.classList.add('hidden');
        }, 300);
    },

    async refreshStoreData() {
        try {
            const storeDoc = await getDoc(doc(db, 'stores', Auth.userData.storeId));
            if (storeDoc.exists()) {
                this.store = { id: storeDoc.id, ...storeDoc.data() };
                window.currentUserStore = this.store;
                
                const nameEl = document.getElementById('ownerStoreName');
                if (nameEl) nameEl.textContent = this.store.name;
            }
        } catch (error) {
            console.error('Erro ao carregar loja:', error);
        }
    },

    showTab(tab) {
        this.currentTab = tab;
        
        // Atualizar sidebar
        document.querySelectorAll('.owner-tab').forEach(t => {
            t.classList.remove('active', 'text-white', 'border-l-4', 'border-primary', 'bg-primary/10');
            t.classList.add('text-gray-300');
        });
        
        const activeTab = document.querySelector(`.owner-tab[data-tab="${tab}"]`);
        if (activeTab) {
            activeTab.classList.add('active', 'text-white', 'border-l-4', 'border-primary', 'bg-primary/10');
            activeTab.classList.remove('text-gray-300');
        }
        
        const content = document.getElementById('ownerContent');
        if (!content) return;
        
        switch(tab) {
            case 'overview':
                this.renderOverview(content);
                break;
            case 'products':
                this.renderProducts(content);
                break;
            case 'orders':
                this.renderOrders(content);
                break;
            case 'chats':
                this.renderChats(content);
                break;
            case 'delivery':
                this.renderDeliverySettings(content);
                break;
            case 'coupons':
                this.renderCoupons(content);
                break;
            case 'reports':
                this.renderReports(content);
                break;
            case 'editstore':
                this.renderEditStore(content);
                break;
            case 'payments':
                this.renderPaymentSettings(content);
                break;
        }
    },

    renderOverview(container) {
        const totalSales = this.store.totalSales || 0;
        const totalOrders = this.store.totalOrders || 0;
        const pendingOrders = (this.store.orders || []).filter(o => o.status === 'pending').length;
        const totalProducts = this.store.items?.length || 0;
        const activePromos = this.store.items?.reduce((acc, item) => 
            acc + (item.promotions?.filter(p => p.active).length || 0), 0) || 0;
        
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between">
                    <h2 class="text-2xl font-bold">Visão Geral</h2>
                    <span class="text-sm text-gray-400">Última atualização: ${new Date().toLocaleTimeString()}</span>
                </div>
                
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div class="glass rounded-2xl p-6 text-center hover:bg-white/5 transition-colors">
                        <div class="text-3xl font-bold text-green-400 mb-1">R$ ${totalSales.toFixed(2)}</div>
                        <div class="text-sm text-gray-400">Total em Vendas</div>
                    </div>
                    <div class="glass rounded-2xl p-6 text-center hover:bg-white/5 transition-colors">
                        <div class="text-3xl font-bold text-primary mb-1">${totalOrders}</div>
                        <div class="text-sm text-gray-400">Pedidos Totais</div>
                    </div>
                    <div class="glass rounded-2xl p-6 text-center hover:bg-white/5 transition-colors">
                        <div class="text-3xl font-bold text-orange-400 mb-1">${pendingOrders}</div>
                        <div class="text-sm text-gray-400">Pendentes</div>
                    </div>
                    <div class="glass rounded-2xl p-6 text-center hover:bg-white/5 transition-colors">
                        <div class="text-3xl font-bold text-accent mb-1">${totalProducts}</div>
                        <div class="text-sm text-gray-400">Produtos</div>
                    </div>
                </div>

                <!-- Ações Rápidas -->
                <div class="glass rounded-2xl p-6">
                    <h3 class="font-bold text-lg mb-4">Ações Rápidas</h3>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <button onclick="Owner.showTab('products'); Products.openEditModal()" class="p-4 glass rounded-xl hover:bg-primary/20 transition-colors text-center">
                            <i class="fas fa-plus text-2xl text-primary mb-2"></i>
                            <p class="text-sm">Novo Produto</p>
                        </button>
                        <button onclick="Owner.showTab('coupons')" class="p-4 glass rounded-xl hover:bg-orange-500/20 transition-colors text-center">
                            <i class="fas fa-ticket-alt text-2xl text-orange-400 mb-2"></i>
                            <p class="text-sm">Criar Cupom</p>
                        </button>
                        <button onclick="Owner.showTab('chats')" class="p-4 glass rounded-xl hover:bg-green-500/20 transition-colors text-center">
                            <i class="fas fa-comments text-2xl text-green-400 mb-2"></i>
                            <p class="text-sm">Ver Conversas</p>
                        </button>
                        <button onclick="Owner.showTab('reports')" class="p-4 glass rounded-xl hover:bg-purple-500/20 transition-colors text-center">
                            <i class="fas fa-chart-line text-2xl text-purple-400 mb-2"></i>
                            <p class="text-sm">Relatórios</p>
                        </button>
                    </div>
                </div>

                <!-- Produtos em Destaque -->
                <div class="glass rounded-2xl p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="font-bold text-lg">Seus Produtos</h3>
                        <button onclick="Owner.showTab('products')" class="text-sm text-primary hover:text-white">Ver todos →</button>
                    </div>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        ${this.store.items?.slice(0, 4).map(item => {
                            const activePromos = item.promotions?.filter(p => p.active) || [];
                            return `
                                <div class="glass rounded-xl overflow-hidden group cursor-pointer" onclick="Owner.showTab('products')">
                                    <div class="relative h-24 overflow-hidden">
                                        <img src="${item.image}" class="w-full h-full object-cover transition-transform group-hover:scale-110">
                                        ${activePromos.length > 0 ? `
                                            <div class="absolute top-1 left-1 bg-orange-500 text-white text-[10px] font-bold px-2 py-0.5 rounded">
                                                ${activePromos[0].highlight}
                                            </div>
                                        ` : ''}
                                    </div>
                                    <div class="p-2">
                                        <p class="text-sm font-medium truncate">${item.name}</p>
                                        <p class="text-xs text-primary">R$ ${item.price.toFixed(2)}</p>
                                        <p class="text-xs text-gray-500">Estoque: ${item.stock}</p>
                                    </div>
                                </div>
                            `;
                        }).join('') || '<p class="text-gray-500 col-span-full text-center py-4">Nenhum produto cadastrado</p>'}
                    </div>
                    ${(this.store.items?.length || 0) > 4 ? `<p class="text-center mt-4 text-sm text-gray-400">+${this.store.items.length - 4} produtos</p>` : ''}
                </div>

                <!-- Últimos Pedidos -->
                <div class="glass rounded-2xl p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="font-bold text-lg">Últimos Pedidos</h3>
                        <button onclick="Owner.showTab('orders')" class="text-sm text-primary hover:text-white">Ver todos →</button>
                    </div>
                    ${(this.store.orders || []).slice(0, 5).length > 0 ? `
                        <div class="space-y-2">
                            ${(this.store.orders || []).slice(0, 5).map(order => `
                                <div class="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                                            <i class="fas fa-shopping-bag text-primary"></i>
                                        </div>
                                        <div>
                                            <p class="font-medium text-sm">#${order.id?.slice(-6) || 'N/A'}</p>
                                            <p class="text-xs text-gray-400">${order.customerName || 'Cliente'}</p>
                                        </div>
                                    </div>
                                    <div class="text-right">
                                        <p class="font-medium">R$ ${(order.total || 0).toFixed(2)}</p>
                                        <span class="text-xs px-2 py-0.5 rounded ${this.getStatusClass(order.status)}">${this.getStatusLabel(order.status)}</span>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    ` : '<p class="text-gray-500 text-center py-4">Nenhum pedido ainda</p>'}
                </div>
            </div>
        `;
    },

    renderProducts(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <h2 class="text-2xl font-bold">Meus Produtos</h2>
                    <button onclick="Products.openEditModal()" class="btn btn-primary">
                        <i class="fas fa-plus mr-2"></i> Novo Produto
                    </button>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    ${this.store.items?.map(item => {
                        const activePromos = item.promotions?.filter(p => p.active) || [];
                        const discount = item.oldPrice ? Math.round((1 - item.price/item.oldPrice) * 100) : 0;
                        return `
                            <div class="glass rounded-xl overflow-hidden group hover:ring-2 ring-primary transition-all">
                                <div class="relative h-40 overflow-hidden">
                                    <img src="${item.image}" class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110">
                                    ${discount > 0 ? `<div class="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">-${discount}%</div>` : ''}
                                    ${activePromos.length > 0 ? `<div class="absolute top-2 right-2 bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded animate-pulse">${activePromos[0].highlight}</div>` : ''}
                                    <div class="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                        <button onclick="event.stopPropagation(); Products.openEditModal(${JSON.stringify(item).replace(/"/g, '&quot;')})" class="w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white backdrop-blur-sm">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button onclick="event.stopPropagation(); Owner.deleteProduct('${item.id}')" class="w-10 h-10 rounded-full bg-red-500/20 hover:bg-red-500/30 text-red-400 flex items-center justify-center backdrop-blur-sm">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="p-4">
                                    <h3 class="font-bold mb-1 truncate">${item.name}</h3>
                                    <p class="text-sm text-gray-400 mb-2 line-clamp-2">${item.description || 'Sem descrição'}</p>
                                    <div class="flex items-center gap-2 mb-2">
                                        <span class="text-primary font-bold text-lg">R$ ${item.price.toFixed(2)}</span>
                                        ${item.oldPrice ? `<span class="text-gray-500 text-sm line-through">R$ ${item.oldPrice.toFixed(2)}</span>` : ''}
                                    </div>
                                    <div class="flex items-center justify-between text-sm">
                                        <span class="text-gray-400">Estoque: <span class="${item.stock < 5 ? 'text-red-400' : 'text-green-400'}">${item.stock}</span></span>
                                        <span class="text-gray-500 capitalize">${item.category || 'geral'}</span>
                                    </div>
                                    ${item.variations?.length > 0 ? `
                                        <div class="mt-2 flex flex-wrap gap-1">
                                            ${item.variations.map(v => `
                                                <span class="text-xs px-2 py-1 rounded bg-gray-700 text-gray-300">${v.name}</span>
                                            `).join('')}
                                        </div>
                                    ` : ''}
                                </div>
                            </div>
                        `;
                    }).join('') || `
                        <div class="col-span-full text-center py-12 text-gray-500">
                            <i class="fas fa-box-open text-4xl mb-4 opacity-50"></i>
                            <p class="mb-4">Nenhum produto cadastrado</p>
                            <button onclick="Products.openEditModal()" class="btn btn-primary">
                                <i class="fas fa-plus mr-2"></i> Adicionar primeiro produto
                            </button>
                        </div>
                    `}
                </div>
            </div>
        `;
    },

    async deleteProduct(productId) {
        if (!confirm('Tem certeza que deseja excluir este produto?')) return;
        
        try {
            const items = this.store.items.filter(i => i.id !== productId);
            await updateDoc(doc(db, 'stores', this.store.id), {
                items,
                updatedAt: serverTimestamp()
            });
            
            // Atualizar local
            this.store.items = items;
            window.currentUserStore.items = items;
            
            Utils.showToast('Sucesso', 'Produto removido!');
            this.renderProducts(document.getElementById('ownerContent'));
        } catch (error) {
            console.error('Erro ao excluir:', error);
            Utils.showToast('Erro', 'Erro ao remover produto', 'error');
        }
    },

    renderOrders(container) {
        // Setup realtime listener para pedidos
        if (this.ordersUnsubscribe) {
            this.ordersUnsubscribe();
        }
        
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <h2 class="text-2xl font-bold">Pedidos</h2>
                    <div class="flex gap-2">
                        <select id="orderFilter" onchange="Owner.filterOrders(this.value)" class="input-field rounded-xl px-4 py-2 text-sm">
                            <option value="all">Todos</option>
                            <option value="pending">Pendentes</option>
                            <option value="paid">Pagos</option>
                            <option value="preparing">Em preparo</option>
                            <option value="delivered">Entregues</option>
                        </select>
                    </div>
                </div>
                
                <div id="ordersList" class="space-y-3">
                    <div class="text-center py-12">
                        <i class="fas fa-spinner fa-spin text-3xl text-primary"></i>
                        <p class="mt-4 text-gray-400">Carregando pedidos...</p>
                    </div>
                </div>
            </div>
        `;
        
        // Listener em tempo real
        const ordersQuery = query(
            collection(db, 'orders'),
            where('storeId', '==', this.store.id),
            orderBy('createdAt', 'desc')
        );
        
        this.ordersUnsubscribe = onSnapshot(ordersQuery, (snapshot) => {
            const orders = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
            this.renderOrdersList(orders);
        }, (error) => {
            console.error('Erro ao carregar pedidos:', error);
            document.getElementById('ordersList').innerHTML = `
                <div class="text-center py-12 text-red-400">
                    <i class="fas fa-exclamation-triangle text-3xl mb-4"></i>
                    <p>Erro ao carregar pedidos</p>
                </div>
            `;
        });
    },

    renderOrdersList(orders, filter = 'all') {
        const container = document.getElementById('ordersList');
        if (!container) return;
        
        const filteredOrders = filter === 'all' ? orders : orders.filter(o => o.status === filter);
        
        if (filteredOrders.length === 0) {
            container.innerHTML = `
                <div class="text-center py-12 text-gray-500">
                    <i class="fas fa-shopping-bag text-4xl mb-4 opacity-50"></i>
                    <p>Nenhum pedido ${filter !== 'all' ? 'com este status' : 'ainda'}</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = filteredOrders.map(order => `
            <div class="glass rounded-xl p-4 hover:bg-white/5 transition-colors cursor-pointer" onclick="Owner.viewOrderDetail('${order.id}')">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <div class="flex items-center gap-4">
                        <div class="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                            <i class="fas fa-shopping-bag text-primary text-lg"></i>
                        </div>
                        <div>
                            <p class="font-bold">#${order.id.slice(-6).toUpperCase()}</p>
                            <p class="text-sm text-gray-400">${order.customerName || 'Cliente'}</p>
                            <p class="text-xs text-gray-500">${Utils.formatDate(order.createdAt)}</p>
                        </div>
                    </div>
                    <div class="text-right">
                        <p class="text-xl font-bold text-primary">R$ ${(order.total || 0).toFixed(2)}</p>
                        <span class="inline-block px-3 py-1 rounded-full text-xs font-medium ${this.getStatusClass(order.status)}">
                            ${this.getStatusLabel(order.status)}
                        </span>
                    </div>
                </div>
                <div class="mt-3 pt-3 border-t border-gray-700 flex items-center gap-4 text-sm">
                    <span class="text-gray-400"><i class="fas fa-box mr-1"></i> ${order.productName || 'Produto'}</span>
                    <span class="text-gray-400"><i class="fas ${order.deliveryType === 'delivery' ? 'fa-truck' : 'fa-store'} mr-1"></i> ${order.deliveryType === 'delivery' ? 'Entrega' : 'Retirada'}</span>
                    <span class="text-gray-400"><i class="fas fa-credit-card mr-1"></i> ${this.getPaymentMethodLabel(order.paymentMethod)}</span>
                </div>
            </div>
        `).join('');
    },

    filterOrders(status) {
        // Recarregar com filtro
        const ordersQuery = query(
            collection(db, 'orders'),
            where('storeId', '==', this.store.id),
            orderBy('createdAt', 'desc')
        );
        
        getDocs(ordersQuery).then(snapshot => {
            const orders = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
            this.renderOrdersList(orders, status);
        });
    },

    viewOrderDetail(orderId) {
        const order = this.store.orders?.find(o => o.id === orderId);
        if (!order) {
            Utils.showToast('Erro', 'Pedido não encontrado', 'error');
            return;
        }

        // Criar modal de detalhes
        const modal = document.createElement('div');
        modal.id = 'orderDetailModal';
        modal.className = 'fixed inset-0 z-[90] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4';
        modal.innerHTML = `
            <div class="glass-strong w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl animate-scale-in">
                <div class="sticky top-0 bg-gray-900/95 border-b border-gray-700 p-6 flex items-center justify-between">
                    <h3 class="text-xl font-bold">Pedido #${order.id.slice(-6).toUpperCase()}</h3>
                    <button onclick="document.getElementById('orderDetailModal').remove()" class="w-8 h-8 rounded-full glass hover:bg-white/10 flex items-center justify-center">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <div class="p-6 space-y-6">
                    <!-- Status -->
                    <div class="flex items-center justify-between p-4 bg-gray-800/50 rounded-xl">
                        <span class="text-gray-400">Status</span>
                        <div class="flex items-center gap-3">
                            <select id="orderStatusSelect" class="input-field rounded-lg px-3 py-2 text-sm">
                                <option value="pending" ${order.status === 'pending' ? 'selected' : ''}>Pendente</option>
                                <option value="paid" ${order.status === 'paid' ? 'selected' : ''}>Pago</option>
                                <option value="preparing" ${order.status === 'preparing' ? 'selected' : ''}>Em preparo</option>
                                <option value="shipped" ${order.status === 'shipped' ? 'selected' : ''}>Enviado</option>
                                <option value="delivered" ${order.status === 'delivered' ? 'selected' : ''}>Entregue</option>
                                <option value="cancelled" ${order.status === 'cancelled' ? 'selected' : ''}>Cancelado</option>
                            </select>
                            <button onclick="Owner.updateOrderStatus('${order.id}')" class="btn btn-primary text-sm">
                                <i class="fas fa-save"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Produto -->
                    <div class="flex gap-4 p-4 bg-gray-800/30 rounded-xl">
                        <img src="${order.productImage || 'https://via.placeholder.com/100'}" class="w-20 h-20 object-cover rounded-lg">
                        <div class="flex-1">
                            <p class="font-bold">${order.productName}</p>
                            <p class="text-sm text-gray-400">Preço: R$ ${(order.productPrice || 0).toFixed(2)}</p>
                            ${order.deliveryFee > 0 ? `<p class="text-sm text-gray-400">Entrega: R$ ${order.deliveryFee.toFixed(2)}</p>` : ''}
                            <p class="text-lg font-bold text-primary mt-1">Total: R$ ${(order.total || 0).toFixed(2)}</p>
                        </div>
                    </div>

                    <!-- Cliente -->
                    <div class="space-y-2">
                        <h4 class="font-bold text-sm text-gray-400 uppercase">Dados do Cliente</h4>
                        <div class="p-4 bg-gray-800/30 rounded-xl space-y-2">
                            <p><i class="fas fa-user w-5 text-gray-500"></i> ${order.customerName}</p>
                            <p><i class="fas fa-envelope w-5 text-gray-500"></i> ${order.customerEmail || '-'}</p>
                            <p><i class="fas fa-phone w-5 text-gray-500"></i> ${order.customerPhone || '-'}</p>
                        </div>
                    </div>

                    <!-- Entrega -->
                    <div class="space-y-2">
                        <h4 class="font-bold text-sm text-gray-400 uppercase">Entrega</h4>
                        <div class="p-4 bg-gray-800/30 rounded-xl">
                            <p class="flex items-center gap-2 mb-2">
                                <i class="fas ${order.deliveryType === 'delivery' ? 'fa-truck' : 'fa-store'} text-primary"></i>
                                <span class="font-medium">${order.deliveryType === 'delivery' ? 'Entrega em domicílio' : 'Retirada na loja'}</span>
                            </p>
                            ${order.deliveryAddress ? `
                                <div class="text-sm text-gray-400 mt-2">
                                    <p>${order.deliveryAddress.street}, ${order.deliveryAddress.number}</p>
                                    ${order.deliveryAddress.complement ? `<p>${order.deliveryAddress.complement}</p>` : ''}
                                    <p>${order.deliveryAddress.neighborhood}</p>
                                </div>
                            ` : ''}
                        </div>
                    </div>

                    <!-- Pagamento -->
                    <div class="space-y-2">
                        <h4 class="font-bold text-sm text-gray-400 uppercase">Pagamento</h4>
                        <div class="p-4 bg-gray-800/30 rounded-xl">
                            <p><i class="fas fa-credit-card w-5 text-gray-500"></i> ${this.getPaymentMethodLabel(order.paymentMethod)}</p>
                            ${order.gateway ? `<p class="text-sm text-gray-500 mt-1">Gateway: ${order.gateway}</p>` : ''}
                        </div>
                    </div>

                    <!-- Ações -->
                    <div class="flex gap-3 pt-4">
                        <button onclick="Chat.startChatFromOrder('${order.customerId}', '${order.id}')" class="flex-1 py-3 glass rounded-xl hover:bg-primary/20 text-primary">
                            <i class="fas fa-comment mr-2"></i> Conversar com Cliente
                        </button>
                        <a href="https://wa.me/55${order.customerPhone?.replace(/\D/g, '')}" target="_blank" class="flex-1 py-3 glass rounded-xl hover:bg-green-500/20 text-green-400 text-center">
                            <i class="fab fa-whatsapp mr-2"></i> WhatsApp
                        </a>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
    },

    async updateOrderStatus(orderId) {
        const newStatus = document.getElementById('orderStatusSelect').value;
        
        try {
            // Atualizar na coleção orders
            await updateDoc(doc(db, 'orders', orderId), {
                status: newStatus,
                updatedAt: serverTimestamp()
            });
            
            // Atualizar no array da loja
            const orders = this.store.orders || [];
            const orderIndex = orders.findIndex(o => o.id === orderId);
            if (orderIndex !== -1) {
                orders[orderIndex].status = newStatus;
                await updateDoc(doc(db, 'stores', this.store.id), {
                    orders,
                    updatedAt: serverTimestamp()
                });
            }
            
            Utils.showToast('Sucesso', 'Status atualizado!');
            document.getElementById('orderDetailModal').remove();
            this.refreshStoreData();
        } catch (error) {
            console.error('Erro ao atualizar:', error);
            Utils.showToast('Erro', 'Erro ao atualizar status', 'error');
        }
    },

    renderChats(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <h2 class="text-2xl font-bold">Conversas</h2>
                <div id="chatsList" class="space-y-3">
                    <div class="text-center py-12">
                        <i class="fas fa-spinner fa-spin text-3xl text-primary"></i>
                        <p class="mt-4 text-gray-400">Carregando conversas...</p>
                    </div>
                </div>
            </div>
        `;
        
        // Carregar chats
        if (this.chatsUnsubscribe) {
            this.chatsUnsubscribe();
        }
        
        const chatsQuery = query(
            collection(db, 'chats'),
            where('storeId', '==', this.store.id),
            orderBy('lastMessageAt', 'desc')
        );
        
        this.chatsUnsubscribe = onSnapshot(chatsQuery, (snapshot) => {
            const chats = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
            this.renderChatsList(chats);
        });
    },

    renderChatsList(chats) {
        const container = document.getElementById('chatsList');
        if (!container) return;
        
        if (chats.length === 0) {
            container.innerHTML = `
                <div class="text-center py-12 text-gray-500">
                    <i class="fas fa-comments text-4xl mb-4 opacity-50"></i>
                    <p>Nenhuma conversa ainda</p>
                    <p class="text-sm mt-2">As conversas aparecerão quando clientes entrarem em contato</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = chats.map(chat => {
            const unread = chat.unreadCount?.[this.store.ownerId] || 0;
            return `
                <div onclick="Chat.openChat('${chat.id}')" class="glass rounded-xl p-4 flex items-center gap-4 cursor-pointer hover:bg-white/5 transition-colors ${unread > 0 ? 'border-l-4 border-primary' : ''}">
                    <img src="${chat.customerAvatar}" class="w-12 h-12 rounded-full">
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center justify-between">
                            <h4 class="font-medium truncate">${chat.customerName}</h4>
                            <span class="text-xs text-gray-500">${chat.lastMessageAt?.toDate ? Utils.formatDate(chat.lastMessageAt) : ''}</span>
                        </div>
                        <p class="text-sm text-gray-400 truncate ${unread > 0 ? 'text-white font-medium' : ''}">
                            ${chat.lastMessage || 'Sem mensagens'}
                        </p>
                    </div>
                    ${unread > 0 ? `<span class="w-6 h-6 bg-primary rounded-full text-xs flex items-center justify-center font-bold">${unread}</span>` : ''}
                </div>
            `;
        }).join('');
    },

    renderDeliverySettings(container) {
        const config = this.store.deliveryOptions || { allowDelivery: true, allowPickup: true, deliveryFee: 0 };
        
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <h2 class="text-2xl font-bold">Configurações de Entrega</h2>
                
                <div class="glass rounded-xl p-6 space-y-6">
                    <div class="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
                        <div>
                            <h4 class="font-medium">Permitir Retirada na Loja</h4>
                            <p class="text-sm text-gray-400">Cliente pode buscar o pedido presencialmente</p>
                        </div>
                        <label class="toggle">
                            <input type="checkbox" id="allowPickup" ${config.allowPickup ? 'checked' : ''}>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div class="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg">
                        <div>
                            <h4 class="font-medium">Permitir Entrega</h4>
                            <p class="text-sm text-gray-400">Você faz entrega na cidade</p>
                        </div>
                        <label class="toggle">
                            <input type="checkbox" id="allowDelivery" ${config.allowDelivery ? 'checked' : ''} onchange="Owner.toggleDeliveryFee()">
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div id="deliveryFeeSection" class="${config.allowDelivery ? '' : 'hidden'} p-4 bg-gray-800/30 rounded-lg">
                        <label class="block text-sm text-gray-400 mb-2">Taxa de Entrega (R$)</label>
                        <input type="number" id="deliveryFee" value="${config.deliveryFee || 0}" step="0.01" 
                               class="input-field w-full rounded-xl px-4 py-3" placeholder="0,00">
                        <p class="text-xs text-gray-500 mt-1">Deixe 0 para entrega grátis</p>
                    </div>

                    <button onclick="Owner.saveDeliveryConfig()" class="btn btn-primary w-full">
                        <i class="fas fa-save mr-2"></i> Salvar Configurações
                    </button>
                </div>
            </div>
        `;
    },

    toggleDeliveryFee() {
        const allowDelivery = document.getElementById('allowDelivery').checked;
        document.getElementById('deliveryFeeSection').classList.toggle('hidden', !allowDelivery);
    },

    async saveDeliveryConfig() {
        const btn = event.target;
        btn.classList.add('btn-loading');

        try {
            const config = {
                allowPickup: document.getElementById('allowPickup').checked,
                allowDelivery: document.getElementById('allowDelivery').checked,
                deliveryFee: parseFloat(document.getElementById('deliveryFee')?.value) || 0
            };

            await updateDoc(doc(db, 'stores', this.store.id), {
                deliveryOptions: config,
                updatedAt: serverTimestamp()
            });

            this.store.deliveryOptions = config;
            window.currentUserStore.deliveryOptions = config;
            
            Utils.showToast('Sucesso', 'Configurações salvas!');

        } catch (error) {
            Utils.showToast('Erro', 'Erro ao salvar', 'error');
        } finally {
            btn.classList.remove('btn-loading');
        }
    },

    renderCoupons(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <h2 class="text-2xl font-bold">Cupons de Desconto</h2>
                    <button onclick="Owner.openCouponModal()" class="btn btn-primary">
                        <i class="fas fa-plus mr-2"></i> Novo Cupom
                    </button>
                </div>

                <div id="couponsList" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="col-span-full text-center py-12">
                        <i class="fas fa-spinner fa-spin text-3xl text-primary"></i>
                        <p class="mt-4 text-gray-400">Carregando cupons...</p>
                    </div>
                </div>
            </div>
        `;
        
        this.loadCoupons();
    },

    async loadCoupons() {
        try {
            const couponsQuery = query(
                collection(db, 'coupons'),
                where('storeId', '==', this.store.id),
                orderBy('createdAt', 'desc')
            );
            
            const snapshot = await getDocs(couponsQuery);
            const coupons = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
            
            const container = document.getElementById('couponsList');
            if (!container) return;
            
            if (coupons.length === 0) {
                container.innerHTML = `
                    <div class="col-span-full text-center py-12 text-gray-500">
                        <i class="fas fa-ticket-alt text-4xl mb-4 opacity-50"></i>
                        <p class="mb-4">Nenhum cupom criado</p>
                        <button onclick="Owner.openCouponModal()" class="btn btn-primary">
                            <i class="fas fa-plus mr-2"></i> Criar primeiro cupom
                        </button>
                    </div>
                `;
                return;
            }
            
            container.innerHTML = coupons.map(c => `
                <div class="glass rounded-xl p-4 ${c.active ? 'border-l-4 border-green-500' : 'border-l-4 border-gray-500 opacity-60'}">
                    <div class="flex items-center justify-between mb-3">
                        <span class="text-2xl font-bold font-mono text-primary">${c.code}</span>
                        <span class="px-2 py-1 rounded text-xs ${c.active ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}">
                            ${c.active ? 'Ativo' : 'Inativo'}
                        </span>
                    </div>
                    <p class="text-lg font-medium mb-2">${c.type === 'percentage' ? c.value + '% OFF' : 'R$ ' + c.value.toFixed(2) + ' OFF'}</p>
                    <p class="text-sm text-gray-400 mb-3">${c.description || 'Sem descrição'}</p>
                    <div class="flex items-center justify-between text-sm text-gray-500">
                        <span>Usos: ${c.usedCount || 0}${c.maxUses ? '/' + c.maxUses : ''}</span>
                        <span>${c.expiresAt ? 'Válido até: ' + c.expiresAt.toDate().toLocaleDateString() : 'Sem expiração'}</span>
                    </div>
                    <div class="flex gap-2 mt-4">
                        <button onclick="Owner.toggleCoupon('${c.id}', ${!c.active})" class="flex-1 py-2 rounded-lg ${c.active ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'} text-sm">
                            ${c.active ? '<i class="fas fa-ban mr-1"></i> Desativar' : '<i class="fas fa-check mr-1"></i> Ativar'}
                        </button>
                        <button onclick="Owner.deleteCoupon('${c.id}')" class="px-3 py-2 rounded-lg bg-gray-700 text-red-400 text-sm">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `).join('');
            
        } catch (error) {
            console.error('Erro ao carregar cupons:', error);
        }
    },

    openCouponModal() {
        const modal = document.createElement('div');
        modal.id = 'couponModal';
        modal.className = 'fixed inset-0 z-[90] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4';
        modal.innerHTML = `
            <div class="glass-strong w-full max-w-md rounded-2xl animate-scale-in">
                <div class="p-6 border-b border-gray-700 flex items-center justify-between">
                    <h3 class="text-xl font-bold">Novo Cupom</h3>
                    <button onclick="document.getElementById('couponModal').remove()" class="w-8 h-8 rounded-full glass hover:bg-white/10 flex items-center justify-center">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <form id="couponForm" class="p-6 space-y-4" onsubmit="event.preventDefault(); Owner.saveCoupon();">
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Código *</label>
                        <input type="text" id="couponCode" required class="input-field w-full rounded-xl px-4 py-3 uppercase" placeholder="PROMO10">
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Tipo *</label>
                            <select id="couponType" class="input-field w-full rounded-xl px-4 py-3">
                                <option value="percentage">Porcentagem (%)</option>
                                <option value="fixed">Valor Fixo (R$)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Valor *</label>
                            <input type="number" id="couponValue" required step="0.01" class="input-field w-full rounded-xl px-4 py-3" placeholder="10">
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Descrição</label>
                        <input type="text" id="couponDescription" class="input-field w-full rounded-xl px-4 py-3" placeholder="Ex: 10% de desconto na primeira compra">
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Mínimo de compra (R$)</label>
                            <input type="number" id="couponMinPurchase" step="0.01" class="input-field w-full rounded-xl px-4 py-3" placeholder="0">
                        </div>
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Limite de usos</label>
                            <input type="number" id="couponMaxUses" class="input-field w-full rounded-xl px-4 py-3" placeholder="Ilimitado">
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Data de expiração</label>
                        <input type="datetime-local" id="couponExpires" class="input-field w-full rounded-xl px-4 py-3">
                    </div>
                    <button type="submit" class="btn btn-primary w-full">
                        <i class="fas fa-save mr-2"></i> Criar Cupom
                    </button>
                </form>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async saveCoupon() {
        const code = document.getElementById('couponCode').value.toUpperCase().trim();
        const type = document.getElementById('couponType').value;
        const value = parseFloat(document.getElementById('couponValue').value);
        const description = document.getElementById('couponDescription').value;
        const minPurchase = parseFloat(document.getElementById('couponMinPurchase').value) || 0;
        const maxUses = parseInt(document.getElementById('couponMaxUses').value) || null;
        const expiresAt = document.getElementById('couponExpires').value;
        
        if (!code || !value) {
            Utils.showToast('Erro', 'Preencha código e valor', 'error');
            return;
        }
        
        try {
            await setDoc(doc(collection(db, 'coupons')), {
                code,
                type,
                value,
                description,
                storeId: this.store.id,
                minPurchase,
                maxUses,
                usedCount: 0,
                active: true,
                expiresAt: expiresAt ? new Date(expiresAt) : null,
                createdBy: Auth.userData.id,
                createdAt: serverTimestamp()
            });
            
            Utils.showToast('Sucesso', 'Cupom criado!');
            document.getElementById('couponModal').remove();
            this.loadCoupons();
        } catch (error) {
            console.error('Erro ao criar cupom:', error);
            Utils.showToast('Erro', 'Erro ao criar cupom', 'error');
        }
    },

    async toggleCoupon(couponId, active) {
        try {
            await updateDoc(doc(db, 'coupons', couponId), {
                active,
                updatedAt: serverTimestamp()
            });
            Utils.showToast('Sucesso', active ? 'Cupom ativado' : 'Cupom desativado');
            this.loadCoupons();
        } catch (error) {
            Utils.showToast('Erro', 'Erro ao atualizar cupom', 'error');
        }
    },

    async deleteCoupon(couponId) {
        if (!confirm('Excluir este cupom permanentemente?')) return;
        
        try {
            await deleteDoc(doc(db, 'coupons', couponId));
            Utils.showToast('Sucesso', 'Cupom excluído');
            this.loadCoupons();
        } catch (error) {
            Utils.showToast('Erro', 'Erro ao excluir cupom', 'error');
        }
    },

    renderReports(container) {
        // Calcular estatísticas
        const orders = this.store.orders || [];
        const totalSales = orders.reduce((sum, o) => sum + (o.total || 0), 0);
        const salesByDay = {};
        const salesByProduct = {};
        
        orders.forEach(order => {
            const date = order.createdAt?.toDate ? order.createdAt.toDate().toISOString().split('T')[0] : new Date().toISOString().split('T')[0];
            salesByDay[date] = (salesByDay[date] || 0) + (order.total || 0);
            
            if (order.productName) {
                salesByProduct[order.productName] = (salesByProduct[order.productName] || 0) + (order.total || 0);
            }
        });
        
        const chartData = Object.entries(salesByDay).slice(-7);
        
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <h2 class="text-2xl font-bold">Relatórios de Vendas</h2>
                
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div class="glass rounded-xl p-4 text-center">
                        <div class="text-2xl font-bold text-green-400">R$ ${totalSales.toFixed(2)}</div>
                        <div class="text-sm text-gray-400">Total em vendas</div>
                    </div>
                    <div class="glass rounded-xl p-4 text-center">
                        <div class="text-2xl font-bold text-primary">${orders.length}</div>
                        <div class="text-sm text-gray-400">Pedidos</div>
                    </div>
                    <div class="glass rounded-xl p-4 text-center">
                        <div class="text-2xl font-bold text-accent">R$ ${orders.length > 0 ? (totalSales / orders.length).toFixed(2) : '0.00'}</div>
                        <div class="text-sm text-gray-400">Ticket médio</div>
                    </div>
                    <div class="glass rounded-xl p-4 text-center">
                        <div class="text-2xl font-bold text-orange-400">${this.store.items?.length || 0}</div>
                        <div class="text-sm text-gray-400">Produtos</div>
                    </div>
                </div>

                <!-- Gráfico de Vendas -->
                <div class="glass rounded-xl p-6">
                    <h3 class="font-bold mb-4">Vendas nos últimos 7 dias</h3>
                    ${chartData.length > 0 ? `
                        <div class="flex items-end gap-2 h-48">
                            ${chartData.map(([date, value]) => {
                                const max = Math.max(...chartData.map(d => d[1]));
                                const height = max > 0 ? (value / max * 100) : 0;
                                return `
                                    <div class="flex-1 flex flex-col items-center gap-2">
                                        <div class="w-full bg-primary/20 rounded-t-lg relative group" style="height: ${height}%">
                                            <div class="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-800 px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                                                R$ ${value.toFixed(2)}
                                            </div>
                                        </div>
                                        <span class="text-xs text-gray-500">${date.slice(5)}</span>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    ` : '<p class="text-center text-gray-500 py-8">Sem dados de vendas</p>'}
                </div>

                <!-- Produtos Mais Vendidos -->
                <div class="glass rounded-xl p-6">
                    <h3 class="font-bold mb-4">Produtos Mais Vendidos</h3>
                    <div class="space-y-3">
                        ${Object.entries(salesByProduct)
                            .sort((a, b) => b[1] - a[1])
                            .slice(0, 5)
                            .map(([name, value], index) => `
                                <div class="flex items-center gap-4">
                                    <span class="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center font-bold text-sm">${index + 1}</span>
                                    <span class="flex-1 truncate">${name}</span>
                                    <div class="flex-1 h-2 bg-gray-700 rounded-full overflow-hidden">
                                        <div class="h-full bg-primary rounded-full" style="width: ${(value / totalSales * 100) || 0}%"></div>
                                    </div>
                                    <span class="text-sm text-gray-400 w-20 text-right">R$ ${value.toFixed(2)}</span>
                                </div>
                            `).join('') || '<p class="text-center text-gray-500">Sem dados</p>'}
                    </div>
                </div>

                <!-- Últimos Pedidos -->
                <div class="glass rounded-xl p-6">
                    <h3 class="font-bold mb-4">Últimos Pedidos</h3>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Pedido</th>
                                    <th>Produto</th>
                                    <th>Cliente</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${orders.slice(0, 10).map(o => `
                                    <tr>
                                        <td>#${o.id?.slice(-6) || 'N/A'}</td>
                                        <td class="truncate max-w-xs">${o.productName}</td>
                                        <td>${o.customerName}</td>
                                        <td>R$ ${(o.total || 0).toFixed(2)}</td>
                                        <td><span class="px-2 py-1 rounded text-xs ${this.getStatusClass(o.status)}">${this.getStatusLabel(o.status)}</span></td>
                                    </tr>
                                `).join('') || '<tr><td colspan="5" class="text-center text-gray-500">Nenhum pedido</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    },

    renderEditStore(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <h2 class="text-2xl font-bold">Editar Loja</h2>
                
                <form id="editStoreForm" class="space-y-6" onsubmit="event.preventDefault(); Owner.saveStoreEdit();">
                    <!-- Logo e Banner -->
                    <div class="grid md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Logo da Loja</label>
                            <div class="relative group">
                                <input type="file" id="storeLogoInput" accept="image/*" class="hidden" onchange="Owner.previewStoreImage(this, 'logo')">
                                <label for="storeLogoInput" class="cursor-pointer block">
                                    <img id="storeLogoPreview" src="${this.store.logo || 'https://via.placeholder.com/200?text=Logo'}" class="w-full h-40 object-cover rounded-xl border-2 border-dashed border-gray-600 hover:border-primary transition-colors">
                                    <div class="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-xl">
                                        <i class="fas fa-camera text-2xl"></i>
                                    </div>
                                </label>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Banner da Loja</label>
                            <div class="relative group">
                                <input type="file" id="storeBannerInput" accept="image/*" class="hidden" onchange="Owner.previewStoreImage(this, 'banner')">
                                <label for="storeBannerInput" class="cursor-pointer block">
                                    <img id="storeBannerPreview" src="${this.store.banner || this.store.image || 'https://via.placeholder.com/400x200?text=Banner'}" class="w-full h-40 object-cover rounded-xl border-2 border-dashed border-gray-600 hover:border-primary transition-colors">
                                    <div class="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-xl">
                                        <i class="fas fa-camera text-2xl"></i>
                                    </div>
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Informações Básicas -->
                    <div class="glass rounded-xl p-6 space-y-4">
                        <h3 class="font-bold text-lg">Informações Básicas</h3>
                        
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Nome da Loja *</label>
                            <input type="text" id="storeName" value="${this.store.name}" required class="input-field w-full rounded-xl px-4 py-3">
                        </div>
                        
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Descrição</label>
                            <textarea id="storeDescription" rows="3" class="input-field w-full rounded-xl px-4 py-3 resize-none">${this.store.description || ''}</textarea>
                        </div>
                        
                        <div class="grid md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Categoria</label>
                                <select id="storeCategory" class="input-field w-full rounded-xl px-4 py-3">
                                    <option value="geral" ${this.store.category === 'geral' ? 'selected' : ''}>Geral</option>
                                    <option value="supermercado" ${this.store.category === 'supermercado' ? 'selected' : ''}>Supermercado</option>
                                    <option value="eletronicos" ${this.store.category === 'eletronicos' ? 'selected' : ''}>Eletrônicos</option>
                                    <option value="moda" ${this.store.category === 'moda' ? 'selected' : ''}>Moda</option>
                                    <option value="casa" ${this.store.category === 'casa' ? 'selected' : ''}>Casa</option>
                                    <option value="alimentos" ${this.store.category === 'alimentos' ? 'selected' : ''}>Alimentos</option>
                                    <option value="beleza" ${this.store.category === 'beleza' ? 'selected' : ''}>Beleza</option>
                                    <option value="esportes" ${this.store.category === 'esportes' ? 'selected' : ''}>Esportes</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Cidade</label>
                                <select id="storeCity" class="input-field w-full rounded-xl px-4 py-3">
                                    <option value="">Selecione...</option>
                                    ${window.Cities?.data?.map(c => `<option value="${c.id}" ${c.id === this.store.cityId ? 'selected' : ''}>${c.name}</option>`).join('') || ''}
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Contato -->
                    <div class="glass rounded-xl p-6 space-y-4">
                        <h3 class="font-bold text-lg">Contato</h3>
                        
                        <div class="grid md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Telefone/WhatsApp</label>
                                <input type="text" id="storePhone" value="${this.store.phone || ''}" class="input-field w-full rounded-xl px-4 py-3" placeholder="(11) 99999-9999">
                            </div>
                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Email</label>
                                <input type="email" id="storeEmail" value="${this.store.email || ''}" class="input-field w-full rounded-xl px-4 py-3">
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Endereço</label>
                            <input type="text" id="storeAddress" value="${this.store.address || ''}" class="input-field w-full rounded-xl px-4 py-3" placeholder="Rua, número, bairro">
                        </div>
                    </div>

                    <div class="flex gap-4">
                        <button type="button" onclick="Owner.showTab('overview')" class="flex-1 py-3 glass rounded-xl hover:bg-white/10">Cancelar</button>
                        <button type="submit" class="flex-1 py-3 bg-gradient-to-r from-primary to-secondary rounded-xl font-bold">
                            <i class="fas fa-save mr-2"></i> Salvar Alterações
                        </button>
                    </div>
                </form>
            </div>
        `;
    },

    previewStoreImage(input, type) {
        const file = input.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById(`store${type.charAt(0).toUpperCase() + type.slice(1)}Preview`).src = e.target.result;
        };
        reader.readAsDataURL(file);
    },

    async saveStoreEdit() {
        const btn = event.target.querySelector('button[type="submit"]');
        btn.classList.add('btn-loading');
        
        try {
            const updates = {
                name: document.getElementById('storeName').value.trim(),
                description: document.getElementById('storeDescription').value.trim(),
                category: document.getElementById('storeCategory').value,
                cityId: document.getElementById('storeCity').value,
                phone: document.getElementById('storePhone').value.trim(),
                email: document.getElementById('storeEmail').value.trim(),
                address: document.getElementById('storeAddress').value.trim(),
                updatedAt: serverTimestamp()
            };
            
            // Processar imagens se houver
            const logoInput = document.getElementById('storeLogoInput');
            const bannerInput = document.getElementById('storeBannerInput');
            
            if (logoInput.files[0]) {
                const logoUpload = await Products.optimizeAndUpload(logoInput.files[0]);
                updates.logo = logoUpload.url;
            }
            
            if (bannerInput.files[0]) {
                const bannerUpload = await Products.optimizeAndUpload(bannerInput.files[0]);
                updates.banner = bannerUpload.url;
                updates.image = bannerUpload.url; // Compatibilidade
            }
            
            await updateDoc(doc(db, 'stores', this.store.id), updates);
            
            // Atualizar local
            Object.assign(this.store, updates);
            Object.assign(window.currentUserStore, updates);
            
            Utils.showToast('Sucesso', 'Loja atualizada!');
            this.showTab('overview');
            
        } catch (error) {
            console.error('Erro ao salvar:', error);
            Utils.showToast('Erro', 'Erro ao atualizar loja', 'error');
        } finally {
            btn.classList.remove('btn-loading');
        }
    },

    renderPaymentSettings(container) {
        const mp = this.store.mercadoPago || {};
        const asaas = this.store.asaas || {};
        
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <h2 class="text-2xl font-bold">Configurações de Pagamento</h2>
                <p class="text-gray-400">Configure os gateways de pagamento para receber vendas</p>

                <!-- Mercado Pago -->
                <div class="glass rounded-xl p-6 space-y-4">
                    <div class="flex items-center gap-3 mb-4">
                        <i class="fas fa-credit-card text-3xl text-blue-400"></i>
                        <div>
                            <h3 class="font-bold text-lg">Mercado Pago</h3>
                            <p class="text-sm text-gray-400">Aceite cartão, PIX e boleto</p>
                        </div>
                        <span class="ml-auto px-3 py-1 rounded-full text-xs ${mp.accessToken ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}">
                            ${mp.accessToken ? 'Configurado' : 'Não configurado'}
                        </span>
                    </div>
                    
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Access Token</label>
                        <input type="password" id="mpAccessToken" value="${mp.accessToken || ''}" class="input-field w-full rounded-xl px-4 py-3" placeholder="APP_USR-...">
                        <p class="text-xs text-gray-500 mt-1">Encontre em: Mercado Pago → Desenvolvedores → Credenciais</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Public Key</label>
                        <input type="text" id="mpPublicKey" value="${mp.publicKey || ''}" class="input-field w-full rounded-xl px-4 py-3" placeholder="APP_USR-...">
                    </div>
                </div>

                <!-- Asaas -->
                <div class="glass rounded-xl p-6 space-y-4">
                    <div class="flex items-center gap-3 mb-4">
                        <i class="fas fa-university text-3xl text-purple-400"></i>
                        <div>
                            <h3 class="font-bold text-lg">Asaas</h3>
                            <p class="text-sm text-gray-400">Ótimo para cobranças recorrentes (aluguel)</p>
                        </div>
                        <span class="ml-auto px-3 py-1 rounded-full text-xs ${asaas.apiKey ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}">
                            ${asaas.apiKey ? 'Configurado' : 'Não configurado'}
                        </span>
                    </div>
                    
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">API Key</label>
                        <input type="password" id="asaasApiKey" value="${asaas.apiKey || ''}" class="input-field w-full rounded-xl px-4 py-3" placeholder="Sua chave Asaas">
                        <p class="text-xs text-gray-500 mt-1">Encontre em: Asaas → Configurações → Integrações</p>
                    </div>
                    
                    <label class="flex items-center gap-3 mt-4">
                        <input type="checkbox" id="asaasSandbox" ${asaas.sandbox !== false ? 'checked' : ''} class="w-4 h-4 rounded bg-gray-700 border-gray-600">
                        <span class="text-sm text-gray-300">Modo Sandbox (testes)</span>
                    </label>
                </div>

                <!-- PIX Direto -->
                <div class="glass rounded-xl p-6 space-y-4">
                    <div class="flex items-center gap-3 mb-4">
                        <i class="fas fa-qrcode text-3xl text-green-400"></i>
                        <div>
                            <h3 class="font-bold text-lg">PIX Direto</h3>
                            <p class="text-sm text-gray-400">Receba direto na sua conta (sem taxas de intermediário)</p>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Chave PIX</label>
                        <input type="text" id="pixKey" value="${this.store.pixKey || ''}" class="input-field w-full rounded-xl px-4 py-3" placeholder="CPF, CNPJ, email ou celular">
                        <p class="text-xs text-gray-500 mt-1">Sua chave PIX registrada no banco</p>
                    </div>
                </div>

                <button onclick="Owner.savePaymentConfig()" class="btn btn-primary w-full">
                    <i class="fas fa-save mr-2"></i> Salvar Configurações
                </button>
            </div>
        `;
    },

    async savePaymentConfig() {
        const btn = event.target;
        btn.classList.add('btn-loading');
        
        try {
            const updates = {
                updatedAt: serverTimestamp()
            };
            
            const mpToken = document.getElementById('mpAccessToken').value.trim();
            const mpPublicKey = document.getElementById('mpPublicKey').value.trim();
            
            if (mpToken) {
                updates.mercadoPago = {
                    accessToken: mpToken,
                    publicKey: mpPublicKey,
                    configuredAt: serverTimestamp()
                };
            }
            
            const asaasKey = document.getElementById('asaasApiKey').value.trim();
            const asaasSandbox = document.getElementById('asaasSandbox').checked;
            
            if (asaasKey) {
                updates.asaas = {
                    apiKey: asaasKey,
                    sandbox: asaasSandbox,
                    configuredAt: serverTimestamp()
                };
            }
            
            const pixKey = document.getElementById('pixKey').value.trim();
            if (pixKey) {
                updates.pixKey = pixKey;
            }
            
            await updateDoc(doc(db, 'stores', this.store.id), updates);
            
            Object.assign(this.store, updates);
            Object.assign(window.currentUserStore, updates);
            
            Utils.showToast('Sucesso', 'Configurações salvas!');
            
        } catch (error) {
            console.error('Erro ao salvar:', error);
            Utils.showToast('Erro', 'Erro ao salvar configurações', 'error');
        } finally {
            btn.classList.remove('btn-loading');
        }
    },

    // Helpers
    getStatusLabel(status) {
        const labels = {
            pending: 'Pendente',
            paid: 'Pago',
            preparing: 'Em preparo',
            shipped: 'Enviado',
            delivered: 'Entregue',
            cancelled: 'Cancelado'
        };
        return labels[status] || status;
    },

    getStatusClass(status) {
        const classes = {
            pending: 'bg-yellow-500/20 text-yellow-400',
            paid: 'bg-green-500/20 text-green-400',
            preparing: 'bg-blue-500/20 text-blue-400',
            shipped: 'bg-purple-500/20 text-purple-400',
            delivered: 'bg-green-500/20 text-green-400',
            cancelled: 'bg-red-500/20 text-red-400'
        };
        return classes[status] || 'bg-gray-500/20 text-gray-400';
    },

    getPaymentMethodLabel(method) {
        const labels = {
            credit_card: 'Cartão de Crédito',
            debit_card: 'Cartão de Débito',
            pix: 'PIX',
            boleto: 'Boleto',
            cash: 'Dinheiro'
        };
        return labels[method] || method;
    }
};

window.Owner = Owner;
export default Owner;