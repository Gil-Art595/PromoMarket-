// ==========================================
// CONFIGURAÇÃO ASAAS - REDEPROMO
// ==========================================

const AsaasConfig = {
    // ⚠️ SUBSTITUA PELA SUA API KEY REAL
    apiKey: '$aact_SUA_CHAVE_AQUI$prod$...',
    
    // Ambiente: 'sandbox' para testes, 'production' para produção
    environment: 'sandbox', // Mude para 'production' quando for ao vivo
    
    // URLs da API
    baseUrl: {
        sandbox: 'https://sandbox.asaas.com/api/v3',
        production: 'https://api.asaas.com/v3'
    },
    
    // Configurações de aluguel padrão
    defaultRental: {
        amount: 99.90,        // Valor mensal padrão
        dueDay: 5,            // Dia do vencimento (5 = todo dia 5)
        description: 'Aluguel mensal RedePromo'
    },
    
    // Headers para requisições
    getHeaders() {
        return {
            'Content-Type': 'application/json',
            'access_token': this.apiKey
        };
    },
    
    // URL base conforme ambiente
    getBaseUrl() {
        return this.environment === 'production' 
            ? this.baseUrl.production 
            : this.baseUrl.sandbox;
    }
};

export default AsaasConfig;
window.AsaasConfig = AsaasConfig;