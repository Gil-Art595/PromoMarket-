// ==========================================
// INTEGRAÇÃO WHATSAPP API
// ==========================================

const WhatsApp = {
    // Configurações
    config: {
        // Opção 1: WhatsApp Business API (Meta/Facebook) - Oficial, pago
        // Opção 2: WhatsApp Web.js - Gratuito, precisa de servidor Node
        // Opção 3: Evolution API - Open source, self-hosted
        // Opção 4: Z-API - Pago, brasileiro, fácil
        
        // Aqui vamos usar a Z-API como exemplo (mais fácil para iniciar)
        provider: 'zapi', // 'zapi', 'evolution', 'official', 'webjs'
        
        // Z-API (https://www.z-api.io/)
        zapi: {
            instanceId: '', // Preencher com sua instância
            token: '',      // Preencher com seu token
            baseUrl: 'https://api.z-api.io/instances'
        },
        
        // Evolution API (self-hosted)
        evolution: {
            baseUrl: '',    // URL da sua instância
            apiKey: ''
        }
    },

    // Enviar mensagem
    async sendMessage(phone, message, options = {}) {
        const cleanPhone = phone.replace(/\D/g, '');
        
        switch(this.config.provider) {
            case 'zapi':
                return this.sendZApi(cleanPhone, message, options);
            case 'evolution':
                return this.sendEvolution(cleanPhone, message, options);
            case 'webjs':
                // Requer servidor Node.js rodando
                return this.sendWebJS(cleanPhone, message);
            default:
                // Fallback: abrir WhatsApp Web
                return this.openWhatsAppWeb(cleanPhone, message);
        }
    },

    // Z-API
    async sendZApi(phone, message, options = {}) {
        const { zapi } = this.config;
        
        try {
            const response = await fetch(`${zapi.baseUrl}/${zapi.instanceId}/token/${zapi.token}/send-text`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    phone: phone,
                    message: message,
                    ...options
                })
            });

            return await response.json();
        } catch (error) {
            console.error('Erro Z-API:', error);
            // Fallback para WhatsApp Web
            return this.openWhatsAppWeb(phone, message);
        }
    },

    // Evolution API
    async sendEvolution(phone, message, options = {}) {
        const { evolution } = this.config;
        
        try {
            const response = await fetch(`${evolution.baseUrl}/message/sendText/${evolution.instance}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'apikey': evolution.apiKey
                },
                body: JSON.stringify({
                    number: `55${phone}`,
                    text: message,
                    ...options
                })
            });

            return await response.json();
        } catch (error) {
            console.error('Erro Evolution:', error);
            return this.openWhatsAppWeb(phone, message);
        }
    },

    // WhatsApp Web.js (via Firebase Function)
    async sendWebJS(phone, message) {
        // Isso chamaria uma Firebase Function
        // Por enquanto, fallback
        return this.openWhatsAppWeb(phone, message);
    },

    // Fallback: abrir WhatsApp Web
    openWhatsAppWeb(phone, message) {
        const encodedMessage = encodeURIComponent(message);
        const url = `https://wa.me/55${phone}?text=${encodedMessage}`;
        window.open(url, '_blank');
        return { success: true, method: 'web' };
    },

    // Templates de mensagens

    // Notificar novo pedido para lojista
    async notifyNewOrderToStore(order) {
        const store = Stores.data.find(s => s.id === order.storeId);
        if (!store?.whatsapp) return;

        const message = `🛍️ *NOVO PEDIDO - RedePromo*\n\n` +
            `Pedido: #${order.id.slice(-6)}\n` +
            `Cliente: ${order.customerName}\n` +
            `Produto: ${order.productName}\n` +
            `Total: R$ ${order.total.toFixed(2)}\n\n` +
            `📦 Tipo: ${order.deliveryType === 'delivery' ? 'Entrega' : 'Retirada'}\n` +
            `💳 Pagamento: ${order.paymentMethod}\n\n` +
            `Acesse o painel para mais detalhes.`;

        return this.sendMessage(store.whatsapp, message);
    },

    // Notificar cliente sobre status do pedido
    async notifyOrderStatusToCustomer(order) {
        if (!order.customerPhone) return;

        const statusMessages = {
            pending: '⏳ Aguardando pagamento',
            paid: '✅ Pagamento confirmado!',
            preparing: '📦 Pedido em preparação',
            shipped: '🚚 Saiu para entrega',
            delivered: '✨ Pedido entregue!',
            cancelled: '❌ Pedido cancelado'
        };

        const message = `🛍️ *Atualização do seu pedido - RedePromo*\n\n` +
            `Pedido: #${order.id.slice(-6)}\n` +
            `Loja: ${order.storeName}\n` +
            `Status: ${statusMessages[order.status] || order.status}\n\n` +
            `Acompanhe pelo app: ${window.location.origin}`;

        return this.sendMessage(order.customerPhone, message);
    },

    // Lembrete de aluguel
    async sendRentalReminder(store, rental) {
        if (!store.whatsapp) return;

        const message = `💰 *LEMBRETE - Aluguel RedePromo*\n\n` +
            `Olá ${store.ownerName || 'Lojista'}!\n\n` +
            `Seu aluguel de *R$ ${rental.amount.toFixed(2)}* vence em ${rental.dueDay ? `dia ${rental.dueDay}` : 'breve'}.\n\n` +
            `Evite suspensão da loja. Faça o pagamento pelo painel ou responda aqui com o comprovante.\n\n` +
            `Dúvidas? Fale conosco!`;

        return this.sendMessage(store.whatsapp, message);
    },

    // Cupom de desconto
    async sendCoupon(phone, couponCode, discount) {
        const message = `🎁 *CUPOM ESPECIAL - RedePromo*\n\n` +
            `Use o código: *${couponCode}*\n` +
            `Desconto: ${discount}\n\n` +
            `Válido por tempo limitado. Aproveite! 🛒\n\n` +
            `${window.location.origin}`;

        return this.sendMessage(phone, message);
    },

    // Botão de WhatsApp flutuante
    renderButton(containerId, phone, message = '') {
        const container = document.getElementById(containerId);
        if (!container) return;

        const cleanPhone = phone.replace(/\D/g, '');
        
        container.innerHTML = `
            <a href="https://wa.me/55${cleanPhone}${message ? '?text=' + encodeURIComponent(message) : ''}" 
               target="_blank"
               class="fixed bottom-24 right-4 w-14 h-14 bg-green-500 rounded-full shadow-lg shadow-green-500/50 flex items-center justify-center text-white text-2xl hover:scale-110 transition-transform z-30 animate-bounce">
                <i class="fab fa-whatsapp"></i>
            </a>
        `;
    },

    // Widget de chat (simulação)
    renderWidget(containerId, storePhone, storeName) {
        const container = document.getElementById(containerId);
        if (!container) return;

        container.innerHTML = `
            <div id="whatsappWidget" class="fixed bottom-4 right-4 z-50">
                <button onclick="WhatsApp.toggleWidget()" class="w-14 h-14 bg-green-500 rounded-full shadow-lg flex items-center justify-center text-white text-2xl hover:scale-110 transition-transform">
                    <i class="fab fa-whatsapp"></i>
                </button>
                
                <div id="widgetChat" class="hidden absolute bottom-16 right-0 w-80 glass-strong rounded-2xl shadow-2xl overflow-hidden">
                    <div class="bg-green-600 p-4 flex items-center gap-3">
                        <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(storeName)}&background=random" class="w-10 h-10 rounded-full">
                        <div>
                            <p class="font-bold text-white">${storeName}</p>
                            <p class="text-xs text-green-100">Geralmente responde em minutos</p>
                        </div>
                    </div>
                    
                    <div class="h-64 p-4 overflow-y-auto bg-gray-900/50">
                        <div class="bg-gray-800 rounded-lg p-3 rounded-tl-none max-w-[80%]">
                            <p class="text-sm">Olá! Como posso ajudar? 😊</p>
                            <span class="text-xs text-gray-500 mt-1 block">Agora</span>
                        </div>
                    </div>
                    
                    <div class="p-3 bg-gray-900 border-t border-gray-800">
                        <form onsubmit="WhatsApp.sendWidgetMessage(event, '${storePhone}')" class="flex gap-2">
                            <input type="text" id="widgetMessage" placeholder="Digite sua mensagem..." 
                                   class="flex-1 bg-gray-800 rounded-full px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500">
                            <button type="submit" class="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        `;
    },

    toggleWidget() {
        const chat = document.getElementById('widgetChat');
        chat.classList.toggle('hidden');
    },

    sendWidgetMessage(e, phone) {
        e.preventDefault();
        const input = document.getElementById('widgetMessage');
        const message = input.value.trim();
        
        if (!message) return;

        // Adicionar mensagem do usuário
        const chatContainer = e.target.closest('#widgetChat').querySelector('.overflow-y-auto');
        chatContainer.innerHTML += `
            <div class="flex justify-end mt-3">
                <div class="bg-green-600 rounded-lg p-3 rounded-tr-none max-w-[80%]">
                    <p class="text-sm">${message}</p>
                    <span class="text-xs text-green-100 mt-1 block">Você</span>
                </div>
            </div>
        `;
        
        chatContainer.scrollTop = chatContainer.scrollHeight;
        input.value = '';

        // Abrir WhatsApp real após 1s
        setTimeout(() => {
            this.openWhatsAppWeb(phone, message);
        }, 1000);
    },

    // Configurar provider
    setProvider(provider, config) {
        this.config.provider = provider;
        Object.assign(this.config[provider], config);
    }
};

window.WhatsApp = WhatsApp;
export default WhatsApp;
