// ==========================================
// RELATÓRIOS FINANCEIROS
// ==========================================

import { collection, getDocs, query, where, orderBy } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const db = window.firebaseDb;

const Reports = {
    // Relatório de vendas da loja
    async getStoreSalesReport(storeId, period = 'month') {
        const store = Stores.data.find(s => s.id === storeId);
        if (!store) return null;

        const orders = store.orders || [];
        const now = new Date();
        
        // Filtrar por período
        let startDate;
        switch(period) {
            case 'week':
                startDate = new Date(now - 7 * 24 * 60 * 60 * 1000);
                break;
            case 'month':
                startDate = new Date(now.getFullYear(), now.getMonth(), 1);
                break;
            case 'year':
                startDate = new Date(now.getFullYear(), 0, 1);
                break;
            default:
                startDate = new Date(0);
        }

        const filteredOrders = orders.filter(o => {
            const orderDate = o.createdAt?.toDate ? o.createdAt.toDate() : new Date(o.createdAt);
            return orderDate >= startDate;
        });

        // Calcular métricas
        const totalSales = filteredOrders.reduce((sum, o) => sum + (o.total || 0), 0);
        const totalOrders = filteredOrders.length;
        const averageTicket = totalOrders > 0 ? totalSales / totalOrders : 0;
        
        const salesByDay = {};
        const salesByProduct = {};
        const salesByPaymentMethod = {};

        filteredOrders.forEach(order => {
            // Por dia
            const date = order.createdAt?.toDate ? 
                order.createdAt.toDate().toISOString().split('T')[0] : 
                new Date().toISOString().split('T')[0];
            salesByDay[date] = (salesByDay[date] || 0) + order.total;

            // Por produto
            salesByProduct[order.productName] = (salesByProduct[order.productName] || 0) + order.total;

            // Por método de pagamento
            const method = order.paymentMethod || 'unknown';
            salesByPaymentMethod[method] = (salesByPaymentMethod[method] || 0) + order.total;
        });

        return {
            period,
            totalSales,
            totalOrders,
            averageTicket,
            salesByDay,
            salesByProduct,
            salesByPaymentMethod,
            orders: filteredOrders
        };
    },

    // Relatório de aluguéis (para admin)
    async getRentalReport(month = null) {
        const targetMonth = month || new Date().toISOString().slice(0, 7);
        
        const q = query(
            collection(db, 'rentals'),
            where('month', '==', targetMonth)
        );

        const snapshot = await getDocs(q);
        const rentals = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));

        const totalExpected = rentals.reduce((sum, r) => sum + (r.amount || 0), 0);
        const totalReceived = rentals
            .filter(r => r.status === 'confirmed')
            .reduce((sum, r) => sum + (r.amount || 0), 0);
        const totalPending = rentals
            .filter(r => r.status === 'pending' || r.status === 'paid')
            .reduce((sum, r) => sum + (r.amount || 0), 0);

        return {
            month: targetMonth,
            totalRentals: rentals.length,
            totalExpected,
            totalReceived,
            totalPending,
            totalOverdue: rentals.filter(r => r.status === 'overdue').length,
            rentals: rentals.sort((a, b) => {
                const statusOrder = { overdue: 0, pending: 1, paid: 2, confirmed: 3 };
                return statusOrder[a.status] - statusOrder[b.status];
            })
        };
    },

    // Relatório geral da plataforma (admin)
    async getPlatformReport() {
        const stores = Stores.data;
        const totalStores = stores.length;
        
        const totalProducts = stores.reduce((sum, s) => sum + (s.items?.length || 0), 0);
        const totalOrders = stores.reduce((sum, s) => sum + (s.orders?.length || 0), 0);
        const totalSales = stores.reduce((sum, s) => {
            return sum + (s.orders || []).reduce((orderSum, o) => orderSum + (o.total || 0), 0);
        }, 0);

        // Lojas mais vendidas
        const topStores = [...stores]
            .map(s => ({
                ...s,
                totalSales: (s.orders || []).reduce((sum, o) => sum + (o.total || 0), 0),
                orderCount: s.orders?.length || 0
            }))
            .sort((a, b) => b.totalSales - a.totalSales)
            .slice(0, 10);

        return {
            totalStores,
            totalProducts,
            totalOrders,
            totalSales,
            topStores,
            averageStoreSales: totalStores > 0 ? totalSales / totalStores : 0
        };
    },

    // Renderizar dashboard de relatórios
    renderDashboard(containerId, storeId = null) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const isAdmin = Auth.isAdmin();
        const targetStoreId = storeId || (isAdmin ? null : window.currentUserStore?.id);

        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between">
                    <h2 class="text-2xl font-bold">Relatórios</h2>
                    <select onchange="Reports.changePeriod(this.value, '${targetStoreId}')" class="input-field rounded-xl px-4 py-2">
                        <option value="week">Última semana</option>
                        <option value="month" selected>Este mês</option>
                        <option value="year">Este ano</option>
                        <option value="all">Todo período</option>
                    </select>
                </div>

                <div id="reportContent" class="space-y-6">
                    <div class="flex items-center justify-center py-12">
                        <i class="fas fa-spinner fa-spin text-4xl text-primary"></i>
                    </div>
                </div>
            </div>
        `;

        this.loadReport('month', targetStoreId);
    },

    async loadReport(period, storeId) {
        const content = document.getElementById('reportContent');
        
        try {
            let report;
            if (storeId) {
                report = await this.getStoreSalesReport(storeId, period);
            } else if (Auth.isAdmin()) {
                report = await this.getPlatformReport();
            }

            if (storeId) {
                this.renderStoreReport(content, report);
            } else {
                this.renderPlatformReport(content, report);
            }

        } catch (error) {
            content.innerHTML = `<p class="text-red-400 text-center">Erro ao carregar relatório</p>`;
        }
    },

    renderStoreReport(container, report) {
        const chartData = Object.entries(report.salesByDay || {})
            .slice(-7)
            .map(([date, value]) => ({ date, value }));

        container.innerHTML = `
            <!-- Cards de resumo -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div class="glass rounded-xl p-4 text-center">
                    <p class="text-3xl font-bold text-green-400">R$ ${report.totalSales.toFixed(2)}</p>
                    <p class="text-sm text-gray-400">Total em vendas</p>
                </div>
                <div class="glass rounded-xl p-4 text-center">
                    <p class="text-3xl font-bold text-primary">${report.totalOrders}</p>
                    <p class="text-sm text-gray-400">Pedidos</p>
                </div>
                <div class="glass rounded-xl p-4 text-center">
                    <p class="text-3xl font-bold text-accent">R$ ${report.averageTicket.toFixed(2)}</p>
                    <p class="text-sm text-gray-400">Ticket médio</p>
                </div>
                <div class="glass rounded-xl p-4 text-center">
                    <p class="text-3xl font-bold text-orange-400">${chartData.length}</p>
                    <p class="text-sm text-gray-400">Dias com venda</p>
                </div>
            </div>

            <!-- Gráfico simples (barras CSS) -->
            <div class="glass rounded-xl p-6">
                <h3 class="font-bold text-lg mb-4">Vendas nos últimos 7 dias</h3>
                <div class="flex items-end gap-2 h-48">
                    ${chartData.map(d => {
                        const max = Math.max(...chartData.map(x => x.value));
                        const height = max > 0 ? (d.value / max * 100) : 0;
                        return `
                            <div class="flex-1 flex flex-col items-center gap-2">
                                <div class="w-full bg-primary/20 rounded-t-lg relative group" style="height: ${height}%">
                                    <div class="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-800 px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                                        R$ ${d.value.toFixed(2)}
                                    </div>
                                </div>
                                <span class="text-xs text-gray-500">${d.date.slice(-2)}/${d.date.slice(5, 7)}</span>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>

            <!-- Por produto -->
            <div class="glass rounded-xl p-6">
                <h3 class="font-bold text-lg mb-4">Vendas por produto</h3>
                <div class="space-y-3">
                    ${Object.entries(report.salesByProduct || {})
                        .sort((a, b) => b[1] - a[1])
                        .slice(0, 5)
                        .map(([name, value]) => `
                            <div class="flex items-center gap-4">
                                <span class="flex-1 truncate">${name}</span>
                                <div class="flex-1 h-2 bg-gray-700 rounded-full overflow-hidden">
                                    <div class="h-full bg-primary rounded-full" style="width: ${(value / report.totalSales * 100) || 0}%"></div>
                                </div>
                                <span class="text-sm text-gray-400 w-20 text-right">R$ ${value.toFixed(2)}</span>
                            </div>
                        `).join('')}
                </div>
            </div>

            <!-- Por método de pagamento -->
            <div class="glass rounded-xl p-6">
                <h3 class="font-bold text-lg mb-4">Por método de pagamento</h3>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    ${Object.entries(report.salesByPaymentMethod || {}).map(([method, value]) => {
                        const icons = {
                            credit_card: 'fa-credit-card',
                            pix: 'fa-qrcode',
                            boleto: 'fa-barcode',
                            cash: 'fa-money-bill'
                        };
                        return `
                            <div class="text-center p-4 bg-gray-800/50 rounded-xl">
                                <i class="fas ${icons[method] || 'fa-wallet'} text-2xl text-primary mb-2"></i>
                                <p class="font-bold">R$ ${value.toFixed(2)}</p>
                                <p class="text-xs text-gray-400 capitalize">${method.replace('_', ' ')}</p>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>

            <!-- Últimos pedidos -->
            <div class="glass rounded-xl p-6">
                <h3 class="font-bold text-lg mb-4">Últimos pedidos</h3>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Pedido</th>
                                <th>Produto</th>
                                <th>Cliente</th>
                                <th>Total</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${report.orders.slice(-10).reverse().map(o => `
                                <tr>
                                    <td>#${o.id.slice(-6)}</td>
                                    <td class="truncate max-w-xs">${o.productName}</td>
                                    <td>${o.customerName}</td>
                                    <td>R$ ${o.total.toFixed(2)}</td>
                                    <td>
                                        <span class="px-2 py-1 rounded text-xs status-${o.status}">
                                            ${o.status}
                                        </span>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    },

    renderPlatformReport(container, report) {
        container.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div class="glass rounded-xl p-4 text-center">
                    <p class="text-3xl font-bold text-primary">${report.totalStores}</p>
                    <p class="text-sm text-gray-400">Lojas</p>
                </div>
                <div class="glass rounded-xl p-4 text-center">
                    <p class="text-3xl font-bold text-accent">${report.totalProducts}</p>
                    <p class="text-sm text-gray-400">Produtos</p>
                </div>
                <div class="glass rounded-xl p-4 text-center">
                    <p class="text-3xl font-bold text-green-400">${report.totalOrders}</p>
                    <p class="text-sm text-gray-400">Pedidos</p>
                </div>
                <div class="glass rounded-xl p-4 text-center">
                    <p class="text-3xl font-bold text-orange-400">R$ ${report.totalSales.toFixed(2)}</p>
                    <p class="text-sm text-gray-400">GMV Total</p>
                </div>
            </div>

            <div class="glass rounded-xl p-6">
                <h3 class="font-bold text-lg mb-4">Top 10 Lojas</h3>
                <div class="space-y-3">
                    ${report.topStores.map((s, i) => `
                        <div class="flex items-center gap-4 p-3 bg-gray-800/30 rounded-lg">
                            <span class="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center font-bold">${i + 1}</span>
                            <img src="${s.logo}" class="w-10 h-10 rounded-full">
                            <div class="flex-1">
                                <p class="font-medium">${s.name}</p>
                                <p class="text-sm text-gray-400">${s.orderCount} pedidos</p>
                            </div>
                            <div class="text-right">
                                <p class="font-bold text-green-400">R$ ${s.totalSales.toFixed(2)}</p>
                                <p class="text-xs text-gray-400">em vendas</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    },

    changePeriod(period, storeId) {
        this.loadReport(period, storeId);
    },

    // Exportar para CSV
    exportToCSV(data, filename) {
        const headers = Object.keys(data[0] || {});
        const csvContent = [
            headers.join(','),
            ...data.map(row => headers.map(h => {
                const val = row[h];
                // Escapar valores com vírgula
                if (typeof val === 'string' && val.includes(',')) {
                    return `"${val.replace(/"/g, '""')}"`;
                }
                return val;
            }).join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = filename;
        link.click();
    }
};

window.Reports = Reports;
export default Reports;