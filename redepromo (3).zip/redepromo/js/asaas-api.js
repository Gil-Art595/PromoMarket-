// ==========================================
// API ASAAS - INTEGRAÇÃO COMPLETA
// ==========================================

import AsaasConfig from './asaas-config.js';

const AsaasAPI = {
    // ==========================================
    // CLIENTES (LOJISTAS)
    // ==========================================
    
    // Criar cliente no Asaas
    async createCustomer(storeData) {
        try {
            const response = await fetch(`${AsaasConfig.getBaseUrl()}/customers`, {
                method: 'POST',
                headers: AsaasConfig.getHeaders(),
                body: JSON.stringify({
                    name: storeData.ownerName || storeData.name,
                    email: storeData.ownerEmail,
                    phone: storeData.ownerPhone,
                    cpfCnpj: storeData.ownerCpfCnpj || '00000000000', // CPF/CNPJ do lojista
                    externalReference: storeData.id, // ID da loja no seu sistema
                    notificationDisabled: false
                })
            });
            
            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.errors?.[0]?.description || 'Erro ao criar cliente');
            }
            
            return await response.json();
        } catch (error) {
            console.error('Asaas - Erro ao criar cliente:', error);
            throw error;
        }
    },
    
    // Buscar cliente por CPF/CNPJ ou ID externo
    async findCustomer(cpfCnpj) {
        try {
            const response = await fetch(
                `${AsaasConfig.getBaseUrl()}/customers?cpfCnpj=${cpfCnpj}`,
                { headers: AsaasConfig.getHeaders() }
            );
            
            const data = await response.json();
            return data.data?.[0] || null;
        } catch (error) {
            console.error('Asaas - Erro ao buscar cliente:', error);
            return null;
        }
    },
    
    // ==========================================
    // COBRANÇAS (ALUGUÉIS)
    // ==========================================
    
    // Criar cobrança mensal (boleto/pix/cartão)
    async createPayment(customerId, rentalData) {
        try {
            const dueDate = new Date();
            dueDate.setDate(rentalData.dueDay || AsaasConfig.defaultRental.dueDay);
            
            // Se o dia já passou, mês que vem
            if (dueDate < new Date()) {
                dueDate.setMonth(dueDate.getMonth() + 1);
            }
            
            const response = await fetch(`${AsaasConfig.getBaseUrl()}/payments`, {
                method: 'POST',
                headers: AsaasConfig.getHeaders(),
                body: JSON.stringify({
                    customer: customerId,
                    billingType: 'UNDEFINED', // Lojista escolhe: BOLETO, PIX, CREDIT_CARD
                    value: rentalData.amount || AsaasConfig.defaultRental.amount,
                    dueDate: dueDate.toISOString().split('T')[0],
                    description: rentalData.description || AsaasConfig.defaultRental.description,
                    externalReference: rentalData.storeId,
                    postalService: false, // Não enviar correio
                    notificationDisabled: false
                })
            });
            
            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.errors?.[0]?.description || 'Erro ao criar cobrança');
            }
            
            return await response.json();
        } catch (error) {
            console.error('Asaas - Erro ao criar cobrança:', error);
            throw error;
        }
    },
    
    // Criar cobrança recorrente (assinatura mensal automática)
    async createSubscription(customerId, rentalData) {
        try {
            const response = await fetch(`${AsaasConfig.getBaseUrl()}/subscriptions`, {
                method: 'POST',
                headers: AsaasConfig.getHeaders(),
                body: JSON.stringify({
                    customer: customerId,
                    billingType: 'UNDEFINED',
                    value: rentalData.amount || AsaasConfig.defaultRental.amount,
                    nextDueDate: this.getNextDueDate(rentalData.dueDay),
                    cycle: 'MONTHLY',
                    description: rentalData.description || AsaasConfig.defaultRental.description,
                    externalReference: rentalData.storeId,
                    maxPayments: 0, // 0 = indefinido (até cancelar)
                    notificationDisabled: false
                })
            });
            
            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.errors?.[0]?.description || 'Erro ao criar assinatura');
            }
            
            return await response.json();
        } catch (error) {
            console.error('Asaas - Erro ao criar assinatura:', error);
            throw error;
        }
    },
    
    // Cancelar assinatura
    async cancelSubscription(subscriptionId) {
        try {
            const response = await fetch(
                `${AsaasConfig.getBaseUrl()}/subscriptions/${subscriptionId}`,
                {
                    method: 'DELETE',
                    headers: AsaasConfig.getHeaders()
                }
            );
            
            return response.ok;
        } catch (error) {
            console.error('Asaas - Erro ao cancelar assinatura:', error);
            return false;
        }
    },
    
    // Consultar cobrança
    async getPayment(paymentId) {
        try {
            const response = await fetch(
                `${AsaasConfig.getBaseUrl()}/payments/${paymentId}`,
                { headers: AsaasConfig.getHeaders() }
            );
            
            return await response.json();
        } catch (error) {
            console.error('Asaas - Erro ao consultar cobrança:', error);
            return null;
        }
    },
    
    // ==========================================
    // UTILITÁRIOS
    // ==========================================
    
    getNextDueDate(dueDay = 5) {
        const date = new Date();
        date.setDate(dueDay);
        
        if (date < new Date()) {
            date.setMonth(date.getMonth() + 1);
        }
        
        return date.toISOString().split('T')[0];
    },
    
    // Verificar status do pagamento
    isPaid(status) {
        return status === 'RECEIVED' || status === 'CONFIRMED';
    },
    
    isOverdue(status, dueDate) {
        if (status === 'RECEIVED') return false;
        return new Date(dueDate) < new Date();
    }
};

export default AsaasAPI;
window.AsaasAPI = AsaasAPI;