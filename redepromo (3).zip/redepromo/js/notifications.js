// ==========================================
// SISTEMA DE NOTIFICAÇÕES
// Push, Email, WhatsApp (simulado)
// ==========================================

const Notifications = {
    // Solicitar permissão para notificações push
    async requestPermission() {
        if (!('Notification' in window)) {
            console.log('Notificações não suportadas');
            return false;
        }

        const permission = await Notification.requestPermission();
        return permission === 'granted';
    },

    // Enviar notificação push local
    sendPush(title, options = {}) {
        if (Notification.permission === 'granted') {
            return new Notification(title, {
                icon: '/assets/logo.png',
                badge: '/assets/badge.png',
                ...options
            });
        }
    },

    // Notificar novo pedido (para lojista)
    notifyNewOrder(order) {
        this.sendPush(`Novo pedido #${order.id.slice(-6)}`, {
            body: `${order.customerName} comprou ${order.productName} por R$ ${order.total.toFixed(2)}`,
            tag: `order-${order.id}`,
            requireInteraction: true,
            actions: [
                { action: 'view', title: 'Ver Pedido' },
                { action: 'dismiss', title: 'Ignorar' }
            ]
        });

        // Salvar no Firestore para histórico
        this.saveNotification({
            type: 'new_order',
            userId: order.storeId, // Lojista
            title: 'Novo pedido!',
            message: `${order.customerName} comprou ${order.productName}`,
            data: order,
            read: false,
            createdAt: new Date()
        });
    },

    // Notificar pagamento recebido
    notifyPaymentReceived(order) {
        this.sendPush(`Pagamento confirmado!`, {
            body: `Pedido #${order.id.slice(-6)} foi pago.`,
            tag: `payment-${order.id}`
        });

        this.saveNotification({
            type: 'payment_received',
            userId: order.storeId,
            title: 'Pagamento confirmado',
            message: `R$ ${order.total.toFixed(2)} recebido`,
            data: order,
            read: false,
            createdAt: new Date()
        });
    },

    // Notificar aluguel próximo do vencimento
    notifyRentalDue(rental, daysLeft) {
        const store = Stores.data.find(s => s.id === rental.storeId);
        if (!store) return;

        this.sendPush(`Aluguel vence em ${daysLeft} dias`, {
            body: `R$ ${rental.amount.toFixed(2)} - ${store.name}`,
            tag: `rental-${rental.id}`
        });
    },

    // Salvar notificação no Firestore
    async saveNotification(data) {
        const db = window.firebaseDb;
        const { collection, addDoc } = await import("https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js");

        try {
            await addDoc(collection(db, 'notifications'), data);
        } catch (error) {
            console.error('Erro ao salvar notificação:', error);
        }
    },

    // Carregar notificações do usuário
    async loadUserNotifications(userId, limit = 20) {
        const db = window.firebaseDb;
        const { collection, query, where, orderBy, limit: limitQuery, getDocs, updateDoc, doc } = await import("https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js");

        const q = query(
            collection(db, 'notifications'),
            where('userId', '==', userId),
            orderBy('createdAt', 'desc'),
            limitQuery(limit)
        );

        const snapshot = await getDocs(q);
        return snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
    },

    // Marcar como lida
    async markAsRead(notificationId) {
        const db = window.firebaseDb;
        const { updateDoc, doc } = await import("https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js");

        await updateDoc(doc(db, 'notifications', notificationId), {
            read: true,
            readAt: new Date()
        });
    },

    // Renderizar ícone de notificações com badge
    renderNotificationIcon(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        this.getUnreadCount(Auth.userData?.id).then(count => {
            container.innerHTML = `
                <button onclick="Notifications.showNotificationPanel()" class="relative p-2 glass rounded-full hover:bg-white/10">
                    <i class="fas fa-bell text-lg"></i>
                    ${count > 0 ? `<span class="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs flex items-center justify-center">${count}</span>` : ''}
                </button>
            `;
        });
    },

    async getUnreadCount(userId) {
        if (!userId) return 0;
        
        const notifications = await this.loadUserNotifications(userId, 50);
        return notifications.filter(n => !n.read).length;
    },

    // Painel de notificações
    async showNotificationPanel() {
        const notifications = await this.loadUserNotifications(Auth.userData?.id);
        
        const panel = document.createElement('div');
        panel.className = 'fixed inset-0 z-[90] flex items-start justify-end p-4 pt-20';
        panel.innerHTML = `
            <div class="absolute inset-0 bg-black/50" onclick="this.parentElement.remove()"></div>
            <div class="glass-strong w-full max-w-md max-h-[80vh] overflow-y-auto rounded-2xl relative z-10 animate-fade-in-down">
                <div class="p-4 border-b border-gray-700 flex items-center justify-between">
                    <h3 class="font-bold text-lg">Notificações</h3>
                    <button onclick="this.closest('.fixed').remove()" class="text-gray-400 hover:text-white">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="divide-y divide-gray-700">
                    ${notifications.length === 0 ? `
                        <div class="p-8 text-center text-gray-500">
                            <i class="fas fa-bell-slash text-3xl mb-3"></i>
                            <p>Sem notificações</p>
                        </div>
                    ` : notifications.map(n => `
                        <div class="p-4 ${n.read ? 'opacity-60' : 'bg-white/5'} hover:bg-white/10 cursor-pointer" onclick="Notifications.markAsRead('${n.id}'); this.classList.add('opacity-60')">
                            <div class="flex items-start gap-3">
                                <div class="w-2 h-2 rounded-full ${n.read ? 'bg-gray-500' : 'bg-primary'} mt-2"></div>
                                <div class="flex-1">
                                    <p class="font-medium ${n.read ? 'text-gray-400' : 'text-white'}">${n.title}</p>
                                    <p class="text-sm text-gray-400">${n.message}</p>
                                    <p class="text-xs text-gray-500 mt-1">${Utils.formatDate(n.createdAt)}</p>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        
        document.body.appendChild(panel);
    }
};

// Inicializar permissão ao carregar
if ('Notification' in window && Notification.permission === 'default') {
    // Solicitar após interação do usuário
    document.addEventListener('click', function requestOnce() {
        Notifications.requestPermission();
        document.removeEventListener('click', requestOnce);
    }, { once: true });
}

window.Notifications = Notifications;
export default Notifications;