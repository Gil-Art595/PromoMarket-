// ==========================================
// OWNER PANEL - VERSÃO FINAL CORRIGIDA
// USA O MESMO SISTEMA DO PRODUCTS.JS (array items na loja)
// ==========================================

import { 
    doc, 
    getDoc, 
    updateDoc, 
    setDoc,
    deleteDoc,
    collection, 
    query, 
    where, 
    onSnapshot,
    orderBy,
    serverTimestamp,
    getDocs,
    limit
} from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";
import { 
    ref, 
    uploadBytes, 
    getDownloadURL 
} from "https://www.gstatic.com/firebasejs/12.9.0/firebase-storage.js";
import { 
    onAuthStateChanged,
    signOut 
} from "https://www.gstatic.com/firebasejs/12.9.0/firebase-auth.js";

// Configuração de compressão de imagem (igual products.js)
const IMAGE_CONFIG = {
    maxSizeMB: 0.4,
    maxWidthOrHeight: 800,
    useWebWorker: true,
    fileType: 'image/jpeg',
    initialQuality: 0.7
};

const db = window.firebaseDb;
const auth = window.firebaseAuth;
const storage = window.firebaseStorage;

const OwnerPanel = {
    store: null,
    currentUser: null,
    currentTab: 'overview',
    listeners: [],
    currentProductId: null,
    tempVariations: [],
    tempPromotions: [],
    
    async init() {
        onAuthStateChanged(auth, async (user) => {
            if (!user) {
                window.location.href = 'index.html';
                return;
            }
            
            this.currentUser = user;
            await this.loadStoreData();
            this.setupEventListeners();
            this.showTab('overview');
            
            document.getElementById('loadingScreen').style.display = 'none';
        });
    },

    async loadStoreData() {
        try {
            const storesQuery = query(
                collection(db, 'stores'),
                where('ownerId', '==', this.currentUser.uid),
                limit(1)
            );
            
            const snapshot = await getDocs(storesQuery);
            
            if (snapshot.empty) {
                this.showToast('Erro', 'Você não possui uma loja cadastrada', 'error');
                return;
            }
            
            const storeDoc = snapshot.docs[0];
            this.store = { id: storeDoc.id, ...storeDoc.data() };
            
            this.updateSidebarInfo();
            this.updateUserInfo();
            this.setupRealtimeListeners();
            
        } catch (error) {
            console.error('Erro ao carregar loja:', error);
            this.showToast('Erro', 'Erro ao carregar dados da loja', 'error');
        }
    },

    updateSidebarInfo() {
        const elName = document.getElementById('sidebarStoreName');
        const elLogo = document.getElementById('sidebarStoreLogo');
        
        if (elName) elName.textContent = this.store.name || 'Sem nome';
        if (elLogo) elLogo.src = this.store.logo || this.store.image || 'https://via.placeholder.com/100?text=Logo';
    },

    updateUserInfo() {
        const elName = document.getElementById('userName');
        const elAvatar = document.getElementById('userAvatar');
        
        if (elName) elName.textContent = this.currentUser.displayName || this.currentUser.email;
        if (elAvatar) elAvatar.src = this.currentUser.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(this.currentUser.displayName || 'User')}&background=f97316&color=fff`;
    },

    setupRealtimeListeners() {
        // Listener para a loja (inclui array items)
        const storeUnsub = onSnapshot(doc(db, 'stores', this.store.id), (doc) => {
            if (doc.exists()) {
                this.store = { id: doc.id, ...doc.data() };
                
                const badge = document.getElementById('productsBadge');
                const items = this.store.items || [];
                if (badge) {
                    badge.textContent = items.length;
                    badge.classList.remove('hidden');
                }
                
                if (this.currentTab === 'products') {
                    this.renderProductsList(items);
                } else if (this.currentTab === 'overview') {
                    this.renderOverview(document.getElementById('contentArea'));
                }
            }
        });
        
        this.listeners.push(storeUnsub);
        
        // Pedidos
        const ordersQuery = query(
            collection(db, 'orders'),
            where('storeId', '==', this.store.id),
            orderBy('createdAt', 'desc')
        );
        
        const ordersUnsub = onSnapshot(ordersQuery, (snapshot) => {
            this.store.orders = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
        });
        
        this.listeners.push(ordersUnsub);
    },

    setupEventListeners() {
        const menuBtn = document.getElementById('mobileMenuBtn');
        if (menuBtn) {
            menuBtn.addEventListener('click', () => {
                document.getElementById('sidebar').classList.toggle('open');
            });
        }
    },

    showTab(tab) {
        this.currentTab = tab;
        
        document.querySelectorAll('.owner-tab').forEach(t => {
            t.classList.remove('active', 'bg-primary/10', 'text-white');
            t.classList.add('text-gray-300');
        });
        
        const activeTab = document.querySelector(`.owner-tab[data-tab="${tab}"]`);
        if (activeTab) {
            activeTab.classList.add('active', 'bg-primary/10', 'text-white');
            activeTab.classList.remove('text-gray-300');
        }
        
        const titles = {
            overview: { title: 'Visão Geral', subtitle: 'Acompanhe o desempenho da sua loja' },
            products: { title: 'Produtos', subtitle: 'Gerencie seu catálogo' },
            orders: { title: 'Pedidos', subtitle: 'Acompanhe e gerencie vendas' },
            chats: { title: 'Conversas', subtitle: 'Converse com seus clientes' },
            coupons: { title: 'Cupons', subtitle: 'Crie promoções especiais' },
            reports: { title: 'Relatórios', subtitle: 'Análise detalhada de vendas' },
            editstore: { title: 'Aparência da Loja', subtitle: 'Personalize a identidade visual' },
            delivery: { title: 'Configurações de Entrega', subtitle: 'Defina taxas e opções' },
            payments: { title: 'Pagamentos', subtitle: 'Configure gateways de pagamento' }
        };
        
        const titleInfo = titles[tab] || titles.overview;
        const pageTitle = document.getElementById('pageTitle');
        const pageSubtitle = document.getElementById('pageSubtitle');
        
        if (pageTitle) pageTitle.textContent = titleInfo.title;
        if (pageSubtitle) pageSubtitle.textContent = titleInfo.subtitle;
        
        const contentArea = document.getElementById('contentArea');
        if (contentArea) {
            contentArea.innerHTML = '<div class="flex items-center justify-center h-64"><i class="fas fa-spinner fa-spin text-3xl text-primary"></i></div>';
        }
        
        switch(tab) {
            case 'overview':
                this.renderOverview(contentArea);
                break;
            case 'products':
                this.renderProducts(contentArea);
                break;
            case 'orders':
                this.renderOrders(contentArea);
                break;
            case 'chats':
                this.renderChats(contentArea);
                break;
            case 'coupons':
                this.renderCoupons(contentArea);
                break;
            case 'reports':
                this.renderReports(contentArea);
                break;
            case 'editstore':
                this.renderStoreCustomizer(contentArea);
                break;
            case 'delivery':
                this.renderDeliverySettings(contentArea);
                break;
            case 'payments':
                this.renderPaymentSettings(contentArea);
                break;
        }
        
        if (window.innerWidth < 1024) {
            const sidebar = document.getElementById('sidebar');
            if (sidebar) sidebar.classList.remove('open');
        }
    },

    renderOverview(container) {
        const orders = this.store.orders || [];
        const products = this.store.items || [];
        const totalSales = orders.reduce((sum, o) => sum + (o.total || 0), 0);
        const pendingOrders = orders.filter(o => o.status === 'pending').length;
        
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div class="stat-card rounded-2xl p-6 text-center">
                        <div class="text-3xl font-bold text-green-400 mb-1">R$ ${totalSales.toFixed(2)}</div>
                        <div class="text-sm text-gray-400">Total em Vendas</div>
                    </div>
                    <div class="stat-card rounded-2xl p-6 text-center">
                        <div class="text-3xl font-bold text-primary mb-1">${orders.length}</div>
                        <div class="text-sm text-gray-400">Pedidos</div>
                    </div>
                    <div class="stat-card rounded-2xl p-6 text-center">
                        <div class="text-3xl font-bold text-orange-400 mb-1">${pendingOrders}</div>
                        <div class="text-sm text-gray-400">Pendentes</div>
                    </div>
                    <div class="stat-card rounded-2xl p-6 text-center">
                        <div class="text-3xl font-bold text-accent mb-1">${products.length}</div>
                        <div class="text-sm text-gray-400">Produtos</div>
                    </div>
                </div>

                <div class="glass rounded-2xl p-6">
                    <h3 class="font-bold text-lg mb-4">Ações Rápidas</h3>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <button onclick="OwnerPanel.openProductModal()" class="p-4 glass rounded-xl hover:bg-primary/20 transition-colors text-center group">
                            <i class="fas fa-plus text-2xl text-primary mb-2 group-hover:scale-110 transition-transform"></i>
                            <p class="text-sm">Novo Produto</p>
                        </button>
                        <button onclick="OwnerPanel.showTab('coupons')" class="p-4 glass rounded-xl hover:bg-orange-500/20 transition-colors text-center group">
                            <i class="fas fa-ticket-alt text-2xl text-orange-400 mb-2 group-hover:scale-110 transition-transform"></i>
                            <p class="text-sm">Criar Cupom</p>
                        </button>
                        <button onclick="OwnerPanel.showTab('chats')" class="p-4 glass rounded-xl hover:bg-green-500/20 transition-colors text-center group">
                            <i class="fas fa-comments text-2xl text-green-400 mb-2 group-hover:scale-110 transition-transform"></i>
                            <p class="text-sm">Ver Conversas</p>
                        </button>
                        <button onclick="OwnerPanel.showTab('editstore')" class="p-4 glass rounded-xl hover:bg-purple-500/20 transition-colors text-center group">
                            <i class="fas fa-paint-brush text-2xl text-purple-400 mb-2 group-hover:scale-110 transition-transform"></i>
                            <p class="text-sm">Personalizar</p>
                        </button>
                    </div>
                </div>

                <div class="grid lg:grid-cols-2 gap-6">
                    <div class="glass rounded-2xl p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="font-bold text-lg">Últimos Pedidos</h3>
                            <button onclick="OwnerPanel.showTab('orders')" class="text-sm text-primary hover:text-white">Ver todos →</button>
                        </div>
                        ${orders.slice(0, 5).length > 0 ? `
                            <div class="space-y-3">
                                ${orders.slice(0, 5).map(order => `
                                    <div class="flex items-center justify-between p-3 bg-white/5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer">
                                        <div class="flex items-center gap-3">
                                            <div class="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                                                <i class="fas fa-shopping-bag text-primary"></i>
                                            </div>
                                            <div>
                                                <p class="font-medium text-sm">#${order.id?.slice(-6).toUpperCase()}</p>
                                                <p class="text-xs text-gray-400">${order.customerName || 'Cliente'}</p>
                                            </div>
                                        </div>
                                        <div class="text-right">
                                            <p class="font-medium">R$ ${(order.total || 0).toFixed(2)}</p>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        ` : `
                            <div class="text-center py-8 text-gray-500">
                                <p>Nenhum pedido ainda</p>
                            </div>
                        `}
                    </div>

                    <div class="glass rounded-2xl p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="font-bold text-lg">Seus Produtos</h3>
                            <button onclick="OwnerPanel.showTab('products')" class="text-sm text-primary hover:text-white">Ver todos →</button>
                        </div>
                        ${products.slice(0, 4).length > 0 ? `
                            <div class="grid grid-cols-2 gap-3">
                                ${products.slice(0, 4).map(product => `
                                    <div class="glass rounded-lg overflow-hidden group cursor-pointer hover:ring-2 ring-primary/50 transition-all"
                                         onclick="OwnerPanel.editProduct('${product.id}')">
                                        <div class="aspect-square overflow-hidden">
                                            <img src="${product.image || 'https://via.placeholder.com/150'}" 
                                                class="w-full h-full object-cover group-hover:scale-110 transition-transform">
                                        </div>
                                        <div class="p-2">
                                            <p class="text-sm font-medium truncate">${product.name}</p>
                                            <p class="text-xs text-primary">R$ ${(product.price || 0).toFixed(2)}</p>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        ` : `
                            <div class="text-center py-8 text-gray-500">
                                <p>Nenhum produto cadastrado</p>
                            </div>
                        `}
                    </div>
                </div>
            </div>
        `;
    },

    renderProducts(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <div class="relative">
                        <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input type="text" id="productSearch" placeholder="Buscar produtos..."
                            onkeyup="OwnerPanel.filterProducts(this.value)"
                            class="input-field pl-10 pr-4 py-2 rounded-xl w-64">
                    </div>
                    <button onclick="OwnerPanel.openProductModal()" class="btn btn-primary">
                        <i class="fas fa-plus mr-2"></i> Novo Produto
                    </button>
                </div>

                <div id="productsGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    <div class="col-span-full text-center py-12">
                        <i class="fas fa-spinner fa-spin text-3xl text-primary"></i>
                    </div>
                </div>
            </div>
        `;
        
        this.renderProductsList(this.store.items || []);
    },

    renderProductsList(products) {
        const container = document.getElementById('productsGrid');
        if (!container) return;
        
        if (products.length === 0) {
            container.innerHTML = `
                <div class="col-span-full text-center py-12 text-gray-500">
                    <i class="fas fa-box-open text-5xl mb-4 opacity-50"></i>
                    <p class="mb-4">Nenhum produto cadastrado</p>
                    <button onclick="OwnerPanel.openProductModal()" class="btn btn-primary">
                        <i class="fas fa-plus mr-2"></i> Adicionar primeiro produto
                    </button>
                </div>
            `;
            return;
        }
        
        container.innerHTML = products.map(product => {
            const discount = product.oldPrice ? Math.round((1 - product.price/product.oldPrice) * 100) : 0;
            
            return `
                <div class="product-card group">
                    <div class="image-container aspect-square relative">
                        <img src="${product.image || 'https://via.placeholder.com/300'}" 
                            alt="${product.name}" class="w-full h-full object-cover">
                        ${discount > 0 ? `
                            <div class="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                                -${discount}%
                            </div>
                        ` : ''}
                        ${product.featured ? `
                            <div class="absolute top-2 right-2 bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded">
                                Destaque
                            </div>
                        ` : ''}
                        <div class="actions">
                            <button onclick="event.stopPropagation(); OwnerPanel.editProduct('${product.id}')" 
                                class="w-12 h-12 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white backdrop-blur-sm transition-colors">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button onclick="event.stopPropagation(); OwnerPanel.deleteProduct('${product.id}')" 
                                class="w-12 h-12 rounded-full bg-red-500/20 hover:bg-red-500/30 text-red-400 flex items-center justify-center backdrop-blur-sm transition-colors">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                        ${product.stock < 5 ? `
                            <div class="absolute bottom-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
                                Estoque: ${product.stock}
                            </div>
                        ` : ''}
                    </div>
                    <div class="p-4">
                        <h3 class="font-bold mb-1 truncate">${product.name}</h3>
                        <p class="text-sm text-gray-400 mb-2 line-clamp-2">${product.description || 'Sem descrição'}</p>
                        <div class="flex items-center justify-between">
                            <div>
                                <span class="text-primary font-bold text-lg">R$ ${(product.price || 0).toFixed(2)}</span>
                                ${product.oldPrice ? `<span class="text-gray-500 text-sm line-through ml-2">R$ ${product.oldPrice.toFixed(2)}</span>` : ''}
                            </div>
                        </div>
                        <div class="flex items-center justify-between mt-2 text-sm">
                            <span class="text-gray-400">Estoque: ${product.stock || 0}</span>
                            <span class="text-gray-500 capitalize">${product.category || 'geral'}</span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    },

    filterProducts(search) {
        const products = this.store.items || [];
        const filtered = products.filter(p => 
            p.name.toLowerCase().includes(search.toLowerCase()) ||
            p.description?.toLowerCase().includes(search.toLowerCase())
        );
        this.renderProductsList(filtered);
    },

    // ==========================================
    // MODAL DE PRODUTO COMPLETO
    // ==========================================
    openProductModal(productId = null) {
        this.currentProductId = productId;
        this.tempVariations = [];
        this.tempPromotions = [];
        
        const product = productId ? this.store.items.find(p => p.id === productId) : null;
        
        if (product) {
            this.tempVariations = product.variations ? [...product.variations] : [];
            this.tempPromotions = product.promotions ? [...product.promotions] : [];
        }
        
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'productModal';
        modal.innerHTML = `
            <div class="modal-content max-w-2xl max-h-[90vh] overflow-y-auto">
                <div class="p-6 border-b border-white/10 flex items-center justify-between">
                    <h3 class="text-xl font-bold">${product ? 'Editar' : 'Novo'} Produto</h3>
                    <button onclick="OwnerPanel.closeProductModal()" class="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <form id="productForm" class="p-6 space-y-4" onsubmit="event.preventDefault();">
                    
                    <!-- Imagem -->
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Foto do Produto</label>
                        <div class="relative group">
                            <input type="file" id="productImage" accept="image/jpeg,image/png,image/webp" class="hidden" onchange="OwnerPanel.previewProductImage(event)">
                            <label for="productImage" class="cursor-pointer block">
                                <div class="aspect-video rounded-xl border-2 border-dashed border-white/20 hover:border-primary transition-colors overflow-hidden bg-white/5 flex items-center justify-center relative">
                                    <img id="productImagePreview" src="${product?.image || 'https://via.placeholder.com/400x400?text=Clique+para+adicionar+foto'}" 
                                        class="w-full h-full object-cover">
                                    <div id="productImageOverlay" class="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                        <span class="text-white"><i class="fas fa-camera mr-2"></i>Alterar foto</span>
                                    </div>
                                </div>
                            </label>
                        </div>
                        <p class="text-xs text-gray-500 mt-1">A imagem será otimizada automaticamente</p>
                    </div>

                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Nome do Produto *</label>
                            <input type="text" id="productName" required value="${product?.name || ''}" class="input-field" placeholder="Ex: Camiseta Preta">
                        </div>
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Categoria</label>
                            <select id="productCategory" class="input-field">
                                <option value="geral" ${product?.category === 'geral' ? 'selected' : ''}>Geral</option>
                                <option value="eletronicos" ${product?.category === 'eletronicos' ? 'selected' : ''}>Eletrônicos</option>
                                <option value="moda" ${product?.category === 'moda' ? 'selected' : ''}>Moda</option>
                                <option value="casa" ${product?.category === 'casa' ? 'selected' : ''}>Casa e Decoração</option>
                                <option value="alimentos" ${product?.category === 'alimentos' ? 'selected' : ''}>Alimentos</option>
                                <option value="beleza" ${product?.category === 'beleza' ? 'selected' : ''}>Beleza</option>
                                <option value="esportes" ${product?.category === 'esportes' ? 'selected' : ''}>Esportes</option>
                                <option value="supermercado" ${product?.category === 'supermercado' ? 'selected' : ''}>Supermercado</option>
                            </select>
                        </div>
                    </div>

                    <div class="grid md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Preço Atual (R$) *</label>
                            <input type="number" id="productPrice" required step="0.01" min="0" value="${product?.price || ''}" class="input-field" placeholder="29.90">
                        </div>
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Preço Antigo (R$)</label>
                            <input type="number" id="productOldPrice" step="0.01" min="0" value="${product?.oldPrice || ''}" class="input-field" placeholder="39.90">
                        </div>
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Estoque *</label>
                            <input type="number" id="productStock" required min="0" value="${product?.stock ?? 10}" class="input-field" placeholder="10">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Descrição</label>
                        <textarea id="productDescription" rows="3" class="input-field resize-none" placeholder="Descreva seu produto...">${product?.description || ''}</textarea>
                    </div>

                    <!-- Variações -->
                    <div class="glass rounded-xl p-4 border border-white/10">
                        <div class="flex items-center justify-between mb-3">
                            <label class="text-sm font-medium text-gray-300">Variações</label>
                            <button type="button" onclick="OwnerPanel.addVariation()" class="text-sm text-primary hover:text-white">
                                <i class="fas fa-plus mr-1"></i> Adicionar
                            </button>
                        </div>
                        <div id="productVariations" class="space-y-2">
                            <p class="text-gray-500 text-sm">Nenhuma variação</p>
                        </div>
                    </div>

                    <!-- Promoções -->
                    <div class="glass rounded-xl p-4 border border-orange-500/30 bg-gradient-to-br from-orange-500/5 to-red-500/5">
                        <div class="flex items-center justify-between mb-3">
                            <label class="text-sm font-medium text-orange-400"><i class="fas fa-fire mr-2"></i>Promoções</label>
                            <button type="button" onclick="OwnerPanel.addPromotion()" class="text-sm text-orange-400 hover:text-orange-300">
                                <i class="fas fa-plus mr-1"></i> Nova
                            </button>
                        </div>
                        <div id="productPromotions" class="space-y-2">
                            <p class="text-gray-500 text-sm" id="noPromotionsMsg">Nenhuma promoção</p>
                        </div>
                    </div>

                    <div class="flex items-center gap-6 pt-2">
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" id="productActive" ${product?.active !== false ? 'checked' : ''} class="w-4 h-4 rounded bg-gray-700 border-gray-600">
                            <span class="text-sm text-gray-300">Produto ativo</span>
                        </label>
                        <label class="flex items-center gap-2 cursor-pointer">
                            <input type="checkbox" id="productFeatured" ${product?.featured ? 'checked' : ''} class="w-4 h-4 rounded bg-gray-700 border-gray-600">
                            <span class="text-sm text-orange-400"><i class="fas fa-star mr-1"></i>Destaque na loja</span>
                        </label>
                    </div>

                    <div class="flex gap-3 pt-4 border-t border-white/10">
                        <button type="button" onclick="OwnerPanel.closeProductModal()" class="btn btn-secondary flex-1">Cancelar</button>
                        <button type="button" onclick="OwnerPanel.saveProduct()" class="btn btn-primary flex-1" id="saveProductBtn">
                            <i class="fas fa-save mr-2"></i> ${product ? 'Salvar' : 'Criar'} Produto
                        </button>
                    </div>
                </form>
            </div>
        `;
        document.body.appendChild(modal);
        
        // Renderizar variações e promoções se existirem
        this.renderVariations();
        this.renderPromotions();
    },

    closeProductModal() {
        const modal = document.getElementById('productModal');
        if (modal) modal.remove();
        this.currentProductId = null;
        this.tempVariations = [];
        this.tempPromotions = [];
    },

    previewProductImage(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            const preview = document.getElementById('productImagePreview');
            if (preview) {
                preview.src = e.target.result;
                preview.dataset.hasNewImage = 'true';
            }
        };
        reader.readAsDataURL(file);
    },

    // ==========================================
    // VARIAÇÕES
    // ==========================================
    addVariation() {
        const name = prompt('Nome da variação (ex: Tamanho, Cor):');
        if (!name) return;

        const options = prompt('Opções separadas por vírgula (ex: P, M, G):');
        if (!options) return;

        this.tempVariations.push({
            name: name.trim(),
            options: options.split(',').map(o => o.trim())
        });

        this.renderVariations();
    },

    removeVariation(index) {
        this.tempVariations.splice(index, 1);
        this.renderVariations();
    },

    renderVariations() {
        const container = document.getElementById('productVariations');
        if (!container) return;

        if (this.tempVariations.length === 0) {
            container.innerHTML = '<p class="text-gray-500 text-sm">Nenhuma variação</p>';
            return;
        }

        container.innerHTML = this.tempVariations.map((v, i) => `
            <div class="flex items-center justify-between p-2 bg-gray-800/50 rounded-lg">
                <div>
                    <span class="font-medium text-sm">${v.name}</span>
                    <span class="text-gray-400 text-xs ml-2">${v.options.join(', ')}</span>
                </div>
                <button onclick="OwnerPanel.removeVariation(${i})" class="text-red-400 hover:text-red-300">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `).join('');
    },

    // ==========================================
    // PROMOÇÕES
    // ==========================================
    addPromotion() {
        const highlight = prompt('Destaque da promoção (ex: 20% OFF, Leve 3 Pague 2):');
        if (!highlight) return;

        const discount = prompt('Valor do desconto em % (número apenas):');
        if (!discount || isNaN(discount)) return;

        this.tempPromotions.push({
            id: this.generateId(),
            highlight: highlight.trim(),
            discount: parseInt(discount),
            active: true,
            startDate: new Date().toISOString(),
            endDate: null
        });

        this.renderPromotions();
    },

    removePromotion(index) {
        this.tempPromotions.splice(index, 1);
        this.renderPromotions();
    },

    togglePromotion(index) {
        this.tempPromotions[index].active = !this.tempPromotions[index].active;
        this.renderPromotions();
    },

    renderPromotions() {
        const container = document.getElementById('productPromotions');
        const noMsg = document.getElementById('noPromotionsMsg');
        
        if (!container) return;

        if (this.tempPromotions.length === 0) {
            container.innerHTML = '<p class="text-gray-500 text-sm" id="noPromotionsMsg">Nenhuma promoção</p>';
            return;
        }

        container.innerHTML = this.tempPromotions.map((p, i) => `
            <div class="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg border ${p.active ? 'border-orange-500/30' : 'border-gray-700'}">
                <div class="flex items-center gap-3">
                    <button onclick="OwnerPanel.togglePromotion(${i})" class="${p.active ? 'text-green-400' : 'text-gray-500'}">
                        <i class="fas ${p.active ? 'fa-check-circle' : 'fa-circle'}"></i>
                    </button>
                    <div>
                        <span class="font-medium text-sm ${p.active ? 'text-orange-400' : 'text-gray-400'}">${p.highlight}</span>
                        <span class="text-gray-500 text-xs ml-2">${p.discount}% OFF</span>
                    </div>
                </div>
                <button onclick="OwnerPanel.removePromotion(${i})" class="text-red-400 hover:text-red-300">
                    <i class="fas fa-trash text-xs"></i>
                </button>
            </div>
        `).join('');
    },

    // ==========================================
    // ✅ SAVE PRODUCT - CORRIGIDO (SEM serverTimestamp NO ARRAY)
    // ==========================================
    async saveProduct() {
        const btn = document.getElementById('saveProductBtn');
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Salvando...';
        btn.disabled = true;

        try {
            // Validar campos obrigatórios
            const name = document.getElementById('productName').value.trim();
            const price = parseFloat(document.getElementById('productPrice').value);
            const stock = parseInt(document.getElementById('productStock').value);

            if (!name) throw new Error('Nome do produto é obrigatório');
            if (isNaN(price) || price <= 0) throw new Error('Preço deve ser maior que zero');
            if (isNaN(stock) || stock < 0) throw new Error('Estoque inválido');

            // Processar imagem
            let imageUrl = null;
            const fileInput = document.getElementById('productImage');
            const preview = document.getElementById('productImagePreview');

            if (fileInput?.files?.[0] && preview?.dataset?.hasNewImage === 'true') {
                // Comprimir e fazer upload
                const compressedFile = await this.optimizeImage(fileInput.files[0]);
                
                // Tentar base64 primeiro (grátis)
                const base64 = await this.fileToBase64(compressedFile);
                const base64Size = this.base64Size(base64);

                if (base64Size < 400 * 1024) {
                    imageUrl = base64;
                    this.showToast('Info', 'Imagem otimizada (modo econômico)', 'info');
                } else {
                    // Upload para Storage
                    const storageRef = ref(storage, `stores/${this.store.id}/products/${Date.now()}.jpg`);
                    await uploadBytes(storageRef, compressedFile);
                    imageUrl = await getDownloadURL(storageRef);
                }
            }

            // ✅ CORREÇÃO: Usar new Date().toISOString() em vez de serverTimestamp() dentro do array
            const isNew = !this.currentProductId;
            const productData = {
                id: isNew ? this.generateId() : this.currentProductId,
                name: name,
                category: document.getElementById('productCategory').value,
                price: price,
                oldPrice: parseFloat(document.getElementById('productOldPrice').value) || null,
                stock: stock,
                description: document.getElementById('productDescription').value.trim(),
                image: imageUrl || preview?.src || 'https://via.placeholder.com/400x400?text=Produto',
                active: document.getElementById('productActive').checked,
                featured: document.getElementById('productFeatured').checked,
                variations: this.tempVariations,
                promotions: this.tempPromotions,
                updatedAt: new Date().toISOString()  // ✅ Data normal, não serverTimestamp
            };

            // Atualizar array items da loja (IGUAL PRODUCTS.JS)
            const items = [...(this.store.items || [])];

            if (isNew) {
                items.push(productData);
            } else {
                const index = items.findIndex(i => i.id === this.currentProductId);
                if (index !== -1) {
                    items[index] = productData;
                } else {
                    items.push(productData);
                }
            }

            // ✅ serverTimestamp só aqui, fora do array
            await updateDoc(doc(db, 'stores', this.store.id), {
                items: items,
                updatedAt: serverTimestamp()  // ✅ Aqui pode usar serverTimestamp!
            });

            // Atualizar flag de promoção da loja
            const hasActivePromo = items.some(i => i.promotions?.some(p => p.active));
            if (hasActivePromo !== this.store.hasPromotion) {
                await updateDoc(doc(db, 'stores', this.store.id), { 
                    hasPromotion: hasActivePromo 
                });
            }

            this.showToast('Sucesso', isNew ? 'Produto criado!' : 'Produto atualizado!');
            this.closeProductModal();

        } catch (error) {
            console.error('Erro ao salvar:', error);
            this.showToast('Erro', error.message || 'Erro ao salvar produto', 'error');
        } finally {
            btn.innerHTML = originalText;
            btn.disabled = false;
        }
    },

    // ==========================================
    // UTILITÁRIOS DE IMAGEM (IGUAL PRODUCTS.JS)
    // ==========================================
    async optimizeImage(file) {
        if (typeof imageCompression !== 'undefined') {
            try {
                return await imageCompression(file, IMAGE_CONFIG);
            } catch (e) {
                console.log('Compressão falhou, usando original');
                return file;
            }
        }
        return file;
    },

    fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    },

    base64Size(base64) {
        const base64Length = base64.substr(base64.indexOf(',') + 1).length;
        return (base64Length * 3) / 4;
    },

    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
    },

    editProduct(productId) {
        this.openProductModal(productId);
    },

    async deleteProduct(productId) {
        if (!confirm('Tem certeza que deseja excluir este produto?')) return;
        
        try {
            const items = this.store.items.filter(i => i.id !== productId);
            
            await updateDoc(doc(db, 'stores', this.store.id), {
                items: items,
                updatedAt: serverTimestamp()  // ✅ serverTimestamp fora do array
            });
            
            this.showToast('Sucesso', 'Produto excluído!');
        } catch (error) {
            console.error('Erro ao excluir:', error);
            this.showToast('Erro', 'Erro ao excluir produto', 'error');
        }
    },

    // ==========================================
    // OUTRAS ABAS
    // ==========================================
    renderOrders(container) {
        container.innerHTML = `<div class="p-6"><h2>Pedidos</h2><p>Carregando...</p></div>`;
    },

    renderChats(container) {
        container.innerHTML = `<div class="p-6"><h2>Conversas</h2><p>Em desenvolvimento...</p></div>`;
    },

    renderCoupons(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in p-6">
                <div class="flex items-center justify-between">
                    <h2 class="text-2xl font-bold">Cupons</h2>
                    <button onclick="OwnerPanel.openCouponModal()" class="btn btn-primary">
                        <i class="fas fa-plus mr-2"></i> Novo Cupom
                    </button>
                </div>
                <div id="couponsList">Carregando...</div>
            </div>
        `;
        this.loadCoupons();
    },

    async loadCoupons() {
        try {
            const couponsQuery = query(
                collection(db, 'coupons'),
                where('storeId', '==', this.store.id),
                orderBy('createdAt', 'desc')
            );
            
            const snapshot = await getDocs(couponsQuery);
            const coupons = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
            
            const container = document.getElementById('couponsList');
            if (!container) return;
            
            if (coupons.length === 0) {
                container.innerHTML = `<p class="text-gray-500 text-center py-8">Nenhum cupom criado</p>`;
                return;
            }
            
            container.innerHTML = coupons.map(c => `
                <div class="glass rounded-xl p-4 mb-3 flex justify-between items-center">
                    <div>
                        <span class="font-bold text-primary text-lg">${c.code}</span>
                        <p class="text-sm text-gray-400">${c.type === 'percentage' ? c.value + '% OFF' : 'R$ ' + c.value.toFixed(2) + ' OFF'}</p>
                    </div>
                    <span class="px-3 py-1 rounded-full text-xs ${c.active ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}">
                        ${c.active ? 'Ativo' : 'Inativo'}
                    </span>
                </div>
            `).join('');
            
        } catch (error) {
            console.error('Erro ao carregar cupons:', error);
        }
    },

    openCouponModal() {
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'couponModal';
        modal.innerHTML = `
            <div class="modal-content max-w-md">
                <div class="p-6 border-b border-white/10 flex justify-between items-center">
                    <h3 class="text-xl font-bold">Novo Cupom</h3>
                    <button onclick="document.getElementById('couponModal').remove()" class="text-gray-400 hover:text-white">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <form id="couponForm" class="p-6 space-y-4">
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Código *</label>
                        <input type="text" id="couponCode" required class="input-field uppercase font-mono text-center text-lg tracking-wider" placeholder="PROMO10">
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Tipo *</label>
                            <select id="couponType" class="input-field">
                                <option value="percentage">Porcentagem (%)</option>
                                <option value="fixed">Valor Fixo (R$)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Valor *</label>
                            <input type="number" id="couponValue" required step="0.01" min="0" class="input-field" placeholder="10">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Descrição</label>
                        <input type="text" id="couponDescription" class="input-field" placeholder="Ex: 10% de desconto na primeira compra">
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Mínimo de compra (R$)</label>
                            <input type="number" id="couponMinPurchase" step="0.01" min="0" value="0" class="input-field">
                        </div>
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Limite de usos</label>
                            <input type="number" id="couponMaxUses" min="1" class="input-field" placeholder="Ilimitado">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Data de expiração</label>
                        <input type="datetime-local" id="couponExpires" class="input-field">
                    </div>

                    <button type="button" onclick="OwnerPanel.saveCoupon()" class="btn btn-primary w-full" id="saveCouponBtn">
                        <i class="fas fa-save mr-2"></i> Criar Cupom
                    </button>
                </form>
            </div>
        `;
        document.body.appendChild(modal);
    },

    // ✅ CORREÇÃO: saveCoupon sem serverTimestamp no objeto
    async saveCoupon() {
        const btn = document.getElementById('saveCouponBtn');
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Criando...';
        btn.disabled = true;

        try {
            const code = document.getElementById('couponCode').value.toUpperCase().trim();
            const type = document.getElementById('couponType').value;
            const value = parseFloat(document.getElementById('couponValue').value);
            const description = document.getElementById('couponDescription').value.trim();
            const minPurchase = parseFloat(document.getElementById('couponMinPurchase').value) || 0;
            const maxUses = parseInt(document.getElementById('couponMaxUses').value) || null;
            const expiresAt = document.getElementById('couponExpires').value;

            if (!code || !value) {
                throw new Error('Preencha código e valor');
            }

            // ✅ CORREÇÃO: Usar new Date().toISOString() em vez de serverTimestamp()
            const couponData = {
                code,
                type,
                value,
                description,
                storeId: this.store.id,
                minPurchase,
                maxUses,
                usedCount: 0,
                active: true,
                expiresAt: expiresAt ? new Date(expiresAt).toISOString() : null,  // ✅ Data normal
                createdBy: this.currentUser.uid,
                createdAt: new Date().toISOString()  // ✅ Data normal, não serverTimestamp
            };

            const newDocRef = doc(collection(db, 'coupons'));
            await setDoc(newDocRef, couponData);

            this.showToast('Sucesso', 'Cupom criado!');
            document.getElementById('couponModal').remove();
            this.loadCoupons();

        } catch (error) {
            console.error('Erro ao criar cupom:', error);
            this.showToast('Erro', error.message, 'error');
        } finally {
            btn.innerHTML = originalText;
            btn.disabled = false;
        }
    },

    renderReports(container) {
        container.innerHTML = `<div class="p-6"><h2>Relatórios</h2><p>Em desenvolvimento...</p></div>`;
    },

    renderStoreCustomizer(container) {
        container.innerHTML = `
            <div class="p-6">
                <h2 class="text-2xl font-bold mb-4">Aparência da Loja</h2>
                <div class="glass rounded-xl p-6 space-y-4">
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Cor Principal</label>
                        <input type="color" id="storePrimaryColor" value="${this.store.primaryColor || '#f97316'}" class="w-full h-12 rounded-lg">
                    </div>
                    <button onclick="OwnerPanel.saveStoreAppearance()" class="btn btn-primary w-full">
                        <i class="fas fa-save mr-2"></i> Salvar Aparência
                    </button>
                </div>
            </div>
        `;
    },

    async saveStoreAppearance() {
        try {
            const primaryColor = document.getElementById('storePrimaryColor').value;
            await updateDoc(doc(db, 'stores', this.store.id), {
                primaryColor,
                updatedAt: serverTimestamp()  // ✅ serverTimestamp fora de array
            });
            this.showToast('Sucesso', 'Aparência salva!');
        } catch (error) {
            this.showToast('Erro', 'Erro ao salvar', 'error');
        }
    },

    renderDeliverySettings(container) {
        const config = this.store.deliveryOptions || { allowDelivery: true, allowPickup: true, deliveryFee: 0 };
        
        container.innerHTML = `
            <div class="p-6 max-w-2xl">
                <h2 class="text-2xl font-bold mb-6">Configurações de Entrega</h2>
                
                <div class="glass rounded-xl p-6 space-y-6">
                    <div class="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                        <div>
                            <h4 class="font-medium">Permitir Retirada na Loja</h4>
                            <p class="text-sm text-gray-400">Cliente pode buscar o pedido presencialmente</p>
                        </div>
                        <label class="toggle">
                            <input type="checkbox" id="allowPickup" ${config.allowPickup ? 'checked' : ''}>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div class="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                        <div>
                            <h4 class="font-medium">Permitir Entrega</h4>
                            <p class="text-sm text-gray-400">Você faz entrega na cidade</p>
                        </div>
                        <label class="toggle">
                            <input type="checkbox" id="allowDelivery" ${config.allowDelivery ? 'checked' : ''}>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div class="p-4 bg-white/5 rounded-lg">
                        <label class="block text-sm text-gray-400 mb-2">Taxa de Entrega (R$)</label>
                        <input type="number" id="deliveryFee" value="${config.deliveryFee || 0}" step="0.01" class="input-field" placeholder="0,00">
                        <p class="text-xs text-gray-500 mt-1">Deixe 0 para entrega grátis</p>
                    </div>

                    <button onclick="OwnerPanel.saveDeliveryConfig()" class="btn btn-primary w-full">
                        <i class="fas fa-save mr-2"></i> Salvar Configurações
                    </button>
                </div>
            </div>
        `;
    },

    async saveDeliveryConfig() {
        try {
            const config = {
                allowPickup: document.getElementById('allowPickup').checked,
                allowDelivery: document.getElementById('allowDelivery').checked,
                deliveryFee: parseFloat(document.getElementById('deliveryFee').value) || 0
            };

            await updateDoc(doc(db, 'stores', this.store.id), {
                deliveryOptions: config,
                updatedAt: serverTimestamp()  // ✅ serverTimestamp fora de array
            });

            this.store.deliveryOptions = config;
            this.showToast('Sucesso', 'Configurações salvas!');
        } catch (error) {
            this.showToast('Erro', 'Erro ao salvar', 'error');
        }
    },

    renderPaymentSettings(container) {
        container.innerHTML = `
            <div class="p-6 max-w-2xl">
                <h2 class="text-2xl font-bold mb-6">Pagamentos</h2>
                
                <div class="glass rounded-xl p-6 space-y-4">
                    <h3 class="font-bold">PIX Direto</h3>
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Chave PIX</label>
                        <input type="text" id="pixKey" value="${this.store.pixKey || ''}" class="input-field" placeholder="CPF, CNPJ, email ou celular">
                    </div>
                    <button onclick="OwnerPanel.savePaymentConfig()" class="btn btn-primary w-full">
                        Salvar
                    </button>
                </div>
            </div>
        `;
    },

    async savePaymentConfig() {
        try {
            const pixKey = document.getElementById('pixKey').value.trim();
            await updateDoc(doc(db, 'stores', this.store.id), {
                pixKey,
                updatedAt: serverTimestamp()  // ✅ serverTimestamp fora de array
            });
            this.showToast('Sucesso', 'Configurações salvas!');
        } catch (error) {
            this.showToast('Erro', 'Erro ao salvar', 'error');
        }
    },

    showToast(title, message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `fixed bottom-4 right-4 z-50 flex items-center gap-3 px-6 py-4 rounded-xl shadow-2xl transform translate-y-0 transition-all duration-300 ${type === 'success' ? 'bg-green-500 text-white' : type === 'error' ? 'bg-red-500 text-white' : 'bg-blue-500 text-white'}`;
        toast.innerHTML = `
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'} text-xl"></i>
            <div>
                <p class="font-bold">${title}</p>
                <p class="text-sm">${message}</p>
            </div>
        `;
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(100%)';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    },

    previewStore() {
        window.open(`index.html?store=${this.store.id}`, '_blank');
    },

    async logout() {
        try {
            await signOut(auth);
            window.location.href = 'index.html';
        } catch (error) {
            this.showToast('Erro', 'Erro ao fazer logout', 'error');
        }
    }
};

// Inicializar
document.addEventListener('DOMContentLoaded', () => {
    window.OwnerPanel = OwnerPanel;
    OwnerPanel.init();
});

export default OwnerPanel;