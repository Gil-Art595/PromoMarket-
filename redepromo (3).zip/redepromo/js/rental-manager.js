// ==========================================
// SISTEMA DE ALUGUEL AUTOMÁTICO - REDEPROMO
// ==========================================

import AsaasAPI from './asaas-api.js';
import AsaasConfig from './asaas-config.js';
import { 
    collection, doc, getDocs, getDoc, setDoc, updateDoc, deleteDoc, 
    query, where, orderBy, serverTimestamp, onSnapshot, addDoc 
} from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const db = window.firebaseDb || window.firebaseDbAdmin;

const RentalManager = {
    // ==========================================
    // CONFIGURAÇÃO DE ALUGUEL POR LOJA
    // ==========================================
    
    // Salvar configuração de aluguel para uma loja
    async saveRentalConfig(storeId, config) {
        try {
            const configRef = doc(db, 'rentalConfigs', storeId);
            await setDoc(configRef, {
                storeId: storeId,
                amount: parseFloat(config.amount),
                dueDay: parseInt(config.dueDay),
                enabled: config.enabled !== false,
                autoGenerate: config.autoGenerate !== false,
                description: config.description || AsaasConfig.defaultRental.description,
                updatedAt: serverTimestamp(),
                createdAt: serverTimestamp()
            });
            
            return { success: true, message: 'Configuração salva!' };
        } catch (error) {
            console.error('Erro ao salvar config:', error);
            return { success: false, message: error.message };
        }
    },
    
    // Buscar configuração de aluguel da loja
    async getRentalConfig(storeId) {
        try {
            const configDoc = await getDoc(doc(db, 'rentalConfigs', storeId));
            if (configDoc.exists()) {
                return configDoc.data();
            }
            
            // Retorna padrão se não existir
            return {
                amount: AsaasConfig.defaultRental.amount,
                dueDay: AsaasConfig.defaultRental.dueDay,
                enabled: true,
                autoGenerate: true
            };
        } catch (error) {
            console.error('Erro ao buscar config:', error);
            return null;
        }
    },
    
    // ==========================================
    // GERAÇÃO DE COBRANÇAS
    // ==========================================
    
    // Gerar cobrança manual para uma loja
    async generateRentalInvoice(storeId, month = null) {
        try {
            // 1. Buscar config da loja
            const config = await this.getRentalConfig(storeId);
            if (!config || !config.enabled) {
                throw new Error('Aluguel não configurado ou desativado');
            }
            
            // 2. Buscar dados da loja
            const storeDoc = await getDoc(doc(db, 'stores', storeId));
            if (!storeDoc.exists()) {
                throw new Error('Loja não encontrada');
            }
            
            const store = storeDoc.data();
            
            // 3. Verificar se já existe para o mês
            const targetMonth = month || new Date().toISOString().slice(0, 7);
            const existingQuery = query(
                collection(db, 'rentals'),
                where('storeId', '==', storeId),
                where('month', '==', targetMonth)
            );
            const existingDocs = await getDocs(existingQuery);
            
            if (!existingDocs.empty) {
                throw new Error(`Cobrança para ${targetMonth} já existe`);
            }
            
            // 4. Criar cliente no Asaas (se não existir)
            let customer = await AsaasAPI.findCustomer(store.ownerCpfCnpj || '00000000000');
            
            if (!customer) {
                customer = await AsaasAPI.createCustomer({
                    id: storeId,
                    name: store.name,
                    ownerName: store.ownerName,
                    ownerEmail: store.ownerEmail,
                    ownerPhone: store.ownerPhone,
                    ownerCpfCnpj: store.ownerCpfCnpj
                });
            }
            
            // 5. Criar cobrança no Asaas
            const payment = await AsaasAPI.createPayment(customer.id, {
                amount: config.amount,
                dueDay: config.dueDay,
                description: `${config.description} - ${store.name} (${targetMonth})`,
                storeId: storeId
            });
            
            // 6. Salvar no Firestore
            const rentalRef = doc(collection(db, 'rentals'));
            const rentalData = {
                id: rentalRef.id,
                storeId: storeId,
                storeName: store.name,
                month: targetMonth,
                amount: config.amount,
                dueDay: config.dueDay,
                dueDate: payment.dueDate,
                asaasCustomerId: customer.id,
                asaasPaymentId: payment.id,
                invoiceUrl: payment.invoiceUrl, // Link para pagamento
                bankSlipUrl: payment.bankSlipUrl, // Boleto
                pixQrCode: payment.pix?.qrCode, // PIX
                pixPayload: payment.pix?.payload, // Código PIX copia-e-cola
                status: this.mapAsaasStatus(payment.status),
                paidAt: null,
                confirmedBy: null,
                description: payment.description,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            };
            
            await setDoc(rentalRef, rentalData);
            
            return { 
                success: true, 
                message: 'Cobrança gerada!',
                rental: rentalData
            };
            
        } catch (error) {
            console.error('Erro ao gerar cobrança:', error);
            return { success: false, message: error.message };
        }
    },
    
    // Criar assinatura recorrente (automática todo mês)
    async createRentalSubscription(storeId) {
        try {
            const config = await this.getRentalConfig(storeId);
            const storeDoc = await getDoc(doc(db, 'stores', storeId));
            const store = storeDoc.data();
            
            // Criar/buscar cliente
            let customer = await AsaasAPI.findCustomer(store.ownerCpfCnpj || '00000000000');
            if (!customer) {
                customer = await AsaasAPI.createCustomer({
                    id: storeId,
                    name: store.name,
                    ownerName: store.ownerName,
                    ownerEmail: store.ownerEmail,
                    ownerPhone: store.ownerPhone,
                    ownerCpfCnpj: store.ownerCpfCnpj
                });
            }
            
            // Criar assinatura
            const subscription = await AsaasAPI.createSubscription(customer.id, {
                amount: config.amount,
                dueDay: config.dueDay,
                description: config.description,
                storeId: storeId
            });
            
            // Salvar referência
            await updateDoc(doc(db, 'rentalConfigs', storeId), {
                asaasSubscriptionId: subscription.id,
                subscriptionActive: true,
                updatedAt: serverTimestamp()
            });
            
            return { success: true, subscription };
            
        } catch (error) {
            console.error('Erro ao criar assinatura:', error);
            return { success: false, message: error.message };
        }
    },
    
    // ==========================================
    // SINCRONIZAÇÃO COM ASAAS
    // ==========================================
    
    // Verificar status de pagamento no Asaas e atualizar local
    async syncPaymentStatus(rentalId) {
        try {
            const rentalDoc = await getDoc(doc(db, 'rentals', rentalId));
            if (!rentalDoc.exists()) return false;
            
            const rental = rentalDoc.data();
            
            // Consultar no Asaas
            const payment = await AsaasAPI.getPayment(rental.asaasPaymentId);
            if (!payment) return false;
            
            // Atualizar status local
            const newStatus = this.mapAsaasStatus(payment.status);
            const updates = {
                status: newStatus,
                updatedAt: serverTimestamp()
            };
            
            if (AsaasAPI.isPaid(payment.status) && rental.status !== 'paid') {
                updates.paidAt = serverTimestamp();
                updates.confirmedBy = 'system';
            }
            
            await updateDoc(doc(db, 'rentals', rentalId), updates);
            
            return true;
        } catch (error) {
            console.error('Erro ao sincronizar:', error);
            return false;
        }
    },
    
    // Webhook handler (chamar quando Asaas notificar)
    async handleWebhook(payload) {
        try {
            const { event, payment } = payload;
            
            // Buscar cobrança pelo ID do Asaas
            const q = query(
                collection(db, 'rentals'),
                where('asaasPaymentId', '==', payment.id)
            );
            const snapshot = await getDocs(q);
            
            if (snapshot.empty) return false;
            
            const rentalDoc = snapshot.docs[0];
            const rental = rentalDoc.data();
            
            // Atualizar conforme evento
            switch(event) {
                case 'PAYMENT_RECEIVED':
                case 'PAYMENT_CONFIRMED':
                    await updateDoc(doc(db, 'rentals', rentalDoc.id), {
                        status: 'paid',
                        paidAt: serverTimestamp(),
                        confirmedBy: 'asaas_webhook',
                        updatedAt: serverTimestamp()
                    });
                    
                    // Notificar lojista
                    await this.notifyPaymentReceived(rental.storeId, rental);
                    break;
                    
                case 'PAYMENT_OVERDUE':
                    await updateDoc(doc(db, 'rentals', rentalDoc.id), {
                        status: 'overdue',
                        updatedAt: serverTimestamp()
                    });
                    break;
                    
                case 'PAYMENT_DELETED':
                case 'PAYMENT_REFUNDED':
                    await updateDoc(doc(db, 'rentals', rentalDoc.id), {
                        status: 'cancelled',
                        updatedAt: serverTimestamp()
                    });
                    break;
            }
            
            return true;
        } catch (error) {
            console.error('Erro no webhook:', error);
            return false;
        }
    },
    
    // ==========================================
    // AUTOMAÇÃO MENSAL
    // ==========================================
    
    // Verificar e gerar cobranças do mês (chamar diariamente)
    async checkAndGenerateMonthlyRentals() {
        const today = new Date();
        const currentDay = today.getDate();
        const currentMonth = today.toISOString().slice(0, 7);
        
        // Buscar todas as lojas com aluguel ativo
        const configsQuery = query(
            collection(db, 'rentalConfigs'),
            where('enabled', '==', true),
            where('autoGenerate', '==', true)
        );
        
        const configs = await getDocs(configsQuery);
        const results = [];
        
        for (const configDoc of configs.docs) {
            const config = configDoc.data();
            
            // Só gera se estiver no dia de vencimento ou anterior
            if (currentDay <= config.dueDay) {
                try {
                    const result = await this.generateRentalInvoice(config.storeId, currentMonth);
                    results.push({ storeId: config.storeId, ...result });
                } catch (error) {
                    results.push({ 
                        storeId: config.storeId, 
                        success: false, 
                        message: error.message 
                    });
                }
            }
        }
        
        // Log dos resultados
        console.log('Geração automática de aluguéis:', results);
        return results;
    },
    
    // ==========================================
    // UTILITÁRIOS
    // ==========================================
    
    mapAsaasStatus(asaasStatus) {
        const mapping = {
            'PENDING': 'pending',
            'RECEIVED': 'paid',
            'CONFIRMED': 'paid',
            'OVERDUE': 'overdue',
            'REFUNDED': 'refunded',
            'CANCELLED': 'cancelled',
            'CHARGEBACK': 'chargeback'
        };
        return mapping[asaasStatus] || 'pending';
    },
    
    async notifyPaymentReceived(storeId, rental) {
        // Criar notificação no sistema
        await addDoc(collection(db, 'notifications'), {
            userId: storeId, // ou ownerId da loja
            type: 'rental_paid',
            title: 'Aluguel Pago!',
            message: `Pagamento de R$ ${rental.amount.toFixed(2)} confirmado.`,
            read: false,
            createdAt: serverTimestamp()
        });
    }
};

export default RentalManager;
window.RentalManager = RentalManager;