// ==========================================
// SISTEMA DE SEGURANÇA DO PAINEL ADMIN - CORRIGIDO
// ==========================================

import { 
    onAuthStateChanged, 
    signOut,
    GoogleAuthProvider,
    signInWithPopup
} from "https://www.gstatic.com/firebasejs/12.9.0/firebase-auth.js";
import { doc, getDoc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const AdminSecurity = {
    currentUser: null,
    isVerified: false,
    sessionStart: null,
    maxSessionDuration: 30 * 60 * 1000, // 30 minutos
    auth: null,
    db: null,
    
    init() {
        // Aguardar Firebase estar disponível
        const checkFirebase = setInterval(() => {
            if (window.firebaseAuthAdmin && window.firebaseDbAdmin) {
                clearInterval(checkFirebase);
                this.auth = window.firebaseAuthAdmin;
                this.db = window.firebaseDbAdmin;
                this.startSecurity();
            }
        }, 100);
    },
    
    startSecurity() {
        if (!this.verifySecureEnvironment()) {
            this.showSecurityError('Ambiente inseguro detectado. Acesso bloqueado.');
            return;
        }
        
        // Verificar sessão salva
        const savedSession = sessionStorage.getItem('adminSession');
        if (savedSession) {
            try {
                const session = JSON.parse(savedSession);
                if (session.verified && (Date.now() - session.timestamp < this.maxSessionDuration)) {
                    this.isVerified = true;
                    this.sessionStart = session.timestamp;
                    // Verificar se ainda é admin
                    this.checkAdminAndShowPanel(session.uid);
                    return;
                }
            } catch (e) {
                console.error('Erro ao restaurar sessão:', e);
                sessionStorage.removeItem('adminSession');
            }
        }
        
        this.showSecurityScreen();
        this.setupEventListeners();
        
        // Monitorar estado de autenticação
        onAuthStateChanged(this.auth, async (user) => {
            this.currentUser = user;
        });
        
        // Verificar sessão periodicamente
        setInterval(() => this.checkSession(), 60000);
    },
    
    setupEventListeners() {
        const verifyBtn = document.getElementById('verifyAdminBtn');
        if (verifyBtn) {
            verifyBtn.addEventListener('click', () => this.verifyAdmin());
        }
        
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.logout());
        }
    },
    
    verifySecureEnvironment() {
        const isHTTPS = window.location.protocol === 'https:';
        const isLocalhost = window.location.hostname === 'localhost' || 
                           window.location.hostname === '127.0.0.1';
        
        if (!isHTTPS && !isLocalhost) {
            console.warn('⚠️ HTTPS recomendado em produção');
        }
        
        return true;
    },
    
    async checkIsAdmin(uid) {
        try {
            if (!this.db) return false;
            
            // Verificar na coleção 'admins'
            const adminDoc = await getDoc(doc(this.db, 'admins', uid));
            if (adminDoc.exists()) {
                return true;
            }
            
            // Verificar no documento do usuário
            const userDoc = await getDoc(doc(this.db, 'users', uid));
            if (userDoc.exists()) {
                const userData = userDoc.data();
                return userData.type === 'admin' || userData.role === 'admin';
            }
            
            return false;
        } catch (error) {
            console.error('Erro ao verificar admin:', error);
            return false;
        }
    },
    
    async checkAdminAndShowPanel(uid) {
        const isAdmin = await this.checkIsAdmin(uid);
        if (isAdmin) {
            this.showAdminPanel();
        } else {
            this.showSecurityScreen();
            this.showSecurityError('Você não tem permissão de administrador.');
            await this.logout();
        }
    },
    
    checkSession() {
        if (!this.isVerified || !this.sessionStart) return;
        
        const elapsed = Date.now() - this.sessionStart;
        if (elapsed > this.maxSessionDuration) {
            this.showToast('Sessão expirada', 'Faça login novamente', 'warning');
            setTimeout(() => this.logout(), 3000);
        }
    },
    
    showSecurityScreen() {
        const overlay = document.getElementById('securityOverlay');
        const layout = document.getElementById('adminLayout');
        const step1 = document.getElementById('securityStep1');
        const loading = document.getElementById('securityLoading');
        const error = document.getElementById('securityError');
        
        if (overlay) overlay.classList.remove('hidden');
        if (layout) layout.classList.add('hidden');
        if (step1) step1.classList.remove('hidden');
        if (loading) loading.classList.add('hidden');
        if (error) error.classList.add('hidden');
    },
    
    async verifyAdmin() {
        const step1 = document.getElementById('securityStep1');
        const loading = document.getElementById('securityLoading');
        
        if (step1) step1.classList.add('hidden');
        if (loading) loading.classList.remove('hidden');
        
        try {
            // Se não estiver logado, fazer login com Google
            if (!this.auth.currentUser) {
                const provider = new GoogleAuthProvider();
                provider.setCustomParameters({ prompt: 'select_account' });
                const result = await signInWithPopup(this.auth, provider);
                this.currentUser = result.user;
            }
            
            // Verificar se é admin
            const isAdmin = await this.checkIsAdmin(this.auth.currentUser.uid);
            
            if (isAdmin) {
                // Registrar acesso
                await this.logAccess('login', 'success');
                
                // Salvar sessão
                this.isVerified = true;
                this.sessionStart = Date.now();
                sessionStorage.setItem('adminSession', JSON.stringify({
                    verified: true,
                    timestamp: this.sessionStart,
                    uid: this.auth.currentUser.uid
                }));
                
                this.showAdminPanel();
            } else {
                throw new Error('Usuário não é administrador');
            }
            
        } catch (error) {
            console.error('Erro na verificação:', error);
            
            if (step1) step1.classList.remove('hidden');
            if (loading) loading.classList.add('hidden');
            
            let errorMsg = 'Erro ao verificar acesso.';
            if (error.code === 'auth/popup-closed-by-user') {
                errorMsg = 'Login cancelado. Tente novamente.';
            } else if (error.message === 'Usuário não é administrador') {
                errorMsg = 'Esta conta não tem permissão de administrador.';
            }
            
            this.showSecurityError(errorMsg);
            
            // Fazer logout se não for admin
            if (this.auth.currentUser) {
                await signOut(this.auth);
            }
        }
    },
    
    showAdminPanel() {
        const overlay = document.getElementById('securityOverlay');
        const layout = document.getElementById('adminLayout');
        
        if (overlay) overlay.classList.add('hidden');
        if (layout) layout.classList.remove('hidden');
        
        // Atualizar informações do admin
        if (this.auth.currentUser) {
            const name = this.auth.currentUser.displayName || 'Administrador';
            
            const adminNameEl = document.getElementById('adminName');
            const adminInitialEl = document.getElementById('adminInitial');
            
            if (adminNameEl) adminNameEl.textContent = name;
            if (adminInitialEl) adminInitialEl.textContent = name.charAt(0).toUpperCase();
            
            if (this.auth.currentUser.photoURL) {
                const avatarEl = document.getElementById('adminAvatar');
                if (avatarEl) {
                    avatarEl.src = this.auth.currentUser.photoURL;
                    avatarEl.classList.remove('hidden');
                }
                if (adminInitialEl) adminInitialEl.classList.add('hidden');
            }
        }
        
        // Inicializar o painel admin
        if (window.AdminPanel) {
            window.AdminPanel.init();
        } else {
            const checkPanel = setInterval(() => {
                if (window.AdminPanel) {
                    clearInterval(checkPanel);
                    window.AdminPanel.init();
                }
            }, 100);
        }
    },
    
    showSecurityError(msg) {
        const errorEl = document.getElementById('securityError');
        const errorMsgEl = document.getElementById('securityErrorMsg');
        
        if (errorMsgEl) errorMsgEl.textContent = msg;
        if (errorEl) errorEl.classList.remove('hidden');
        
        setTimeout(() => {
            if (errorEl) errorEl.classList.add('hidden');
        }, 5000);
    },
    
    async logAccess(action, status, details = {}) {
        try {
            if (!this.db || !this.auth.currentUser) return;
            
            const { collection, addDoc } = await import("https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js");
            
            await addDoc(collection(this.db, 'adminLogs'), {
                uid: this.auth.currentUser.uid,
                email: this.auth.currentUser.email,
                action: action,
                status: status,
                userAgent: navigator.userAgent,
                timestamp: serverTimestamp(),
                ...details
            });
        } catch (error) {
            console.error('Erro ao registrar log:', error);
        }
    },
    
    async logout() {
        try {
            await this.logAccess('logout', 'success');
            if (this.auth) {
                await signOut(this.auth);
            }
        } catch (error) {
            console.error('Erro no logout:', error);
        }
        
        this.isVerified = false;
        this.sessionStart = null;
        this.currentUser = null;
        sessionStorage.removeItem('adminSession');
        
        window.location.reload();
    },
    
    showToast(title, message, type = 'success') {
        const toast = document.getElementById('toast');
        const toastTitle = document.getElementById('toastTitle');
        const toastMessage = document.getElementById('toastMessage');
        const toastIcon = document.getElementById('toastIcon');
        const toastContent = document.getElementById('toastContent');
        
        if (!toast) return;
        
        if (toastTitle) toastTitle.textContent = title;
        if (toastMessage) toastMessage.textContent = message;
        
        const icons = {
            success: 'fa-check-circle text-green-400',
            error: 'fa-times-circle text-red-400',
            warning: 'fa-exclamation-triangle text-yellow-400',
            info: 'fa-info-circle text-blue-400'
        };
        
        const borders = {
            success: 'border-green-500',
            error: 'border-red-500',
            warning: 'border-yellow-500',
            info: 'border-blue-500'
        };
        
        if (toastIcon) toastIcon.className = `fas ${icons[type]} text-lg`;
        if (toastContent) toastContent.className = `glass-strong px-4 py-3 rounded-2xl flex items-center gap-3 border-l-4 ${borders[type]} shadow-2xl max-w-xs`;
        
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 4000);
    }
};

document.addEventListener('DOMContentLoaded', () => {
    AdminSecurity.init();
});

window.AdminSecurity = AdminSecurity;
export default AdminSecurity;