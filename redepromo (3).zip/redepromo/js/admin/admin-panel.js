// ==========================================
// ADMIN PANEL - REDEPROMO (CORRIGIDO)
// ==========================================

import { 
    doc, 
    getDoc, 
    getDocs,
    updateDoc, 
    setDoc,
    deleteDoc,
    collection, 
    query, 
    where, 
    onSnapshot,
    orderBy,
    serverTimestamp,
    limit
} from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";
import { 
    onAuthStateChanged,
    signOut 
} from "https://www.gstatic.com/firebasejs/12.9.0/firebase-auth.js";

const db = window.firebaseDb;
const auth = window.firebaseAuth;

const Admin = {
    currentUser: null,
    currentTab: 'dashboard',
    stores: [],
    users: [],
    coupons: [],
    reviews: [],
    rentals: [],
    cities: [],
    listeners: [],

    async init() {
        onAuthStateChanged(auth, async (user) => {
            if (!user) {
                window.location.href = 'index.html';
                return;
            }

            this.currentUser = user;
            
            const userDoc = await getDoc(doc(db, 'users', user.uid));
            if (!userDoc.exists() || userDoc.data().role !== 'admin') {
                this.showToast('Acesso Negado', 'Você não tem permissão para acessar esta área', 'error');
                setTimeout(() => window.location.href = 'index.html', 2000);
                return;
            }

            this.setupEventListeners();
            await this.loadInitialData();
            
            document.getElementById('loadingScreen').style.display = 'none';
            this.showTab('dashboard');
        });
    },

    async loadInitialData() {
        await Promise.all([
            this.loadCities(),
            this.loadStores(),
            this.loadUsers()
        ]);
    },

    setupEventListeners() {
        document.getElementById('mobileMenuBtn')?.addEventListener('click', () => {
            document.getElementById('sidebar').classList.toggle('open');
        });

        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                }
            });
        });
    },

    showTab(tab) {
        this.currentTab = tab;
        
        document.querySelectorAll('.admin-tab').forEach(t => {
            t.classList.remove('active', 'bg-primary/10', 'text-white');
            t.classList.add('text-gray-300');
        });
        
        const activeTab = document.querySelector(`.admin-tab[data-tab="${tab}"]`);
        if (activeTab) {
            activeTab.classList.add('active', 'bg-primary/10', 'text-white');
            activeTab.classList.remove('text-gray-300');
        }

        const titles = {
            dashboard: 'Dashboard',
            cities: 'Gerenciar Cidades',
            stores: 'Gerenciar Lojas',
            promote: 'Promover a Dono',
            payments: 'Configurações de Pagamento',
            rentals: 'Gerenciar Aluguéis',
            coupons: 'Gerenciar Cupons',
            reviews: 'Moderação de Avaliações',
            reports: 'Relatórios da Plataforma',
            users: 'Gerenciar Usuários',
            security: 'Segurança'
        };
        document.getElementById('pageTitle').textContent = titles[tab] || 'Painel Admin';

        const contentArea = document.getElementById('contentArea');
        contentArea.innerHTML = '<div class="flex items-center justify-center h-64"><i class="fas fa-spinner fa-spin text-3xl text-primary"></i></div>';

        switch(tab) {
            case 'dashboard':
                this.renderDashboard(contentArea);
                break;
            case 'cities':
                this.renderCities(contentArea);
                break;
            case 'stores':
                this.renderStores(contentArea);
                break;
            case 'promote':
                this.renderPromote(contentArea);
                break;
            case 'payments':
                this.renderPayments(contentArea);
                break;
            case 'rentals':
                this.renderRentals(contentArea);
                break;
            case 'coupons':
                this.renderCoupons(contentArea);
                break;
            case 'reviews':
                this.renderReviews(contentArea);
                break;
            case 'reports':
                this.renderReports(contentArea);
                break;
            case 'users':
                this.renderUsers(contentArea);
                break;
            case 'security':
                this.renderSecurity(contentArea);
                break;
        }

        if (window.innerWidth < 1024) {
            document.getElementById('sidebar').classList.remove('open');
        }
    },

    async renderDashboard(container) {
        const storesSnapshot = await getDocs(collection(db, 'stores'));
        const usersSnapshot = await getDocs(collection(db, 'users'));
        const ordersSnapshot = await getDocs(collection(db, 'orders'));
        
        const totalStores = storesSnapshot.size;
        const totalUsers = usersSnapshot.size;
        const totalOrders = ordersSnapshot.size;
        
        let totalRevenue = 0;
        ordersSnapshot.forEach(doc => {
            totalRevenue += doc.data().total || 0;
        });

        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div class="glass rounded-2xl p-6 text-center">
                        <div class="text-3xl font-bold text-primary mb-1">${totalStores}</div>
                        <div class="text-sm text-gray-400">Lojas</div>
                    </div>
                    <div class="glass rounded-2xl p-6 text-center">
                        <div class="text-3xl font-bold text-accent mb-1">${totalUsers}</div>
                        <div class="text-sm text-gray-400">Usuários</div>
                    </div>
                    <div class="glass rounded-2xl p-6 text-center">
                        <div class="text-3xl font-bold text-green-400 mb-1">${totalOrders}</div>
                        <div class="text-sm text-gray-400">Pedidos</div>
                    </div>
                    <div class="glass rounded-2xl p-6 text-center">
                        <div class="text-3xl font-bold text-orange-400 mb-1">R$ ${totalRevenue.toFixed(2)}</div>
                        <div class="text-sm text-gray-400">Receita Total</div>
                    </div>
                </div>

                <div class="grid lg:grid-cols-2 gap-6">
                    <div class="glass rounded-2xl p-6">
                        <h3 class="font-bold text-lg mb-4">Lojas Recentes</h3>
                        <div class="space-y-3">
                            ${storesSnapshot.docs.slice(0, 5).map(doc => {
                                const store = doc.data();
                                return `
                                    <div class="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                                        <div class="flex items-center gap-3">
                                            <img src="${store.logo || store.image || 'https://via.placeholder.com/40'}" class="w-10 h-10 rounded-lg object-cover">
                                            <div>
                                                <p class="font-medium">${store.name}</p>
                                                <p class="text-xs text-gray-400">${store.cityId || 'Sem cidade'}</p>
                                            </div>
                                        </div>
                                        <span class="text-xs px-2 py-1 rounded-full ${store.active !== false ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}">
                                            ${store.active !== false ? 'Ativa' : 'Inativa'}
                                        </span>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>

                    <div class="glass rounded-2xl p-6">
                        <h3 class="font-bold text-lg mb-4">Pedidos Recentes</h3>
                        <div class="space-y-3">
                            ${ordersSnapshot.docs.slice(0, 5).map(doc => {
                                const order = doc.data();
                                return `
                                    <div class="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                                        <div>
                                            <p class="font-medium">#${doc.id.slice(-6).toUpperCase()}</p>
                                            <p class="text-xs text-gray-400">${order.customerName || 'Cliente'}</p>
                                        </div>
                                        <div class="text-right">
                                            <p class="font-bold">R$ ${(order.total || 0).toFixed(2)}</p>
                                            <span class="text-xs px-2 py-0.5 rounded-full ${this.getStatusClass(order.status)}">${this.getStatusLabel(order.status)}</span>
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    async renderCities(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between">
                    <h2 class="text-2xl font-bold">Cidades</h2>
                    <button onclick="Admin.openCityModal()" class="btn btn-primary">
                        <i class="fas fa-plus mr-2"></i> Nova Cidade
                    </button>
                </div>

                <div id="citiesList" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="col-span-full text-center py-12">
                        <i class="fas fa-spinner fa-spin text-3xl text-primary"></i>
                        <p class="mt-4 text-gray-400">Carregando cidades...</p>
                    </div>
                </div>
            </div>
        `;
        
        await this.loadCitiesList();
    },

    async loadCitiesList() {
        const snapshot = await getDocs(collection(db, 'cities'));
        const cities = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
        
        const container = document.getElementById('citiesList');
        if (cities.length === 0) {
            container.innerHTML = `
                <div class="col-span-full text-center py-12 text-gray-500">
                    <i class="fas fa-city text-5xl mb-4 opacity-50"></i>
                    <p>Nenhuma cidade cadastrada</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = cities.map(city => `
            <div class="glass rounded-xl p-4">
                <div class="flex items-center justify-between mb-3">
                    <h3 class="font-bold text-lg">${city.name}</h3>
                    <div class="flex gap-2">
                        <button onclick="Admin.editCity('${city.id}')" class="p-2 hover:bg-white/10 rounded-lg text-blue-400">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button onclick="Admin.deleteCity('${city.id}')" class="p-2 hover:bg-white/10 rounded-lg text-red-400">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                <p class="text-sm text-gray-400">${city.state || 'Sem estado'}</p>
                <div class="mt-3 flex items-center gap-4 text-sm text-gray-500">
                    <span><i class="fas fa-store mr-1"></i> ${city.storeCount || 0} lojas</span>
                    <span><i class="fas fa-users mr-1"></i> ${city.userCount || 0} usuários</span>
                </div>
            </div>
        `).join('');
    },

    openCityModal(cityId = null) {
        const isEdit = !!cityId;
        const city = isEdit ? this.cities.find(c => c.id === cityId) : null;
        
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'cityModal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="p-6 border-b border-white/10 flex items-center justify-between">
                    <h3 class="text-xl font-bold">${isEdit ? 'Editar' : 'Nova'} Cidade</h3>
                    <button onclick="document.getElementById('cityModal').remove()" class="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <form class="p-6 space-y-4" onsubmit="event.preventDefault(); Admin.saveCity('${cityId || ''}');">
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Nome da Cidade *</label>
                        <input type="text" id="cityName" required value="${city?.name || ''}" 
                            class="input-field" placeholder="Ex: São Paulo">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Estado *</label>
                        <input type="text" id="cityState" required value="${city?.state || ''}" 
                            class="input-field" placeholder="Ex: SP">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Taxa de Entrega Padrão (R$)</label>
                        <input type="number" id="cityDeliveryFee" step="0.01" value="${city?.defaultDeliveryFee || ''}" 
                            class="input-field" placeholder="0.00">
                    </div>
                    <button type="submit" class="btn btn-primary w-full">
                        <i class="fas fa-save mr-2"></i> ${isEdit ? 'Salvar Alterações' : 'Criar Cidade'}
                    </button>
                </form>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async saveCity(cityId) {
        const name = document.getElementById('cityName').value.trim();
        const state = document.getElementById('cityState').value.trim();
        const defaultDeliveryFee = parseFloat(document.getElementById('cityDeliveryFee').value) || 0;

        try {
            const data = {
                name,
                state,
                defaultDeliveryFee,
                updatedAt: serverTimestamp()
            };

            if (cityId) {
                await updateDoc(doc(db, 'cities', cityId), data);
            } else {
                data.createdAt = serverTimestamp();
                await setDoc(doc(collection(db, 'cities')), data);
            }

            this.showToast('Sucesso', `Cidade ${cityId ? 'atualizada' : 'criada'} com sucesso!`);
            document.getElementById('cityModal').remove();
            this.loadCitiesList();
        } catch (error) {
            console.error('Erro ao salvar cidade:', error);
            this.showToast('Erro', 'Erro ao salvar cidade', 'error');
        }
    },

    async deleteCity(cityId) {
        if (!confirm('Tem certeza que deseja excluir esta cidade?')) return;
        
        try {
            await deleteDoc(doc(db, 'cities', cityId));
            this.showToast('Sucesso', 'Cidade excluída');
            this.loadCitiesList();
        } catch (error) {
            this.showToast('Erro', 'Erro ao excluir cidade', 'error');
        }
    },

    async renderStores(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <div class="flex items-center gap-4">
                        <div class="relative">
                            <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                            <input type="text" id="storeSearch" placeholder="Buscar lojas..."
                                onkeyup="Admin.filterStores(this.value)"
                                class="input-field pl-10 pr-4 py-2 w-64">
                        </div>
                        <select id="storeCityFilter" onchange="Admin.filterStoresByCity(this.value)" 
                            class="input-field py-2 w-40">
                            <option value="">Todas as cidades</option>
                        </select>
                    </div>
                </div>

                <div id="storesList" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="col-span-full text-center py-12">
                        <i class="fas fa-spinner fa-spin text-3xl text-primary"></i>
                        <p class="mt-4 text-gray-400">Carregando lojas...</p>
                    </div>
                </div>
            </div>
        `;
        
        await this.loadStoresList();
        await this.loadCityOptions();
    },

    async loadStoresList() {
        const snapshot = await getDocs(collection(db, 'stores'));
        this.stores = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
        this.renderStoresGrid(this.stores);
    },

    renderStoresGrid(stores) {
        const container = document.getElementById('storesList');
        if (stores.length === 0) {
            container.innerHTML = `
                <div class="col-span-full text-center py-12 text-gray-500">
                    <i class="fas fa-store text-5xl mb-4 opacity-50"></i>
                    <p>Nenhuma loja encontrada</p>
                </div>
            `;
            return;
        }

        container.innerHTML = stores.map(store => `
            <div class="glass rounded-xl overflow-hidden group">
                <div class="relative h-32 overflow-hidden">
                    <img src="${store.banner || store.image || 'https://via.placeholder.com/400x150'}" 
                        class="w-full h-full object-cover">
                    <div class="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                    <div class="absolute bottom-3 left-3 right-3">
                        <h3 class="font-bold text-lg truncate">${store.name}</h3>
                        <p class="text-sm text-gray-300">${store.ownerName || 'Sem proprietário'}</p>
                    </div>
                    <span class="absolute top-2 right-2 px-2 py-1 rounded-full text-xs ${store.active !== false ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}">
                        ${store.active !== false ? 'Ativa' : 'Inativa'}
                    </span>
                </div>
                <div class="p-4">
                    <div class="flex items-center justify-between text-sm text-gray-400 mb-3">
                        <span><i class="fas fa-box mr-1"></i> ${store.items?.length || 0} produtos</span>
                        <span><i class="fas fa-shopping-bag mr-1"></i> ${store.orders?.length || 0} pedidos</span>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="Admin.editStore('${store.id}')" 
                            class="flex-1 py-2 rounded-lg bg-primary/20 text-primary hover:bg-primary/30 transition-colors text-sm">
                            <i class="fas fa-edit mr-1"></i> Editar
                        </button>
                        <button onclick="Admin.toggleStoreStatus('${store.id}', ${store.active === false})" 
                            class="flex-1 py-2 rounded-lg ${store.active !== false ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'} transition-colors text-sm">
                            <i class="fas ${store.active !== false ? 'fa-ban' : 'fa-check'} mr-1"></i> 
                            ${store.active !== false ? 'Desativar' : 'Ativar'}
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    },

    filterStores(search) {
        const filtered = this.stores.filter(s => 
            s.name.toLowerCase().includes(search.toLowerCase()) ||
            s.ownerName?.toLowerCase().includes(search.toLowerCase())
        );
        this.renderStoresGrid(filtered);
    },

    filterStoresByCity(cityId) {
        if (!cityId) {
            this.renderStoresGrid(this.stores);
            return;
        }
        const filtered = this.stores.filter(s => s.cityId === cityId);
        this.renderStoresGrid(filtered);
    },

    async loadCityOptions() {
        const snapshot = await getDocs(collection(db, 'cities'));
        const cities = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
        const select = document.getElementById('storeCityFilter');
        select.innerHTML = '<option value="">Todas as cidades</option>' + 
            cities.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    },

    async editStore(storeId) {
        const store = this.stores.find(s => s.id === storeId);
        if (!store) {
            this.showToast('Erro', 'Loja não encontrada', 'error');
            return;
        }

        const citiesSnapshot = await getDocs(collection(db, 'cities'));
        const cities = citiesSnapshot.docs.map(d => ({ id: d.id, ...d.data() }));

        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'editStoreModal';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 800px;">
                <div class="p-6 border-b border-white/10 flex items-center justify-between sticky top-0 bg-gray-900/95 z-10">
                    <h3 class="text-xl font-bold">Editar Loja: ${store.name}</h3>
                    <button onclick="document.getElementById('editStoreModal').remove()" class="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <form class="p-6 space-y-6" onsubmit="event.preventDefault(); Admin.saveStoreEdit('${storeId}');">
                    
                    <div class="glass rounded-xl p-4 space-y-4">
                        <h4 class="font-bold text-primary">Informações Básicas</h4>
                        <div class="grid md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Nome da Loja *</label>
                                <input type="text" id="editStoreName" required value="${store.name}" class="input-field">
                            </div>
                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Cidade *</label>
                                <select id="editStoreCity" required class="input-field">
                                    ${cities.map(c => `<option value="${c.id}" ${c.id === store.cityId ? 'selected' : ''}>${c.name}</option>`).join('')}
                                </select>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Descrição</label>
                            <textarea id="editStoreDescription" rows="3" class="input-field">${store.description || ''}</textarea>
                        </div>
                    </div>

                    <div class="glass rounded-xl p-4 space-y-4">
                        <h4 class="font-bold text-primary">Contato</h4>
                        <div class="grid md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Telefone/WhatsApp</label>
                                <input type="text" id="editStorePhone" value="${store.phone || ''}" class="input-field" placeholder="(11) 99999-9999">
                            </div>
                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Email</label>
                                <input type="email" id="editStoreEmail" value="${store.email || ''}" class="input-field">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Endereço</label>
                            <input type="text" id="editStoreAddress" value="${store.address || ''}" class="input-field" placeholder="Rua, número, bairro">
                        </div>
                    </div>

                    <div class="glass rounded-xl p-4 space-y-4">
                        <h4 class="font-bold text-primary">Configurações</h4>
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="font-medium">Loja Ativa</p>
                                <p class="text-sm text-gray-400">Permitir que a loja apareça no app</p>
                            </div>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" id="editStoreActive" class="sr-only peer" ${store.active !== false ? 'checked' : ''}>
                                <div class="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                            </label>
                        </div>
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="font-medium">Destacada</p>
                                <p class="text-sm text-gray-400">Aparecer em destaque na home</p>
                            </div>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" id="editStoreFeatured" class="sr-only peer" ${store.featured ? 'checked' : ''}>
                                <div class="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-accent"></div>
                            </label>
                        </div>
                    </div>

                    <div class="flex gap-3">
                        <button type="button" onclick="document.getElementById('editStoreModal').remove()" 
                            class="flex-1 py-3 rounded-xl bg-white/10 hover:bg-white/20 transition-colors">
                            Cancelar
                        </button>
                        <button type="submit" class="flex-1 py-3 rounded-xl bg-gradient-to-r from-primary to-secondary font-bold hover:shadow-lg hover:shadow-primary/30 transition-all">
                            <i class="fas fa-save mr-2"></i> Salvar Alterações
                        </button>
                    </div>
                </form>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async saveStoreEdit(storeId) {
        try {
            const updates = {
                name: document.getElementById('editStoreName').value.trim(),
                cityId: document.getElementById('editStoreCity').value,
                description: document.getElementById('editStoreDescription').value.trim(),
                phone: document.getElementById('editStorePhone').value.trim(),
                email: document.getElementById('editStoreEmail').value.trim(),
                address: document.getElementById('editStoreAddress').value.trim(),
                active: document.getElementById('editStoreActive').checked,
                featured: document.getElementById('editStoreFeatured').checked,
                updatedAt: serverTimestamp()
            };

            await updateDoc(doc(db, 'stores', storeId), updates);
            
            this.showToast('Sucesso', 'Loja atualizada com sucesso!');
            document.getElementById('editStoreModal').remove();
            
            await this.loadStoresList();
        } catch (error) {
            console.error('Erro ao salvar loja:', error);
            this.showToast('Erro', 'Erro ao atualizar loja', 'error');
        }
    },

    async toggleStoreStatus(storeId, activate) {
        try {
            await updateDoc(doc(db, 'stores', storeId), {
                active: activate,
                updatedAt: serverTimestamp()
            });
            this.showToast('Sucesso', activate ? 'Loja ativada' : 'Loja desativada');
            this.loadStoresList();
        } catch (error) {
            this.showToast('Erro', 'Erro ao alterar status', 'error');
        }
    },

    async renderCoupons(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <div>
                        <h2 class="text-2xl font-bold">Cupons da Plataforma</h2>
                        <p class="text-gray-400">Gerencie cupons globais válidos para todas as lojas</p>
                    </div>
                    <button onclick="Admin.openCouponModal()" class="btn btn-primary">
                        <i class="fas fa-plus mr-2"></i> Novo Cupom Global
                    </button>
                </div>

                <div class="flex gap-2 border-b border-white/10 pb-2">
                    <button onclick="Admin.switchCouponTab('platform')" id="tab-platform" 
                        class="px-4 py-2 rounded-lg bg-primary/20 text-primary font-medium">
                        Cupons da Plataforma
                    </button>
                    <button onclick="Admin.switchCouponTab('stores')" id="tab-stores" 
                        class="px-4 py-2 rounded-lg text-gray-400 hover:bg-white/5">
                        Cupons das Lojas
                    </button>
                </div>

                <div id="couponsContent">
                    <div class="text-center py-12">
                        <i class="fas fa-spinner fa-spin text-3xl text-primary"></i>
                        <p class="mt-4 text-gray-400">Carregando cupons...</p>
                    </div>
                </div>
            </div>
        `;
        
        await this.loadPlatformCoupons();
    },

    async loadPlatformCoupons() {
        const snapshot = await getDocs(query(
            collection(db, 'coupons'),
            where('isGlobal', '==', true),
            orderBy('createdAt', 'desc')
        ));
        
        const coupons = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
        this.renderCouponsList(coupons, 'platform');
    },

    async loadStoreCoupons() {
        const snapshot = await getDocs(query(
            collection(db, 'coupons'),
            where('isGlobal', '!=', true),
            orderBy('createdAt', 'desc')
        ));
        
        const coupons = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
        this.renderCouponsList(coupons, 'stores');
    },

    switchCouponTab(tab) {
        document.getElementById('tab-platform').className = tab === 'platform' 
            ? 'px-4 py-2 rounded-lg bg-primary/20 text-primary font-medium'
            : 'px-4 py-2 rounded-lg text-gray-400 hover:bg-white/5';
        document.getElementById('tab-stores').className = tab === 'stores'
            ? 'px-4 py-2 rounded-lg bg-primary/20 text-primary font-medium'
            : 'px-4 py-2 rounded-lg text-gray-400 hover:bg-white/5';
        
        if (tab === 'platform') {
            this.loadPlatformCoupons();
        } else {
            this.loadStoreCoupons();
        }
    },

    renderCouponsList(coupons, type) {
        const container = document.getElementById('couponsContent');
        
        if (coupons.length === 0) {
            container.innerHTML = `
                <div class="text-center py-12 text-gray-500">
                    <i class="fas fa-ticket-alt text-5xl mb-4 opacity-50"></i>
                    <p class="mb-4">Nenhum cupom encontrado</p>
                    ${type === 'platform' ? `
                        <button onclick="Admin.openCouponModal()" class="btn btn-primary">
                            <i class="fas fa-plus mr-2"></i> Criar primeiro cupom
                        </button>
                    ` : ''}
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                ${coupons.map(coupon => `
                    <div class="glass rounded-xl p-4 ${coupon.active ? 'border-l-4 border-primary' : 'border-l-4 border-gray-500 opacity-60'}">
                        <div class="flex items-center justify-between mb-3">
                            <span class="text-2xl font-bold font-mono text-primary">${coupon.code}</span>
                            <div class="flex gap-2">
                                <button onclick="Admin.editCoupon('${coupon.id}')" class="p-2 hover:bg-white/10 rounded-lg text-blue-400">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button onclick="Admin.deleteCoupon('${coupon.id}')" class="p-2 hover:bg-white/10 rounded-lg text-red-400">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                        <p class="text-lg font-medium mb-2">
                            ${coupon.type === 'percentage' ? coupon.value + '% OFF' : 'R$ ' + coupon.value.toFixed(2) + ' OFF'}
                        </p>
                        <p class="text-sm text-gray-400 mb-3">${coupon.description || 'Sem descrição'}</p>
                        ${coupon.storeId ? `<p class="text-xs text-gray-500 mb-2"><i class="fas fa-store mr-1"></i> Loja específica</p>` : ''}
                        <div class="flex items-center justify-between text-sm text-gray-500">
                            <span>Usos: ${coupon.usedCount || 0}${coupon.maxUses ? '/' + coupon.maxUses : ''}</span>
                            <span class="px-2 py-1 rounded-full text-xs ${coupon.active ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}">
                                ${coupon.active ? 'Ativo' : 'Inativo'}
                            </span>
                        </div>
                        ${coupon.expiresAt ? `<p class="text-xs text-gray-500 mt-2">Válido até: ${coupon.expiresAt.toDate().toLocaleDateString()}</p>` : ''}
                    </div>
                `).join('')}
            </div>
        `;
    },

    openCouponModal(couponId = null) {
        const isEdit = !!couponId;
        const coupon = isEdit ? this.coupons.find(c => c.id === couponId) : null;
        
        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'couponModal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="p-6 border-b border-white/10 flex items-center justify-between">
                    <h3 class="text-xl font-bold">${isEdit ? 'Editar' : 'Novo'} Cupom Global</h3>
                    <button onclick="document.getElementById('couponModal').remove()" class="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <form class="p-6 space-y-4" onsubmit="event.preventDefault(); Admin.saveCoupon('${couponId || ''}');">
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Código *</label>
                        <input type="text" id="couponCode" required value="${coupon?.code || ''}" 
                            class="input-field uppercase font-mono" placeholder="PROMO10">
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Tipo *</label>
                            <select id="couponType" class="input-field">
                                <option value="percentage" ${coupon?.type === 'percentage' ? 'selected' : ''}>Porcentagem (%)</option>
                                <option value="fixed" ${coupon?.type === 'fixed' ? 'selected' : ''}>Valor Fixo (R$)</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Valor *</label>
                            <input type="number" id="couponValue" required step="0.01" value="${coupon?.value || ''}" 
                                class="input-field" placeholder="10">
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Descrição</label>
                        <input type="text" id="couponDescription" value="${coupon?.description || ''}" 
                            class="input-field" placeholder="Ex: 10% de desconto em toda a plataforma">
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Mínimo de compra (R$)</label>
                            <input type="number" id="couponMinPurchase" step="0.01" value="${coupon?.minPurchase || ''}" 
                                class="input-field" placeholder="0">
                        </div>
                        <div>
                            <label class="block text-sm text-gray-400 mb-2">Limite de usos</label>
                            <input type="number" id="couponMaxUses" value="${coupon?.maxUses || ''}" 
                                class="input-field" placeholder="Ilimitado">
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Data de expiração</label>
                        <input type="datetime-local" id="couponExpires" 
                            value="${coupon?.expiresAt ? new Date(coupon.expiresAt.toDate()).toISOString().slice(0, 16) : ''}" 
                            class="input-field">
                    </div>
                    <div class="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                        <input type="checkbox" id="couponActive" ${coupon?.active !== false ? 'checked' : ''} 
                            class="w-5 h-5 rounded bg-gray-700 border-gray-600">
                        <label for="couponActive" class="text-sm">Cupom ativo</label>
                    </div>
                    <button type="submit" class="btn btn-primary w-full">
                        <i class="fas fa-save mr-2"></i> ${isEdit ? 'Salvar Alterações' : 'Criar Cupom'}
                    </button>
                </form>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async saveCoupon(couponId) {
        const code = document.getElementById('couponCode').value.toUpperCase().trim();
        const type = document.getElementById('couponType').value;
        const value = parseFloat(document.getElementById('couponValue').value);
        const description = document.getElementById('couponDescription').value;
        const minPurchase = parseFloat(document.getElementById('couponMinPurchase').value) || 0;
        const maxUses = parseInt(document.getElementById('couponMaxUses').value) || null;
        const expiresAt = document.getElementById('couponExpires').value;
        const active = document.getElementById('couponActive').checked;

        if (!code || !value) {
            this.showToast('Erro', 'Preencha código e valor', 'error');
            return;
        }

        try {
            const data = {
                code,
                type,
                value,
                description,
                minPurchase,
                maxUses,
                active,
                isGlobal: true,
                updatedAt: serverTimestamp()
            };

            if (expiresAt) {
                data.expiresAt = new Date(expiresAt);
            }

            if (couponId) {
                await updateDoc(doc(db, 'coupons', couponId), data);
            } else {
                data.usedCount = 0;
                data.createdBy = this.currentUser.uid;
                data.createdAt = serverTimestamp();
                await setDoc(doc(collection(db, 'coupons')), data);
            }

            this.showToast('Sucesso', `Cupom ${couponId ? 'atualizado' : 'criado'} com sucesso!`);
            document.getElementById('couponModal').remove();
            this.loadPlatformCoupons();
        } catch (error) {
            console.error('Erro ao salvar cupom:', error);
            this.showToast('Erro', 'Erro ao salvar cupom', 'error');
        }
    },

    async deleteCoupon(couponId) {
        if (!confirm('Excluir este cupom permanentemente?')) return;
        
        try {
            await deleteDoc(doc(db, 'coupons', couponId));
            this.showToast('Sucesso', 'Cupom excluído');
            this.loadPlatformCoupons();
        } catch (error) {
            this.showToast('Erro', 'Erro ao excluir cupom', 'error');
        }
    },

    async renderReviews(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <div>
                        <h2 class="text-2xl font-bold">Moderação de Avaliações</h2>
                        <p class="text-gray-400">Aprove ou rejeite avaliações de clientes</p>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="Admin.filterReviews('pending')" class="px-4 py-2 rounded-lg bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30 transition-colors">
                            <i class="fas fa-clock mr-2"></i> Pendentes
                        </button>
                        <button onclick="Admin.filterReviews('approved')" class="px-4 py-2 rounded-lg bg-green-500/20 text-green-400 hover:bg-green-500/30 transition-colors">
                            <i class="fas fa-check mr-2"></i> Aprovadas
                        </button>
                        <button onclick="Admin.filterReviews('rejected')" class="px-4 py-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors">
                            <i class="fas fa-times mr-2"></i> Rejeitadas
                        </button>
                    </div>
                </div>

                <div id="reviewsList">
                    <div class="text-center py-12">
                        <i class="fas fa-spinner fa-spin text-3xl text-primary"></i>
                        <p class="mt-4 text-gray-400">Carregando avaliações...</p>
                    </div>
                </div>
            </div>
        `;
        
        await this.loadReviews('pending');
    },

    async loadReviews(status = 'pending') {
        let q = collection(db, 'reviews');
        
        if (status !== 'all') {
            q = query(q, where('status', '==', status));
        }
        
        q = query(q, orderBy('createdAt', 'desc'));
        
        const snapshot = await getDocs(q);
        const reviews = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
        this.renderReviewsList(reviews);
    },

    filterReviews(status) {
        this.loadReviews(status);
    },

    renderReviewsList(reviews) {
        const container = document.getElementById('reviewsList');
        
        if (reviews.length === 0) {
            container.innerHTML = `
                <div class="text-center py-12 text-gray-500">
                    <i class="fas fa-star text-5xl mb-4 opacity-50"></i>
                    <p>Nenhuma avaliação encontrada</p>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <div class="space-y-4">
                ${reviews.map(review => `
                    <div class="glass rounded-xl p-4 ${review.status === 'pending' ? 'border-l-4 border-yellow-500' : review.status === 'approved' ? 'border-l-4 border-green-500' : 'border-l-4 border-red-500'}">
                        <div class="flex items-start justify-between gap-4">
                            <div class="flex items-center gap-3">
                                <img src="${review.userAvatar || 'https://via.placeholder.com/50'}" class="w-10 h-10 rounded-full">
                                <div>
                                    <p class="font-medium">${review.userName}</p>
                                    <p class="text-sm text-gray-400">${review.storeName || 'Loja'}</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <div class="flex text-yellow-400 mb-1">
                                    ${Array(5).fill(0).map((_, i) => `
                                        <i class="fas fa-star ${i < review.rating ? '' : 'text-gray-600'}"></i>
                                    `).join('')}
                                </div>
                                <span class="text-xs text-gray-500">${review.createdAt?.toDate ? review.createdAt.toDate().toLocaleDateString() : ''}</span>
                            </div>
                        </div>
                        <p class="mt-3 text-gray-300">${review.comment}</p>
                        ${review.images?.length ? `
                            <div class="flex gap-2 mt-3">
                                ${review.images.map(img => `<img src="${img}" class="w-16 h-16 rounded-lg object-cover">`).join('')}
                            </div>
                        ` : ''}
                        <div class="flex items-center justify-between mt-4 pt-4 border-t border-white/10">
                            <span class="text-xs px-3 py-1 rounded-full ${review.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' : review.status === 'approved' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}">
                                ${review.status === 'pending' ? 'Pendente' : review.status === 'approved' ? 'Aprovada' : 'Rejeitada'}
                            </span>
                            ${review.status === 'pending' ? `
                                <div class="flex gap-2">
                                    <button onclick="Admin.approveReview('${review.id}')" 
                                        class="px-4 py-2 rounded-lg bg-green-500/20 text-green-400 hover:bg-green-500/30 transition-colors text-sm">
                                        <i class="fas fa-check mr-1"></i> Aprovar
                                    </button>
                                    <button onclick="Admin.rejectReview('${review.id}')" 
                                        class="px-4 py-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors text-sm">
                                        <i class="fas fa-times mr-1"></i> Rejeitar
                                    </button>
                                </div>
                            ` : `
                                <button onclick="Admin.deleteReview('${review.id}')" 
                                    class="px-4 py-2 rounded-lg bg-gray-700 text-red-400 hover:bg-gray-600 transition-colors text-sm">
                                    <i class="fas fa-trash mr-1"></i> Excluir
                                </button>
                            `}
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    },

    async approveReview(reviewId) {
        try {
            await updateDoc(doc(db, 'reviews', reviewId), {
                status: 'approved',
                moderatedAt: serverTimestamp(),
                moderatedBy: this.currentUser.uid
            });
            this.showToast('Sucesso', 'Avaliação aprovada');
            this.loadReviews('pending');
        } catch (error) {
            this.showToast('Erro', 'Erro ao aprovar avaliação', 'error');
        }
    },

    async rejectReview(reviewId) {
        const reason = prompt('Motivo da rejeição (opcional):');
        try {
            await updateDoc(doc(db, 'reviews', reviewId), {
                status: 'rejected',
                rejectionReason: reason,
                moderatedAt: serverTimestamp(),
                moderatedBy: this.currentUser.uid
            });
            this.showToast('Sucesso', 'Avaliação rejeitada');
            this.loadReviews('pending');
        } catch (error) {
            this.showToast('Erro', 'Erro ao rejeitar avaliação', 'error');
        }
    },

    async deleteReview(reviewId) {
        if (!confirm('Excluir esta avaliação permanentemente?')) return;
        
        try {
            await deleteDoc(doc(db, 'reviews', reviewId));
            this.showToast('Sucesso', 'Avaliação excluída');
            this.loadReviews('all');
        } catch (error) {
            this.showToast('Erro', 'Erro ao excluir avaliação', 'error');
        }
    },

    async renderReports(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <div>
                        <h2 class="text-2xl font-bold">Relatórios da Plataforma</h2>
                        <p class="text-gray-400">Visão geral de toda a plataforma</p>
                    </div>
                    <div class="flex gap-2">
                        <select id="reportPeriod" onchange="Admin.loadReportsData()" class="input-field">
                            <option value="7">Últimos 7 dias</option>
                            <option value="30">Últimos 30 dias</option>
                            <option value="90">Últimos 3 meses</option>
                            <option value="365">Último ano</option>
                        </select>
                        <button onclick="Admin.exportReport()" class="btn btn-secondary">
                            <i class="fas fa-download mr-2"></i> Exportar
                        </button>
                    </div>
                </div>

                <div id="reportsContent">
                    <div class="flex items-center justify-center h-64">
                        <i class="fas fa-spinner fa-spin text-3xl text-primary"></i>
                    </div>
                </div>
            </div>
        `;
        
        await this.loadReportsData();
    },

    async loadReportsData() {
        const period = parseInt(document.getElementById('reportPeriod')?.value || 7);
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - period);

        const container = document.getElementById('reportsContent');
        
        try {
            const [storesSnap, usersSnap, ordersSnap] = await Promise.all([
                getDocs(collection(db, 'stores')),
                getDocs(collection(db, 'users')),
                getDocs(query(collection(db, 'orders'), orderBy('createdAt', 'desc')))
            ]);

            const stores = storesSnap.docs.map(d => ({ id: d.id, ...d.data() }));
            const users = usersSnap.docs.map(d => ({ id: d.id, ...d.data() }));
            const orders = ordersSnap.docs.map(d => ({ id: d.id, ...d.data() }));

            const periodOrders = orders.filter(o => {
                if (!o.createdAt) return false;
                const orderDate = o.createdAt.toDate ? o.createdAt.toDate() : new Date(o.createdAt);
                return orderDate >= startDate;
            });

            const totalRevenue = periodOrders.reduce((sum, o) => sum + (o.total || 0), 0);
            const totalOrders = periodOrders.length;
            const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

            const salesByDay = {};
            periodOrders.forEach(order => {
                const date = order.createdAt?.toDate ? 
                    order.createdAt.toDate().toISOString().split('T')[0] : 
                    new Date().toISOString().split('T')[0];
                salesByDay[date] = (salesByDay[date] || 0) + (order.total || 0);
            });

            const storeSales = {};
            periodOrders.forEach(order => {
                storeSales[order.storeId] = (storeSales[order.storeId] || 0) + (order.total || 0);
            });

            const topStores = Object.entries(storeSales)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 5)
                .map(([storeId, sales]) => {
                    const store = stores.find(s => s.id === storeId);
                    return { name: store?.name || 'Loja desconhecida', sales };
                });

            const productSales = {};
            periodOrders.forEach(order => {
                if (order.productName) {
                    productSales[order.productName] = (productSales[order.productName] || 0) + (order.total || 0);
                }
            });

            const topProducts = Object.entries(productSales)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 5);

            container.innerHTML = `
                <div class="space-y-6">
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div class="glass rounded-xl p-4 text-center">
                            <div class="text-2xl font-bold text-green-400">R$ ${totalRevenue.toFixed(2)}</div>
                            <div class="text-sm text-gray-400">Receita do período</div>
                        </div>
                        <div class="glass rounded-xl p-4 text-center">
                            <div class="text-2xl font-bold text-primary">${totalOrders}</div>
                            <div class="text-sm text-gray-400">Pedidos</div>
                        </div>
                        <div class="glass rounded-xl p-4 text-center">
                            <div class="text-2xl font-bold text-accent">R$ ${avgOrderValue.toFixed(2)}</div>
                            <div class="text-sm text-gray-400">Ticket médio</div>
                        </div>
                        <div class="glass rounded-xl p-4 text-center">
                            <div class="text-2xl font-bold text-orange-400">${stores.length}</div>
                            <div class="text-sm text-gray-400">Lojas ativas</div>
                        </div>
                    </div>

                    <div class="glass rounded-xl p-6">
                        <h3 class="font-bold mb-4">Vendas por Dia</h3>
                        ${Object.keys(salesByDay).length > 0 ? `
                            <div class="flex items-end gap-2 h-48">
                                ${Object.entries(salesByDay).map(([date, value]) => {
                                    const max = Math.max(...Object.values(salesByDay));
                                    const height = max > 0 ? (value / max * 100) : 0;
                                    return `
                                        <div class="flex-1 flex flex-col items-center gap-2">
                                            <div class="w-full bg-primary/20 rounded-t-lg relative group" style="height: ${height}%">
                                                <div class="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-800 px-2 py-1 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                                                    R$ ${value.toFixed(2)}
                                                </div>
                                            </div>
                                            <span class="text-xs text-gray-500">${date.slice(5)}</span>
                                        </div>
                                    `;
                                }).join('')}
                            </div>
                        ` : '<p class="text-center text-gray-500 py-8">Sem dados de vendas para este período</p>'}
                    </div>

                    <div class="grid lg:grid-cols-2 gap-6">
                        <div class="glass rounded-xl p-6">
                            <h3 class="font-bold mb-4">Top Lojas</h3>
                            <div class="space-y-3">
                                ${topStores.length > 0 ? topStores.map((store, index) => `
                                    <div class="flex items-center gap-3">
                                        <span class="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center font-bold text-sm">${index + 1}</span>
                                        <span class="flex-1 truncate">${store.name}</span>
                                        <span class="text-sm text-gray-400 w-20 text-right">R$ ${store.sales.toFixed(2)}</span>
                                    </div>
                                `).join('') : '<p class="text-gray-500 text-center py-4">Sem dados</p>'}
                            </div>
                        </div>

                        <div class="glass rounded-xl p-6">
                            <h3 class="font-bold mb-4">Top Produtos</h3>
                            <div class="space-y-3">
                                ${topProducts.length > 0 ? topProducts.map(([name, value], index) => `
                                    <div class="flex items-center gap-3">
                                        <span class="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center font-bold text-sm">${index + 1}</span>
                                        <span class="flex-1 truncate">${name}</span>
                                        <span class="text-sm text-gray-400 w-20 text-right">R$ ${value.toFixed(2)}</span>
                                    </div>
                                `).join('') : '<p class="text-gray-500 text-center py-4">Sem dados</p>'}
                            </div>
                        </div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Erro ao carregar relatórios:', error);
            container.innerHTML = `
                <div class="text-center py-12 text-red-400">
                    <i class="fas fa-exclamation-triangle text-4xl mb-4"></i>
                    <p>Erro ao carregar relatórios</p>
                </div>
            `;
        }
    },

    async renderRentals(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <div>
                        <h2 class="text-2xl font-bold">Gerenciar Aluguéis</h2>
                        <p class="text-gray-400">Controle de aluguéis e pagamentos das lojas</p>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="Admin.loadRentals('active')" class="px-4 py-2 rounded-lg bg-green-500/20 text-green-400 hover:bg-green-500/30 transition-colors">
                            Ativos
                        </button>
                        <button onclick="Admin.loadRentals('pending')" class="px-4 py-2 rounded-lg bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30 transition-colors">
                            Pendentes
                        </button>
                        <button onclick="Admin.loadRentals('overdue')" class="px-4 py-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors">
                            Atrasados
                        </button>
                    </div>
                </div>

                <div id="rentalsList">
                    <div class="text-center py-12">
                        <i class="fas fa-spinner fa-spin text-3xl text-primary"></i>
                        <p class="mt-4 text-gray-400">Carregando aluguéis...</p>
                    </div>
                </div>
            </div>
        `;
        
        await this.loadRentals('active');
    },

    async loadRentals(status = 'active') {
        let q = collection(db, 'rentals');
        
        if (status !== 'all') {
            q = query(q, where('status', '==', status));
        }
        
        q = query(q, orderBy('createdAt', 'desc'));
        
        const snapshot = await getDocs(q);
        const rentals = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
        this.renderRentalsList(rentals);
    },

    renderRentalsList(rentals) {
        const container = document.getElementById('rentalsList');
        
        if (rentals.length === 0) {
            container.innerHTML = `
                <div class="text-center py-12 text-gray-500">
                    <i class="fas fa-home text-5xl mb-4 opacity-50"></i>
                    <p>Nenhum aluguel encontrado</p>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <div class="space-y-4">
                ${rentals.map(rental => `
                    <div class="glass rounded-xl p-4 ${rental.status === 'overdue' ? 'border-l-4 border-red-500' : rental.status === 'pending' ? 'border-l-4 border-yellow-500' : 'border-l-4 border-green-500'}">
                        <div class="flex items-center justify-between flex-wrap gap-4">
                            <div class="flex items-center gap-3">
                                <div class="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                                    <i class="fas fa-store text-primary"></i>
                                </div>
                                <div>
                                    <p class="font-bold">${rental.storeName || 'Loja'}</p>
                                    <p class="text-sm text-gray-400">${rental.ownerName || 'Proprietário'}</p>
                                    <p class="text-xs text-gray-500">Vencimento: ${rental.dueDate?.toDate ? rental.dueDate.toDate().toLocaleDateString() : '-'}</p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="text-xl font-bold text-primary">R$ ${(rental.amount || 0).toFixed(2)}</p>
                                <span class="text-xs px-2 py-1 rounded-full ${rental.status === 'overdue' ? 'bg-red-500/20 text-red-400' : rental.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'}">
                                    ${rental.status === 'overdue' ? 'Atrasado' : rental.status === 'pending' ? 'Pendente' : 'Pago'}
                                </span>
                            </div>
                        </div>
                        <div class="flex gap-2 mt-4 pt-4 border-t border-white/10">
                            ${rental.status !== 'paid' ? `
                                <button onclick="Admin.markRentalPaid('${rental.id}')" 
                                    class="flex-1 py-2 rounded-lg bg-green-500/20 text-green-400 hover:bg-green-500/30 transition-colors text-sm">
                                    <i class="fas fa-check mr-1"></i> Marcar como Pago
                                </button>
                            ` : ''}
                            <button onclick="Admin.viewRentalDetails('${rental.id}')" 
                                class="flex-1 py-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors text-sm">
                                <i class="fas fa-eye mr-1"></i> Ver Detalhes
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    },

    async markRentalPaid(rentalId) {
        try {
            await updateDoc(doc(db, 'rentals', rentalId), {
                status: 'paid',
                paidAt: serverTimestamp(),
                paidBy: this.currentUser.uid
            });
            this.showToast('Sucesso', 'Aluguel marcado como pago');
            this.loadRentals('active');
        } catch (error) {
            this.showToast('Erro', 'Erro ao atualizar aluguel', 'error');
        }
    },

    async renderUsers(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between flex-wrap gap-4">
                    <div class="flex items-center gap-4">
                        <div class="relative">
                            <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                            <input type="text" id="userSearch" placeholder="Buscar usuários..."
                                onkeyup="Admin.filterUsers(this.value)"
                                class="input-field pl-10 pr-4 py-2 w-64">
                        </div>
                        <select id="userRoleFilter" onchange="Admin.filterUsersByRole(this.value)" 
                            class="input-field py-2 w-40">
                            <option value="">Todos os papéis</option>
                            <option value="user">Usuário</option>
                            <option value="owner">Lojista</option>
                            <option value="admin">Admin</option>
                            <option value="banned">Banido</option>
                        </select>
                    </div>
                </div>

                <div id="usersList" class="space-y-3">
                    <div class="text-center py-12">
                        <i class="fas fa-spinner fa-spin text-3xl text-primary"></i>
                        <p class="mt-4 text-gray-400">Carregando usuários...</p>
                    </div>
                </div>
            </div>
        `;
        
        await this.loadUsersList();
    },

    async loadUsersList() {
        const snapshot = await getDocs(collection(db, 'users'));
        this.users = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
        this.renderUsersList(this.users);
    },

    renderUsersList(users) {
        const container = document.getElementById('usersList');
        
        if (users.length === 0) {
            container.innerHTML = `
                <div class="text-center py-12 text-gray-500">
                    <i class="fas fa-users text-5xl mb-4 opacity-50"></i>
                    <p>Nenhum usuário encontrado</p>
                </div>
            `;
            return;
        }

        container.innerHTML = users.map(user => `
            <div class="glass rounded-xl p-4 flex items-center justify-between flex-wrap gap-4">
                <div class="flex items-center gap-3">
                    <img src="${user.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name || 'User')}&background=f97316&color=fff`}" 
                        class="w-12 h-12 rounded-full">
                    <div>
                        <p class="font-medium">${user.name || 'Sem nome'}</p>
                        <p class="text-sm text-gray-400">${user.email}</p>
                        <div class="flex items-center gap-2 mt-1">
                            <span class="text-xs px-2 py-0.5 rounded-full ${user.role === 'admin' ? 'bg-purple-500/20 text-purple-400' : user.role === 'owner' ? 'bg-primary/20 text-primary' : user.role === 'banned' ? 'bg-red-500/20 text-red-400' : 'bg-gray-500/20 text-gray-400'}">
                                ${user.role || 'user'}
                            </span>
                            <span class="text-xs text-gray-500">
                                Cadastrado em: ${user.createdAt?.toDate ? user.createdAt.toDate().toLocaleDateString() : '-'}
                            </span>
                        </div>
                    </div>
                </div>
                <div class="flex gap-2">
                    <button onclick="Admin.viewUserHistory('${user.id}')" 
                        class="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors text-sm">
                        <i class="fas fa-history mr-1"></i> Histórico
                    </button>
                    ${user.role !== 'banned' ? `
                        <button onclick="Admin.banUser('${user.id}')" 
                            class="px-3 py-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors text-sm">
                            <i class="fas fa-ban mr-1"></i> Banir
                        </button>
                    ` : `
                        <button onclick="Admin.unbanUser('${user.id}')" 
                            class="px-3 py-2 rounded-lg bg-green-500/20 text-green-400 hover:bg-green-500/30 transition-colors text-sm">
                            <i class="fas fa-check mr-1"></i> Desbanir
                        </button>
                    `}
                </div>
            </div>
        `).join('');
    },

    filterUsers(search) {
        const filtered = this.users.filter(u => 
            u.name?.toLowerCase().includes(search.toLowerCase()) ||
            u.email?.toLowerCase().includes(search.toLowerCase())
        );
        this.renderUsersList(filtered);
    },

    filterUsersByRole(role) {
        if (!role) {
            this.renderUsersList(this.users);
            return;
        }
        const filtered = this.users.filter(u => u.role === role);
        this.renderUsersList(filtered);
    },

    async banUser(userId) {
        const reason = prompt('Motivo do banimento:');
        if (!reason) return;
        
        try {
            await updateDoc(doc(db, 'users', userId), {
                role: 'banned',
                banReason: reason,
                bannedAt: serverTimestamp(),
                bannedBy: this.currentUser.uid
            });
            this.showToast('Sucesso', 'Usuário banido');
            this.loadUsersList();
        } catch (error) {
            this.showToast('Erro', 'Erro ao banir usuário', 'error');
        }
    },

    async unbanUser(userId) {
        try {
            await updateDoc(doc(db, 'users', userId), {
                role: 'user',
                banReason: null,
                bannedAt: null,
                bannedBy: null,
                unbannedAt: serverTimestamp(),
                unbannedBy: this.currentUser.uid
            });
            this.showToast('Sucesso', 'Usuário desbanido');
            this.loadUsersList();
        } catch (error) {
            this.showToast('Erro', 'Erro ao desbanir usuário', 'error');
        }
    },

    async viewUserHistory(userId) {
        const user = this.users.find(u => u.id === userId);
        if (!user) return;

        const ordersQuery = query(
            collection(db, 'orders'),
            where('customerId', '==', userId),
            orderBy('createdAt', 'desc')
        );
        const ordersSnap = await getDocs(ordersQuery);
        const orders = ordersSnap.docs.map(d => ({ id: d.id, ...d.data() }));

        const modal = document.createElement('div');
        modal.className = 'modal-overlay active';
        modal.id = 'userHistoryModal';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 700px;">
                <div class="p-6 border-b border-white/10 flex items-center justify-between">
                    <h3 class="text-xl font-bold">Histórico do Usuário</h3>
                    <button onclick="document.getElementById('userHistoryModal').remove()" class="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="p-6 space-y-4">
                    <div class="flex items-center gap-4 pb-4 border-b border-white/10">
                        <img src="${user.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name || 'User')}&background=f97316&color=fff`}" 
                            class="w-16 h-16 rounded-full">
                        <div>
                            <h4 class="font-bold text-lg">${user.name || 'Sem nome'}</h4>
                            <p class="text-gray-400">${user.email}</p>
                            <p class="text-sm text-gray-500">Cadastrado em: ${user.createdAt?.toDate ? user.createdAt.toDate().toLocaleDateString() : '-'}</p>
                        </div>
                    </div>
                    
                    <h4 class="font-bold">Pedidos (${orders.length})</h4>
                    <div class="space-y-2 max-h-64 overflow-y-auto">
                        ${orders.length > 0 ? orders.map(order => `
                            <div class="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                                <div>
                                    <p class="font-medium">#${order.id.slice(-6).toUpperCase()}</p>
                                    <p class="text-sm text-gray-400">${order.storeName || 'Loja'}</p>
                                </div>
                                <div class="text-right">
                                    <p class="font-bold">R$ ${(order.total || 0).toFixed(2)}</p>
                                    <span class="text-xs px-2 py-0.5 rounded-full ${this.getStatusClass(order.status)}">${this.getStatusLabel(order.status)}</span>
                                </div>
                            </div>
                        `).join('') : '<p class="text-gray-500 text-center py-4">Nenhum pedido encontrado</p>'}
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    },

    async renderPromote(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in max-w-2xl">
                <h2 class="text-2xl font-bold">Promover a Dono</h2>
                <p class="text-gray-400">Converta um usuário comum em lojista</p>

                <div class="glass rounded-xl p-6 space-y-4">
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Email do Usuário</label>
                        <input type="email" id="promoteEmail" class="input-field" placeholder="usuario@email.com">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Nome da Loja</label>
                        <input type="text" id="promoteStoreName" class="input-field" placeholder="Nome da nova loja">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Cidade</label>
                        <select id="promoteCity" class="input-field">
                            <option value="">Selecione...</option>
                        </select>
                    </div>
                    <button onclick="Admin.promoteToOwner()" class="btn btn-primary w-full">
                        <i class="fas fa-crown mr-2"></i> Promover a Dono
                    </button>
                </div>
            </div>
        `;
        
        const citiesSnap = await getDocs(collection(db, 'cities'));
        const cities = citiesSnap.docs.map(d => ({ id: d.id, ...d.data() }));
        document.getElementById('promoteCity').innerHTML = 
            '<option value="">Selecione...</option>' +
            cities.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    },

    async promoteToOwner() {
        const email = document.getElementById('promoteEmail').value.trim();
        const storeName = document.getElementById('promoteStoreName').value.trim();
        const cityId = document.getElementById('promoteCity').value;

        if (!email || !storeName || !cityId) {
            this.showToast('Erro', 'Preencha todos os campos', 'error');
            return;
        }

        try {
            const usersQuery = query(collection(db, 'users'), where('email', '==', email));
            const userSnap = await getDocs(usersQuery);
            
            if (userSnap.empty) {
                this.showToast('Erro', 'Usuário não encontrado', 'error');
                return;
            }

            const userId = userSnap.docs[0].id;
            const userData = userSnap.docs[0].data();

            await updateDoc(doc(db, 'users', userId), {
                role: 'owner',
                updatedAt: serverTimestamp()
            });

            const storeRef = doc(collection(db, 'stores'));
            await setDoc(storeRef, {
                name: storeName,
                ownerId: userId,
                ownerName: userData.name || email,
                cityId: cityId,
                active: true,
                createdAt: serverTimestamp(),
                items: [],
                orders: []
            });

            this.showToast('Sucesso', 'Usuário promovido a dono com sucesso!');
            document.getElementById('promoteEmail').value = '';
            document.getElementById('promoteStoreName').value = '';
        } catch (error) {
            console.error('Erro ao promover:', error);
            this.showToast('Erro', 'Erro ao promover usuário', 'error');
        }
    },

    renderPayments(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in max-w-2xl">
                <h2 class="text-2xl font-bold">Configurações de Pagamento</h2>
                <p class="text-gray-400">Configure taxas e gateways de pagamento da plataforma</p>

                <div class="glass rounded-xl p-6 space-y-6">
                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Taxa da Plataforma (%)</label>
                        <input type="number" id="platformFee" step="0.1" value="5" class="input-field">
                        <p class="text-xs text-gray-500 mt-1">Porcentagem cobrada de cada venda</p>
                    </div>

                    <div>
                        <label class="block text-sm text-gray-400 mb-2">Taxa de Aluguel Mensal (R$)</label>
                        <input type="number" id="rentalFee" step="0.01" value="99.90" class="input-field">
                    </div>

                    <button onclick="Admin.savePaymentSettings()" class="btn btn-primary w-full">
                        <i class="fas fa-save mr-2"></i> Salvar Configurações
                    </button>
                </div>
            </div>
        `;
    },

    async savePaymentSettings() {
        this.showToast('Sucesso', 'Configurações salvas!');
    },

    renderSecurity(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <h2 class="text-2xl font-bold">Segurança</h2>

                <div class="grid md:grid-cols-2 gap-6">
                    <div class="glass rounded-xl p-6">
                        <h3 class="font-bold text-lg mb-4">Alterar Senha</h3>
                        <form class="space-y-4" onsubmit="event.preventDefault(); Admin.changePassword();">
                            <input type="password" id="currentPassword" placeholder="Senha atual" class="input-field">
                            <input type="password" id="newPassword" placeholder="Nova senha" class="input-field">
                            <input type="password" id="confirmPassword" placeholder="Confirmar nova senha" class="input-field">
                            <button type="submit" class="btn btn-primary w-full">Alterar Senha</button>
                        </form>
                    </div>

                    <div class="glass rounded-xl p-6">
                        <h3 class="font-bold text-lg mb-4">Logs de Acesso</h3>
                        <div class="space-y-2 text-sm">
                            <div class="flex items-center justify-between p-2 bg-white/5 rounded">
                                <span>Login bem-sucedido</span>
                                <span class="text-gray-500">Hoje, 10:30</span>
                            </div>
                            <div class="flex items-center justify-between p-2 bg-white/5 rounded">
                                <span>Configurações alteradas</span>
                                <span class="text-gray-500">Ontem, 15:45</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    getStatusLabel(status) {
        const labels = {
            pending: 'Pendente',
            paid: 'Pago',
            preparing: 'Em preparo',
            shipped: 'Enviado',
            delivered: 'Entregue',
            cancelled: 'Cancelado'
        };
        return labels[status] || status;
    },

    getStatusClass(status) {
        const classes = {
            pending: 'bg-yellow-500/20 text-yellow-400',
            paid: 'bg-green-500/20 text-green-400',
            preparing: 'bg-blue-500/20 text-blue-400',
            shipped: 'bg-purple-500/20 text-purple-400',
            delivered: 'bg-green-500/20 text-green-400',
            cancelled: 'bg-red-500/20 text-red-400'
        };
        return classes[status] || 'bg-gray-500/20 text-gray-400';
    },

    showToast(title, message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `fixed bottom-4 right-4 z-50 flex items-center gap-3 px-6 py-4 rounded-xl shadow-2xl transform translate-y-0 transition-all duration-300 ${type === 'success' ? 'bg-green-500/20 border border-green-500/30 text-green-400' : type === 'error' ? 'bg-red-500/20 border border-red-500/30 text-red-400' : 'bg-yellow-500/20 border border-yellow-500/30 text-yellow-400'}`;
        toast.innerHTML = `
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'} text-xl"></i>
            <div>
                <p class="font-medium">${title}</p>
                <p class="text-sm opacity-80">${message}</p>
            </div>
        `;
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(100%)';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    },

    async logout() {
        try {
            await signOut(auth);
            window.location.href = 'index.html';
        } catch (error) {
            this.showToast('Erro', 'Erro ao fazer logout', 'error');
        }
    }
};

document.addEventListener('DOMContentLoaded', () => {
    window.Admin = Admin;
    Admin.init();
});

export default Admin;