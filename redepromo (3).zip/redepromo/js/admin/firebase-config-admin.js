// ==========================================
// CONFIGURAÇÃO FIREBASE - PAINEL ADMIN
// ==========================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-storage.js";

// ✅ MESMAS CREDENCIAIS DO APP PRINCIPAL
const firebaseConfig = {
    apiKey: "AIzaSyAQ58oORwzmU2S39DQMUxHNZpiMvglStdA",
    authDomain: "promomarket-gill.firebaseapp.com",
    projectId: "promomarket-gill",
    storageBucket: "promomarket-gill.firebasestorage.app",
    messagingSenderId: "304705286483",
    appId: "1:304705286483:web:c6d40c6e48b3fa1b9a31a6"
};

// Inicializar Firebase com nome único para evitar conflito
const app = initializeApp(firebaseConfig, 'adminApp');

// Exportar instâncias para uso global
window.firebaseAuthAdmin = getAuth(app);
window.firebaseDbAdmin = getFirestore(app);
window.firebaseStorageAdmin = getStorage(app);

console.log('✅ Firebase Admin inicializado');