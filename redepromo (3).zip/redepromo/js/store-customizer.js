// ==========================================
// STORE CUSTOMIZER - SISTEMA DE PERSONALIZAÇÃO VISUAL
// ==========================================

import { 
    doc, 
    getDoc, 
    setDoc, 
    updateDoc,
    serverTimestamp 
} from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";
import { 
    ref, 
    uploadBytes, 
    getDownloadURL 
} from "https://www.gstatic.com/firebasejs/12.9.0/firebase-storage.js";

const db = window.firebaseDb;
const storage = window.firebaseStorage;

const StoreCustomizer = {
    storeId: null,
    currentTheme: null,
    
    defaultTheme: {
        colors: {
            primary: '#f97316',
            secondary: '#ea580c',
            background: '#0f172a',
            surface: '#1e293b',
            text: '#ffffff',
            textMuted: '#94a3b8',
            accent: '#8b5cf6',
            success: '#22c55e',
            warning: '#eab308',
            danger: '#ef4444'
        },
        layout: {
            type: 'grid',
            columns: 3,
            borderRadius: 'rounded-xl',
            cardStyle: 'elevated',
            spacing: 'normal'
        },
        typography: {
            fontFamily: 'Inter',
            headingSize: 'large',
            bodySize: 'medium',
            priceSize: 'large'
        },
        header: {
            showLogo: true,
            showSearch: true,
            showCart: true,
            transparent: false,
            sticky: true
        },
        productCard: {
            showImage: true,
            showPrice: true,
            showOldPrice: true,
            showBadge: true,
            showDescription: false,
            imageRatio: 'square'
        },
        customCSS: ''
    },

    async init(storeId) {
        this.storeId = storeId;
        await this.loadTheme();
    },

    async loadTheme() {
        try {
            const themeDoc = await getDoc(doc(db, 'store_themes', this.storeId));
            if (themeDoc.exists()) {
                this.currentTheme = { ...this.defaultTheme, ...themeDoc.data() };
            } else {
                this.currentTheme = { ...this.defaultTheme };
            }
        } catch (error) {
            console.error('Erro ao carregar tema:', error);
            this.currentTheme = { ...this.defaultTheme };
        }
    },

    renderCustomizer(container) {
        const theme = this.currentTheme || this.defaultTheme;
        
        container.innerHTML = `
            <div class="space-y-8 animate-fade-in">
                <div class="flex items-center justify-between">
                    <div>
                        <h2 class="text-2xl font-bold">Personalização Visual</h2>
                        <p class="text-gray-400">Customize a aparência da sua loja</p>
                    </div>
                    <div class="flex gap-3">
                        <button onclick="StoreCustomizer.resetTheme()" class="btn btn-secondary">
                            <i class="fas fa-undo mr-2"></i> Restaurar Padrão
                        </button>
                        <button onclick="StoreCustomizer.saveTheme()" class="btn btn-primary">
                            <i class="fas fa-save mr-2"></i> Salvar Alterações
                        </button>
                    </div>
                </div>

                <div class="grid lg:grid-cols-3 gap-6">
                    <div class="lg:col-span-2 space-y-6">
                        
                        <!-- Cores -->
                        <div class="glass rounded-xl p-6">
                            <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
                                <i class="fas fa-palette text-primary"></i>
                                Cores da Loja
                            </h3>
                            <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
                                ${this.renderColorPicker('primary', 'Cor Primária', theme.colors.primary)}
                                ${this.renderColorPicker('secondary', 'Cor Secundária', theme.colors.secondary)}
                                ${this.renderColorPicker('accent', 'Cor de Destaque', theme.colors.accent)}
                                ${this.renderColorPicker('background', 'Fundo Principal', theme.colors.background)}
                                ${this.renderColorPicker('surface', 'Fundo dos Cards', theme.colors.surface)}
                                ${this.renderColorPicker('text', 'Cor do Texto', theme.colors.text)}
                            </div>
                        </div>

                        <!-- Layout -->
                        <div class="glass rounded-xl p-6">
                            <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
                                <i class="fas fa-th-large text-primary"></i>
                                Layout
                            </h3>
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm text-gray-400 mb-2">Tipo de Visualização</label>
                                    <div class="grid grid-cols-2 gap-3">
                                        <label class="cursor-pointer">
                                            <input type="radio" name="layoutType" value="grid" 
                                                ${theme.layout.type === 'grid' ? 'checked' : ''}
                                                onchange="StoreCustomizer.updateLayout('type', 'grid')"
                                                class="hidden peer">
                                            <div class="p-4 rounded-xl border-2 border-white/10 peer-checked:border-primary peer-checked:bg-primary/10 text-center transition-all">
                                                <i class="fas fa-th text-2xl mb-2"></i>
                                                <p class="font-medium">Grade</p>
                                            </div>
                                        </label>
                                        <label class="cursor-pointer">
                                            <input type="radio" name="layoutType" value="list" 
                                                ${theme.layout.type === 'list' ? 'checked' : ''}
                                                onchange="StoreCustomizer.updateLayout('type', 'list')"
                                                class="hidden peer">
                                            <div class="p-4 rounded-xl border-2 border-white/10 peer-checked:border-primary peer-checked:bg-primary/10 text-center transition-all">
                                                <i class="fas fa-list text-2xl mb-2"></i>
                                                <p class="font-medium">Lista</p>
                                            </div>
                                        </label>
                                    </div>
                                </div>

                                <div class="grid md:grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm text-gray-400 mb-2">Colunas (modo grade)</label>
                                        <select onchange="StoreCustomizer.updateLayout('columns', parseInt(this.value))" 
                                            class="input-field">
                                            <option value="2" ${theme.layout.columns === 2 ? 'selected' : ''}>2 colunas</option>
                                            <option value="3" ${theme.layout.columns === 3 ? 'selected' : ''}>3 colunas</option>
                                            <option value="4" ${theme.layout.columns === 4 ? 'selected' : ''}>4 colunas</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label class="block text-sm text-gray-400 mb-2">Estilo dos Cards</label>
                                        <select onchange="StoreCustomizer.updateLayout('cardStyle', this.value)"
                                            class="input-field">
                                            <option value="flat" ${theme.layout.cardStyle === 'flat' ? 'selected' : ''}>Plano</option>
                                            <option value="elevated" ${theme.layout.cardStyle === 'elevated' ? 'selected' : ''}>Elevado</option>
                                            <option value="bordered" ${theme.layout.cardStyle === 'bordered' ? 'selected' : ''}>Com Borda</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Tipografia -->
                        <div class="glass rounded-xl p-6">
                            <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
                                <i class="fas fa-font text-primary"></i>
                                Tipografia
                            </h3>
                            <div class="space-y-4">
                                <div>
                                    <label class="block text-sm text-gray-400 mb-2">Fonte</label>
                                    <select onchange="StoreCustomizer.updateTypography('fontFamily', this.value)"
                                        class="input-field">
                                        <option value="Inter" ${theme.typography.fontFamily === 'Inter' ? 'selected' : ''}>Inter (Moderna)</option>
                                        <option value="Roboto" ${theme.typography.fontFamily === 'Roboto' ? 'selected' : ''}>Roboto (Clássica)</option>
                                        <option value="Poppins" ${theme.typography.fontFamily === 'Poppins' ? 'selected' : ''}>Poppins (Amigável)</option>
                                        <option value="Playfair Display" ${theme.typography.fontFamily === 'Playfair Display' ? 'selected' : ''}>Playfair (Elegante)</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Imagens -->
                        <div class="glass rounded-xl p-6">
                            <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
                                <i class="fas fa-images text-primary"></i>
                                Imagens da Loja
                            </h3>
                            <div class="grid md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-sm text-gray-400 mb-2">Logo</label>
                                    <div class="relative group">
                                        <input type="file" id="themeLogoInput" accept="image/*" class="hidden" 
                                            onchange="StoreCustomizer.handleImageUpload(event, 'logo')">
                                        <label for="themeLogoInput" class="cursor-pointer block">
                                            <div class="aspect-square rounded-xl border-2 border-dashed border-white/20 hover:border-primary transition-colors overflow-hidden bg-white/5 flex items-center justify-center">
                                                <img id="themeLogoPreview" src="${theme.logo || ''}" 
                                                    class="w-full h-full object-contain p-4 ${theme.logo ? '' : 'hidden'}">
                                                <div id="themeLogoPlaceholder" class="text-center ${theme.logo ? 'hidden' : ''}">
                                                    <i class="fas fa-cloud-upload-alt text-3xl text-gray-500 mb-2"></i>
                                                    <span class="text-sm text-gray-400 block">Clique para upload</span>
                                                </div>
                                            </div>
                                        </label>
                                        ${theme.logo ? `
                                            <button onclick="StoreCustomizer.removeImage('logo')" 
                                                class="absolute top-2 right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                                <i class="fas fa-trash text-white text-xs"></i>
                                            </button>
                                        ` : ''}
                                    </div>
                                    <p class="text-xs text-gray-500 mt-2">Recomendado: 400x400px, PNG ou SVG</p>
                                </div>

                                <div>
                                    <label class="block text-sm text-gray-400 mb-2">Banner</label>
                                    <div class="relative group">
                                        <input type="file" id="themeBannerInput" accept="image/*" class="hidden"
                                            onchange="StoreCustomizer.handleImageUpload(event, 'banner')">
                                        <label for="themeBannerInput" class="cursor-pointer block">
                                            <div class="aspect-video rounded-xl border-2 border-dashed border-white/20 hover:border-primary transition-colors overflow-hidden bg-white/5 flex items-center justify-center">
                                                <img id="themeBannerPreview" src="${theme.banner || ''}" 
                                                    class="w-full h-full object-cover ${theme.banner ? '' : 'hidden'}">
                                                <div id="themeBannerPlaceholder" class="text-center ${theme.banner ? 'hidden' : ''}">
                                                    <i class="fas fa-cloud-upload-alt text-3xl text-gray-500 mb-2"></i>
                                                    <span class="text-sm text-gray-400 block">Clique para upload</span>
                                                </div>
                                            </div>
                                        </label>
                                        ${theme.banner ? `
                                            <button onclick="StoreCustomizer.removeImage('banner')" 
                                                class="absolute top-2 right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                                <i class="fas fa-trash text-white text-xs"></i>
                                            </button>
                                        ` : ''}
                                    </div>
                                    <p class="text-xs text-gray-500 mt-2">Recomendado: 1920x400px</p>
                                </div>
                            </div>
                        </div>

                        <!-- CSS Customizado -->
                        <div class="glass rounded-xl p-6">
                            <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
                                <i class="fas fa-code text-primary"></i>
                                CSS Personalizado
                            </h3>
                            <textarea 
                                onchange="StoreCustomizer.updateCustomCSS(this.value)"
                                rows="6" 
                                class="input-field w-full font-mono text-sm"
                                placeholder="/* Exemplo: */
.card-product { 
    border-radius: 20px; 
}">${theme.customCSS || ''}</textarea>
                        </div>
                    </div>

                    <!-- Preview -->
                    <div class="lg:col-span-1">
                        <div class="sticky top-24">
                            <h3 class="font-bold text-lg mb-4">Preview ao Vivo</h3>
                            <div class="glass rounded-xl overflow-hidden shadow-2xl">
                                <iframe id="themePreviewFrame" class="w-full h-[600px] border-0"></iframe>
                            </div>
                            <p class="text-sm text-gray-400 mt-3 text-center">
                                <i class="fas fa-info-circle mr-1"></i>
                                As alterações são aplicadas em tempo real
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        `;

        this.updatePreviewFrame();
    },

    renderColorPicker(key, label, value) {
        return `
            <div>
                <label class="block text-sm text-gray-400 mb-2">${label}</label>
                <div class="flex items-center gap-3">
                    <div class="color-picker-wrapper w-12 h-12" style="background-color: ${value}">
                        <input type="color" 
                            value="${value}"
                            onchange="StoreCustomizer.updateColor('${key}', this.value)"
                            class="w-full h-full opacity-0 cursor-pointer">
                    </div>
                    <input type="text" 
                        value="${value}"
                        onchange="StoreCustomizer.updateColor('${key}', this.value)"
                        class="input-field flex-1 rounded-lg px-3 py-2 text-sm font-mono uppercase">
                </div>
            </div>
        `;
    },

    updateColor(key, value) {
        if (!this.currentTheme) return;
        this.currentTheme.colors[key] = value;
        this.updatePreviewFrame();
    },

    updateLayout(key, value) {
        if (!this.currentTheme) return;
        this.currentTheme.layout[key] = value;
        this.updatePreviewFrame();
    },

    updateTypography(key, value) {
        if (!this.currentTheme) return;
        this.currentTheme.typography[key] = value;
        this.updatePreviewFrame();
    },

    updateCustomCSS(value) {
        if (!this.currentTheme) return;
        this.currentTheme.customCSS = value;
        this.updatePreviewFrame();
    },

    async handleImageUpload(event, type) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            document.getElementById(`theme${type.charAt(0).toUpperCase() + type.slice(1)}Preview`).src = e.target.result;
            document.getElementById(`theme${type.charAt(0).toUpperCase() + type.slice(1)}Preview`).classList.remove('hidden');
            document.getElementById(`theme${type.charAt(0).toUpperCase() + type.slice(1)}Placeholder`).classList.add('hidden');
        };
        reader.readAsDataURL(file);

        try {
            const storageRef = ref(storage, `stores/${this.storeId}/${type}_${Date.now()}_${file.name}`);
            await uploadBytes(storageRef, file);
            const url = await getDownloadURL(storageRef);
            
            this.currentTheme[type] = url;
            this.showToast('Imagem carregada com sucesso!', 'success');
        } catch (error) {
            console.error('Erro no upload:', error);
            this.showToast('Erro ao carregar imagem', 'error');
        }
    },

    removeImage(type) {
        this.currentTheme[type] = null;
        document.getElementById(`theme${type.charAt(0).toUpperCase() + type.slice(1)}Preview`).classList.add('hidden');
        document.getElementById(`theme${type.charAt(0).toUpperCase() + type.slice(1)}Placeholder`).classList.remove('hidden');
        this.updatePreviewFrame();
    },

    updatePreviewFrame() {
        const frame = document.getElementById('themePreviewFrame');
        if (!frame || !this.currentTheme) return;

        const theme = this.currentTheme;
        const html = `
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    @import url('https://fonts.googleapis.com/css2?family=${theme.typography.fontFamily.replace(' ', '+')}:wght@400;600;700&display=swap');
                    
                    * { margin: 0; padding: 0; box-sizing: border-box; }
                    
                    body {
                        font-family: '${theme.typography.fontFamily}', sans-serif;
                        background: ${theme.colors.background};
                        color: ${theme.colors.text};
                        padding: 20px;
                    }
                    
                    .header {
                        background: ${theme.colors.surface};
                        padding: 15px 20px;
                        border-radius: 12px;
                        margin-bottom: 20px;
                        display: flex;
                        align-items: center;
                        justify-content: space-between;
                    }
                    
                    .logo {
                        font-size: ${theme.typography.headingSize === 'large' ? '24px' : theme.typography.headingSize === 'medium' ? '20px' : '16px'};
                        font-weight: 700;
                        color: ${theme.colors.primary};
                    }
                    
                    .products-grid {
                        display: grid;
                        grid-template-columns: repeat(${theme.layout.columns}, 1fr);
                        gap: ${theme.layout.spacing === 'compact' ? '10px' : theme.layout.spacing === 'relaxed' ? '25px' : '15px'};
                    }
                    
                    .product-card {
                        background: ${theme.colors.surface};
                        border-radius: ${theme.layout.borderRadius === 'rounded-xl' ? '16px' : '8px'};
                        overflow: hidden;
                        ${theme.layout.cardStyle === 'elevated' ? 'box-shadow: 0 4px 20px rgba(0,0,0,0.3);' : 
                          theme.layout.cardStyle === 'bordered' ? `border: 2px solid ${theme.colors.primary};` : ''}
                    }
                    
                    .product-image {
                        aspect-ratio: ${theme.productCard.imageRatio === 'square' ? '1' : theme.productCard.imageRatio === 'portrait' ? '3/4' : '4/3'};
                        background: linear-gradient(135deg, ${theme.colors.primary}20, ${theme.colors.secondary}20);
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-size: 40px;
                        color: ${theme.colors.primary};
                    }
                    
                    .product-info {
                        padding: 15px;
                    }
                    
                    .product-name {
                        font-size: ${theme.typography.headingSize === 'large' ? '16px' : '14px'};
                        font-weight: 600;
                        margin-bottom: 8px;
                    }
                    
                    .product-price {
                        font-size: ${theme.typography.priceSize === 'large' ? '20px' : '16px'};
                        font-weight: 700;
                        color: ${theme.colors.primary};
                    }
                    
                    .btn-primary {
                        background: ${theme.colors.primary};
                        color: white;
                        border: none;
                        padding: 10px 20px;
                        border-radius: 8px;
                        font-weight: 600;
                        margin-top: 10px;
                        width: 100%;
                        cursor: pointer;
                    }
                    
                    ${theme.customCSS}
                </style>
            </head>
            <body>
                <div class="header">
                    <div class="logo">
                        ${theme.logo ? `<img src="${theme.logo}" style="height: 30px;">` : '🏪 Sua Loja'}
                    </div>
                    <div style="color: ${theme.colors.textMuted};">🔍 🛒</div>
                </div>
                
                <div class="products-grid">
                    ${[1, 2, 3, 4, 5, 6].map(i => `
                        <div class="product-card">
                            <div style="position: relative;">
                                <div class="product-image">📦</div>
                                ${theme.productCard.showBadge ? '<span style="position: absolute; top: 10px; left: 10px; background: ' + theme.colors.accent + '; color: white; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 600;">-20%</span>' : ''}
                            </div>
                            <div class="product-info">
                                <div class="product-name">Produto ${i}</div>
                                <div>
                                    <span class="product-price">R$ 99,90</span>
                                    ${theme.productCard.showOldPrice ? '<span style="font-size: 12px; color: ' + theme.colors.textMuted + '; text-decoration: line-through; margin-left: 8px;">R$ 129,90</span>' : ''}
                                </div>
                                <button class="btn-primary">Comprar</button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </body>
            </html>
        `;

        frame.srcdoc = html;
    },

    async saveTheme() {
        try {
            const themeData = {
                ...this.currentTheme,
                storeId: this.storeId,
                updatedAt: serverTimestamp(),
                updatedBy: window.firebaseAuth.currentUser?.uid
            };

            await setDoc(doc(db, 'store_themes', this.storeId), themeData);
            
            await updateDoc(doc(db, 'stores', this.storeId), {
                themeId: this.storeId,
                hasCustomTheme: true,
                updatedAt: serverTimestamp()
            });

            this.showToast('Tema salvo com sucesso!', 'success');
        } catch (error) {
            console.error('Erro ao salvar tema:', error);
            this.showToast('Erro ao salvar tema', 'error');
        }
    },

    resetTheme() {
        if (confirm('Tem certeza que deseja restaurar o tema padrão?')) {
            this.currentTheme = { ...this.defaultTheme };
            this.renderCustomizer(document.getElementById('contentArea'));
            this.showToast('Tema restaurado para o padrão', 'success');
        }
    },

    showToast(message, type = 'success') {
        if (window.OwnerPanel && window.OwnerPanel.showToast) {
            window.OwnerPanel.showToast(type === 'success' ? 'Sucesso' : 'Erro', message, type);
        }
    },

    // MÉTODO CORRIGIDO: Removido 'static' - agora é método de instância normal
    async applyThemeToPage(storeId) {
        try {
            const themeDoc = await getDoc(doc(db, 'store_themes', storeId));
            if (!themeDoc.exists()) return;

            const theme = themeDoc.data();
            
            let styleEl = document.getElementById('dynamic-store-theme');
            if (!styleEl) {
                styleEl = document.createElement('style');
                styleEl.id = 'dynamic-store-theme';
                document.head.appendChild(styleEl);
            }

            styleEl.textContent = `
                :root {
                    --store-primary: ${theme.colors.primary};
                    --store-secondary: ${theme.colors.secondary};
                    --store-accent: ${theme.colors.accent};
                    --store-bg: ${theme.colors.background};
                    --store-surface: ${theme.colors.surface};
                    --store-text: ${theme.colors.text};
                    --store-text-muted: ${theme.colors.textMuted};
                }
                
                .store-primary-bg { background-color: var(--store-primary) !important; }
                .store-primary-text { color: var(--store-primary) !important; }
                .store-bg { background-color: var(--store-bg) !important; }
                .store-surface { background-color: var(--store-surface) !important; }
                
                ${theme.customCSS || ''}
            `;

            if (theme.typography?.fontFamily) {
                document.body.style.fontFamily = theme.typography.fontFamily + ', sans-serif';
            }

            if (theme.logo) {
                document.querySelectorAll('.store-logo').forEach(el => el.src = theme.logo);
            }

            if (theme.banner) {
                document.querySelectorAll('.store-banner').forEach(el => el.style.backgroundImage = `url(${theme.banner})`);
            }

        } catch (error) {
            console.error('Erro ao aplicar tema:', error);
        }
    }
};

// Método estático alternativo para uso externo (não requer instância)
StoreCustomizer.applyThemeToPageStatic = async function(storeId) {
    const instance = Object.create(StoreCustomizer);
    instance.storeId = storeId;
    instance.currentTheme = null;
    await instance.applyThemeToPage(storeId);
};

window.StoreCustomizer = StoreCustomizer;
export default StoreCustomizer;