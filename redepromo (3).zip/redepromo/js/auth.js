// ==========================================
// AUTENTICAÇÃO - REDEPROMO (CORRIGIDO)
// ==========================================

import { 
    onAuthStateChanged, 
    signInWithEmailAndPassword, 
    createUserWithEmailAndPassword,
    signOut,
    GoogleAuthProvider,
    signInWithPopup,
    signInWithRedirect,
    getRedirectResult,
    updateProfile,
    sendPasswordResetEmail
} from "https://www.gstatic.com/firebasejs/12.9.0/firebase-auth.js";
import { doc, setDoc, getDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const Auth = {
    currentUser: null,
    userData: null,
    isProcessingGoogle: false,
    auth: null,
    db: null,

    // ✅ FUNÇÃO INIT QUE O APP.JS ESPERA
    init() {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const maxAttempts = 50;
            
            const checkFirebase = () => {
                attempts++;
                
                if (window.firebaseAuth && window.firebaseDb) {
                    this.auth = window.firebaseAuth;
                    this.db = window.firebaseDb;
                    console.log('✅ Auth: Firebase conectado');
                    this.setupAuth();
                    resolve();
                } else if (attempts >= maxAttempts) {
                    reject(new Error('Firebase não carregou após 5s'));
                } else {
                    setTimeout(checkFirebase, 100);
                }
            };
            
            checkFirebase();
        });
    },

    setupAuth() {
        // Verificar resultado de redirect (para mobile)
        this.checkRedirectResult();
        
        // Observar mudanças de estado
        onAuthStateChanged(this.auth, async (user) => {
            if (user) {
                console.log('✅ Usuário logado:', user.email);
                this.currentUser = user;
                await this.loadUserData(user.uid);
                this.updateUI();
                
                // Fechar modal de login
                const loginModal = document.getElementById('loginModal');
                if (loginModal) {
                    loginModal.classList.add('hidden');
                }
                document.body.style.overflow = '';
                
                // Disparar evento global
                window.dispatchEvent(new CustomEvent('user-logged-in', { detail: user }));
            } else {
                console.log('❌ Sem usuário logado');
                this.currentUser = null;
                this.userData = null;
                
                // Mostrar modal de login
                const loginModal = document.getElementById('loginModal');
                if (loginModal) {
                    loginModal.classList.remove('hidden');
                }
                document.body.style.overflow = 'hidden';
            }
        });
    },

    async checkRedirectResult() {
        try {
            const result = await getRedirectResult(this.auth);
            if (result) {
                console.log('✅ Login por redirect detectado');
                await this.handleGoogleSuccess(result);
            }
        } catch (error) {
            console.error('Erro no redirect:', error);
        }
    },

    async loadUserData(uid) {
        try {
            // Verificar se é admin
            const adminDoc = await getDoc(doc(this.db, 'admins', uid));
            const isAdmin = adminDoc.exists();
            
            // Buscar dados do usuário
            const userDoc = await getDoc(doc(this.db, 'users', uid));
            
            if (userDoc.exists()) {
                this.userData = { 
                    id: uid, 
                    ...userDoc.data(), 
                    isAdmin,
                    email: this.auth.currentUser?.email
                };
            } else {
                // Criar documento se não existir (usuário Google novo)
                const userData = {
                    name: this.auth.currentUser?.displayName || 'Usuário',
                    email: this.auth.currentUser?.email,
                    phone: '',
                    type: isAdmin ? 'admin' : 'customer',
                    createdAt: serverTimestamp(),
                    avatar: this.auth.currentUser?.photoURL || 
                           `https://ui-avatars.com/api/?name=${encodeURIComponent(this.auth.currentUser?.displayName || 'User')}&background=6366f1&color=fff`
                };
                
                await setDoc(doc(this.db, 'users', uid), userData);
                this.userData = { id: uid, ...userData, isAdmin };
            }

            // Se for dono de loja, carregar dados da loja
            if (this.userData.type === 'owner' && this.userData.storeId) {
                const storeDoc = await getDoc(doc(this.db, 'stores', this.userData.storeId));
                if (storeDoc.exists()) {
                    window.currentUserStore = { id: storeDoc.id, ...storeDoc.data() };
                }
            }

        } catch (error) {
            console.error('Erro ao carregar usuário:', error);
            this.showToast('Erro', 'Erro ao carregar dados do usuário', 'error');
        }
    },

    updateUI() {
        if (!this.userData) return;

        const avatarImg = document.getElementById('userAvatar');
        const initialDiv = document.getElementById('userInitial');
        const dropdownName = document.getElementById('dropdownName');
        const dropdownEmail = document.getElementById('dropdownEmail');

        // Avatar
        if (avatarImg && initialDiv) {
            if (this.userData.avatar) {
                avatarImg.src = this.userData.avatar;
                avatarImg.classList.remove('hidden');
                initialDiv.classList.add('hidden');
            } else {
                initialDiv.textContent = this.userData.name?.charAt(0).toUpperCase() || '?';
                avatarImg.classList.add('hidden');
                initialDiv.classList.remove('hidden');
            }
        }

        // Nome e email no dropdown
        if (dropdownName) dropdownName.textContent = this.userData.name || 'Usuário';
        if (dropdownEmail) dropdownEmail.textContent = this.userData.email || '';

        // Badges
        const typeBadge = document.getElementById('userTypeBadge');
        const ownerBadge = document.getElementById('ownerBadge');
        const adminBtn = document.getElementById('adminBtn');
        const menuAdmin = document.getElementById('menuAdmin');
        const myStoreBtn = document.getElementById('myStoreBtn');
        const menuMyStore = document.getElementById('menuMyStore');

        if (this.userData.isAdmin) {
            if (typeBadge) {
                typeBadge.textContent = 'ADMIN';
                typeBadge.className = 'px-2 py-1 rounded text-[10px] font-medium bg-purple-500/20 text-purple-400';
            }
            if (adminBtn) adminBtn.classList.remove('hidden');
            if (menuAdmin) menuAdmin.classList.remove('hidden');
            if (ownerBadge) ownerBadge.classList.add('hidden');
        } else if (this.userData.type === 'owner') {
            if (typeBadge) {
                typeBadge.textContent = 'DONO';
                typeBadge.className = 'px-2 py-1 rounded text-[10px] font-medium bg-green-500/20 text-green-400';
            }
            if (ownerBadge) ownerBadge.classList.remove('hidden');
            if (myStoreBtn) myStoreBtn.classList.remove('hidden');
            if (menuMyStore) menuMyStore.classList.remove('hidden');
            if (adminBtn) adminBtn.classList.add('hidden');
        } else {
            if (typeBadge) {
                typeBadge.textContent = 'CLIENTE';
                typeBadge.className = 'px-2 py-1 rounded text-[10px] font-medium bg-blue-500/20 text-blue-400';
            }
            if (ownerBadge) ownerBadge.classList.add('hidden');
            if (adminBtn) adminBtn.classList.add('hidden');
        }
    },

    switchTab(tab) {
        const loginTab = document.getElementById('tabLogin');
        const registerTab = document.getElementById('tabRegister');
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');

        if (!loginTab || !registerTab) return;

        if (tab === 'login') {
            loginTab.classList.add('active', 'text-white');
            loginTab.classList.remove('text-gray-400');
            registerTab.classList.remove('active', 'text-white');
            registerTab.classList.add('text-gray-400');
            if (loginForm) loginForm.classList.remove('hidden');
            if (registerForm) registerForm.classList.add('hidden');
        } else {
            registerTab.classList.add('active', 'text-white');
            registerTab.classList.remove('text-gray-400');
            loginTab.classList.remove('active', 'text-white');
            loginTab.classList.add('text-gray-400');
            if (registerForm) registerForm.classList.remove('hidden');
            if (loginForm) loginForm.classList.add('hidden');
        }
    },

    togglePassword(id) {
        const input = document.getElementById(id);
        if (!input) return;
        
        const icon = input.nextElementSibling?.querySelector('i');
        
        if (input.type === 'password') {
            input.type = 'text';
            if (icon) {
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            }
        } else {
            input.type = 'password';
            if (icon) {
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    },

    async handleLogin(e) {
        e.preventDefault();
        
        const btn = document.getElementById('loginBtn');
        if (btn) btn.classList.add('btn-loading');

        const emailInput = document.getElementById('loginEmail');
        const passwordInput = document.getElementById('loginPassword');
        
        const email = emailInput?.value.trim();
        const password = passwordInput?.value;

        if (!email || !password) {
            this.showToast('Erro', 'Preencha email e senha', 'error');
            if (btn) btn.classList.remove('btn-loading');
            return;
        }

        try {
            console.log('🔑 Tentando login:', email);
            const userCredential = await signInWithEmailAndPassword(this.auth, email, password);
            console.log('✅ Login bem-sucedido:', userCredential.user.email);
            
            this.showToast('Sucesso', 'Bem-vindo à RedePromo!');
            
            // Limpar campos
            if (emailInput) emailInput.value = '';
            if (passwordInput) passwordInput.value = '';
            
        } catch (error) {
            console.error('❌ Erro login:', error.code, error.message);
            
            let msg = 'Email ou senha incorretos';
            if (error.code === 'auth/user-not-found') msg = 'Usuário não encontrado';
            if (error.code === 'auth/wrong-password') msg = 'Senha incorreta';
            if (error.code === 'auth/invalid-email') msg = 'Email inválido';
            if (error.code === 'auth/too-many-requests') msg = 'Muitas tentativas. Aguarde um momento.';
            if (error.code === 'auth/invalid-credential') msg = 'Email ou senha incorretos';
            if (error.code === 'auth/user-disabled') msg = 'Conta desativada. Entre em contato.';
            
            this.showToast('Erro', msg, 'error');
        } finally {
            if (btn) btn.classList.remove('btn-loading');
        }
    },

    async handleRegister(e) {
        e.preventDefault();
        
        const btn = document.getElementById('registerBtn');
        if (btn) btn.classList.add('btn-loading');

        const nameInput = document.getElementById('regName');
        const emailInput = document.getElementById('regEmail');
        const phoneInput = document.getElementById('regPhone');
        const passwordInput = document.getElementById('regPassword');
        const confirmInput = document.getElementById('regPasswordConfirm');

        const name = nameInput?.value.trim();
        const email = emailInput?.value.trim().toLowerCase();
        const phone = phoneInput?.value.trim();
        const password = passwordInput?.value;
        const confirm = confirmInput?.value;

        // Validações
        if (!name || !email || !phone || !password || !confirm) {
            this.showToast('Erro', 'Preencha todos os campos', 'error');
            if (btn) btn.classList.remove('btn-loading');
            return;
        }

        if (password !== confirm) {
            this.showToast('Erro', 'As senhas não coincidem', 'error');
            if (btn) btn.classList.remove('btn-loading');
            return;
        }

        if (password.length < 6) {
            this.showToast('Erro', 'A senha deve ter no mínimo 6 caracteres', 'error');
            if (btn) btn.classList.remove('btn-loading');
            return;
        }

        if (!this.isValidEmail(email)) {
            this.showToast('Erro', 'Email inválido', 'error');
            if (btn) btn.classList.remove('btn-loading');
            return;
        }

        try {
            console.log('📝 Criando usuário:', email);
            
            // 1. Criar usuário no Auth
            const userCredential = await createUserWithEmailAndPassword(this.auth, email, password);
            const user = userCredential.user;
            console.log('✅ Usuário criado no Auth:', user.uid);
            
            // 2. Atualizar perfil com nome
            await updateProfile(user, { displayName: name });
            
            // 3. Criar documento no Firestore
            await setDoc(doc(this.db, 'users', user.uid), {
                name: name,
                email: email,
                phone: phone,
                type: 'customer',
                createdAt: serverTimestamp(),
                avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=6366f1&color=fff`
            });
            console.log('✅ Documento criado no Firestore');

            // 4. Forçar recarregamento dos dados
            await this.loadUserData(user.uid);
            this.updateUI();
            
            this.showToast('Sucesso', 'Conta criada com sucesso! Bem-vindo!');
            
            // 5. Limpar formulário
            if (nameInput) nameInput.value = '';
            if (emailInput) emailInput.value = '';
            if (phoneInput) phoneInput.value = '';
            if (passwordInput) passwordInput.value = '';
            if (confirmInput) confirmInput.value = '';
            
            // 6. Trocar para aba de login após 2 segundos
            setTimeout(() => {
                this.switchTab('login');
            }, 2000);
            
        } catch (error) {
            console.error('❌ Erro no registro:', error.code, error.message);
            
            let msg = 'Erro ao criar conta. Tente novamente.';
            if (error.code === 'auth/email-already-in-use') msg = 'Este email já está cadastrado. Tente fazer login.';
            if (error.code === 'auth/invalid-email') msg = 'Email inválido';
            if (error.code === 'auth/weak-password') msg = 'Senha muito fraca. Use pelo menos 6 caracteres.';
            if (error.code === 'auth/network-request-failed') msg = 'Sem conexão com internet. Verifique sua conexão.';
            
            this.showToast('Erro', msg, 'error');
        } finally {
            if (btn) btn.classList.remove('btn-loading');
        }
    },

    isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    },

    async resetPassword() {
        const emailInput = document.getElementById('loginEmail');
        const email = emailInput?.value.trim();

        if (!email) {
            this.showToast('Erro', 'Digite seu email no campo acima', 'error');
            return;
        }

        try {
            await sendPasswordResetEmail(this.auth, email);
            this.showToast('Sucesso', 'Email de recuperação enviado! Verifique sua caixa de entrada.');
        } catch (error) {
            console.error('Erro reset:', error);
            let msg = 'Erro ao enviar email';
            if (error.code === 'auth/user-not-found') msg = 'Email não encontrado';
            if (error.code === 'auth/invalid-email') msg = 'Email inválido';
            this.showToast('Erro', msg, 'error');
        }
    },

    async loginWithGoogle() {
        if (this.isProcessingGoogle) return;

        const btn = document.getElementById('googleBtn');
        const btnText = document.getElementById('googleBtnText');
        
        if (!btn || !btnText) {
            console.error('Botão do Google não encontrado');
            return;
        }

        this.isProcessingGoogle = true;
        btn.classList.add('google-btn-loading');
        btn.disabled = true;
        btnText.textContent = 'Conectando...';

        const timeoutId = setTimeout(() => {
            this.resetGoogleButton();
            this.isProcessingGoogle = false;
            this.showToast('Erro', 'Login demorou muito. Tente novamente.', 'error');
        }, 15000);

        try {
            const provider = new GoogleAuthProvider();
            provider.addScope('profile');
            provider.addScope('email');
            provider.setCustomParameters({ prompt: 'select_account' });

            try {
                const result = await signInWithPopup(this.auth, provider);
                clearTimeout(timeoutId);
                await this.handleGoogleSuccess(result);
            } catch (popupError) {
                console.warn('Popup erro:', popupError.code);
                
                if (popupError.code === 'auth/popup-blocked' || 
                    popupError.code === 'auth/cancelled-popup-request') {
                    // Tentar com redirect
                    btnText.textContent = 'Redirecionando...';
                    await signInWithRedirect(this.auth, provider);
                    return;
                }
                
                throw popupError;
            }
            
        } catch (error) {
            clearTimeout(timeoutId);
            console.error('❌ Erro login Google:', error);
            
            let msg = 'Erro no login com Google';
            if (error.code === 'auth/popup-blocked') msg = 'Popup bloqueado. Permita popups para este site.';
            if (error.code === 'auth/popup-closed-by-user') msg = 'Você fechou a janela de login.';
            if (error.code === 'auth/cancelled-popup-request') msg = 'Login cancelado.';
            if (error.code === 'auth/network-request-failed') msg = 'Sem conexão com internet.';
            if (error.code === 'auth/unauthorized-domain') msg = 'Domínio não autorizado no Firebase Console.';
            if (error.code === 'auth/operation-not-allowed') msg = 'Google Login não habilitado no Firebase.';
            
            this.showToast('Erro', msg, 'error');
        } finally {
            this.resetGoogleButton();
            this.isProcessingGoogle = false;
        }
    },

    resetGoogleButton() {
        const btn = document.getElementById('googleBtn');
        const btnText = document.getElementById('googleBtnText');
        
        if (btn) {
            btn.classList.remove('google-btn-loading');
            btn.disabled = false;
        }
        if (btnText) {
            btnText.textContent = 'Entrar com Google';
        }
    },

    async handleGoogleSuccess(result) {
        const user = result.user;
        console.log('✅ Google login sucesso:', user.displayName);
        
        try {
            const userDoc = await getDoc(doc(this.db, 'users', user.uid));
            
            if (!userDoc.exists()) {
                // Primeiro login com Google - criar documento
                await setDoc(doc(this.db, 'users', user.uid), {
                    name: user.displayName || 'Usuário',
                    email: user.email,
                    phone: '',
                    type: 'customer',
                    createdAt: serverTimestamp(),
                    avatar: user.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.displayName || 'User')}&background=6366f1&color=fff`
                });
                console.log('✅ Novo usuário Google criado');
            }
            
            await this.loadUserData(user.uid);
            this.updateUI();
            
            this.showToast('Sucesso', `Bem-vindo, ${user.displayName || 'Usuário'}!`);
            
        } catch (error) {
            console.error('Erro ao processar login Google:', error);
            this.showToast('Erro', 'Erro ao completar login. Tente novamente.', 'error');
        }
    },

    async logout() {
        try {
            await signOut(this.auth);
            this.showToast('Info', 'Você saiu da conta');
            localStorage.removeItem('redepromo_city');
            
            // Resetar UI
            this.currentUser = null;
            this.userData = null;
            
        } catch (error) {
            console.error('Erro ao sair:', error);
            this.showToast('Erro', 'Erro ao sair. Tente novamente.', 'error');
        }
    },

    toggleMenu() {
        const dropdown = document.getElementById('userDropdown');
        if (dropdown) {
            dropdown.classList.toggle('hidden');
        }
    },

    isAdmin() {
        return this.userData?.isAdmin || false;
    },

    isOwner() {
        return this.userData?.type === 'owner';
    },

    // Helper para mostrar toast (usa Utils se disponível)
    showToast(title, message, type = 'success') {
        if (window.Utils?.showToast) {
            window.Utils.showToast(title, message, type);
        } else {
            console.log(`[${type.toUpperCase()}] ${title}: ${message}`);
            alert(`${title}: ${message}`);
        }
    }
};

// Fechar dropdown ao clicar fora
document.addEventListener('click', (e) => {
    const menu = document.getElementById('userMenu');
    const dropdown = document.getElementById('userDropdown');
    
    if (menu && dropdown && !menu.contains(e.target)) {
        dropdown.classList.add('hidden');
    }
});

// Expor globalmente
window.Auth = Auth;
export default Auth;