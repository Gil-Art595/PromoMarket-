// ==========================================
// MULTI-GATEWAY DE PAGAMENTO
// Suporte: Mercado Pago, Asaas, PicPay, PIX Direto
// ==========================================

const Gateways = {
    // Configurações de cada gateway
    configs: {
        mercadopago: {
            name: 'Mercado Pago',
            icon: 'fas fa-credit-card',
            methods: ['credit_card', 'debit_card', 'pix', 'boleto'],
            hasSplit: true,
            hasRecurrence: true,
            sandbox: true
        },
        asaas: {
            name: 'Asaas',
            icon: 'fas fa-university',
            methods: ['credit_card', 'pix', 'boleto', 'transfer'],
            hasSplit: true,
            hasRecurrence: true, // Ótimo para aluguel!
            sandbox: true
        },
        picpay: {
            name: 'PicPay',
            icon: 'fas fa-mobile-alt',
            methods: ['credit_card', 'pix', 'picpay_wallet'],
            hasSplit: false,
            hasRecurrence: false,
            sandbox: true
        },
        pixdirect: {
            name: 'PIX Direto (Grátis)',
            icon: 'fas fa-qrcode',
            methods: ['pix'],
            hasSplit: false,
            hasRecurrence: false,
            sandbox: false // Não precisa, é direto
        }
    },

    // Inicializar gateway específico
    async init(gateway, credentials) {
        switch(gateway) {
            case 'mercadopago':
                return this.initMercadoPago(credentials);
            case 'asaas':
                return this.initAsaas(credentials);
            case 'picpay':
                return this.initPicPay(credentials);
            case 'pixdirect':
                return this.initPixDirect(credentials);
            default:
                throw new Error('Gateway não suportado');
        }
    },

    // Mercado Pago
    initMercadoPago(credentials) {
        if (!window.MercadoPago) {
            throw new Error('SDK do Mercado Pago não carregado');
        }
        
        return new MercadoPago(credentials.publicKey, {
            locale: 'pt-BR',
            advancedFraudPrevention: true
        });
    },

    // Asaas - Ótimo para cobrança de aluguel!
    initAsaas(credentials) {
        // Asaas usa API REST, não precisa de SDK no frontend
        return {
            apiKey: credentials.apiKey,
            sandbox: credentials.sandbox !== false,
            baseUrl: credentials.sandbox !== false 
                ? 'https://sandbox.asaas.com/api/v3'
                : 'https://api.asaas.com/v3'
        };
    },

    // PicPay
    initPicPay(credentials) {
        return {
            picpayToken: credentials.picpayToken,
            sellerToken: credentials.sellerToken,
            sandbox: credentials.sandbox !== false
        };
    },

    // PIX Direto (sem intermediário)
    initPixDirect(credentials) {
        return {
            pixKey: credentials.pixKey, // CPF/CNPJ/Email/Celular do lojista
            description: credentials.description || 'Pagamento RedePromo',
            merchantName: credentials.merchantName
        };
    },

    // Criar cobrança em qualquer gateway
    async createCharge(gateway, config, data) {
        switch(gateway) {
            case 'mercadopago':
                return this.createMPCharge(config, data);
            case 'asaas':
                return this.createAsaasCharge(config, data);
            case 'picpay':
                return this.createPicPayCharge(config, data);
            case 'pixdirect':
                return this.createPixDirectCharge(config, data);
        }
    },

    // Criar cobrança no Asaas (ótimo para aluguel!)
    async createAsaasCharge(config, data) {
        // Criar cliente primeiro se não existir
        const customer = await this.createAsaasCustomer(config, data.customer);
        
        const chargeData = {
            customer: customer.id,
            billingType: data.paymentMethod === 'credit_card' ? 'CREDIT_CARD' : 
                        data.paymentMethod === 'pix' ? 'PIX' : 'BOLETO',
            value: data.amount,
            dueDate: data.dueDate || new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            description: data.description,
            externalReference: data.orderId
        };

        // Se for cartão, adicionar dados do cartão
        if (data.paymentMethod === 'credit_card' && data.card) {
            chargeData.creditCard = {
                holderName: data.card.holderName,
                number: data.card.number,
                expiryMonth: data.card.expiryMonth,
                expiryYear: data.card.expiryYear,
                ccv: data.card.ccv
            };
            chargeData.creditCardHolderInfo = {
                name: data.customer.name,
                email: data.customer.email,
                cpfCnpj: data.customer.document,
                postalCode: data.customer.zipCode,
                addressNumber: data.customer.addressNumber,
                phone: data.customer.phone
            };
        }

        const response = await fetch(`${config.baseUrl}/payments`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'access_token': config.apiKey
            },
            body: JSON.stringify(chargeData)
        });

        return await response.json();
    },

    async createAsaasCustomer(config, customerData) {
        // Buscar cliente existente
        const search = await fetch(`${config.baseUrl}/customers?cpfCnpj=${customerData.document}`, {
            headers: { 'access_token': config.apiKey }
        });
        const searchData = await search.json();

        if (searchData.data && searchData.data.length > 0) {
            return searchData.data[0];
        }

        // Criar novo cliente
        const response = await fetch(`${config.baseUrl}/customers`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'access_token': config.apiKey
            },
            body: JSON.stringify({
                name: customerData.name,
                email: customerData.email,
                cpfCnpj: customerData.document,
                phone: customerData.phone,
                postalCode: customerData.zipCode,
                addressNumber: customerData.addressNumber
            })
        });

        return await response.json();
    },

    // Criar assinatura (PERFEITO para aluguel mensal!)
    async createSubscription(config, data) {
        const customer = await this.createAsaasCustomer(config, data.customer);
        
        const subscriptionData = {
            customer: customer.id,
            billingType: data.paymentMethod === 'credit_card' ? 'CREDIT_CARD' : 'BOLETO',
            value: data.amount,
            nextDueDate: data.startDate || new Date().toISOString().split('T')[0],
            cycle: 'MONTHLY', // Mensal!
            description: data.description,
            externalReference: data.reference
        };

        const response = await fetch(`${config.baseUrl}/subscriptions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'access_token': config.apiKey
            },
            body: JSON.stringify(subscriptionData)
        });

        return await response.json();
    },

    // PIX Direto - Gera QR Code sem intermediário
    createPixDirectCharge(config, data) {
        // Gerar payload PIX válido (EMV Code)
        const pixPayload = this.generatePixPayload({
            key: config.pixKey,
            amount: data.amount,
            description: data.description,
            merchantName: config.merchantName,
            transactionId: data.orderId
        });

        return {
            qrCode: pixPayload,
            qrCodeImage: this.generateQRCodeImage(pixPayload),
            copyPaste: pixPayload
        };
    },

    // Gerar payload PIX válido (formato EMV)
    generatePixPayload(data) {
        const { key, amount, description, merchantName, transactionId } = data;
        
        // Formatação do valor
        const amountStr = amount.toFixed(2);
        
        // IDs dos campos PIX
        const ID_PAYLOAD_FORMAT = '01';
        const ID_MERCHANT_ACCOUNT = '26';
        const ID_MERCHANT_ACCOUNT_GUI = '00';
        const ID_MERCHANT_ACCOUNT_KEY = '01';
        const ID_MERCHANT_ACCOUNT_DESCRIPTION = '02';
        const ID_MERCHANT_CATEGORY = '52';
        const ID_TRANSACTION_CURRENCY = '53';
        const ID_TRANSACTION_AMOUNT = '54';
        const ID_COUNTRY_CODE = '58';
        const ID_MERCHANT_NAME = '59';
        const ID_MERCHANT_CITY = '60';
        const ID_ADDITIONAL_DATA = '62';
        const ID_ADDITIONAL_DATA_TXID = '05';
        const ID_CRC16 = '63';

        // Construir payload
        let payload = '';
        
        // Payload Format Indicator
        payload += this.makeField(ID_PAYLOAD_FORMAT, '01');
        
        // Merchant Account Information
        let merchantAccount = '';
        merchantAccount += this.makeField(ID_MERCHANT_ACCOUNT_GUI, 'br.gov.bcb.pix');
        merchantAccount += this.makeField(ID_MERCHANT_ACCOUNT_KEY, key);
        if (description) {
            merchantAccount += this.makeField(ID_MERCHANT_ACCOUNT_DESCRIPTION, description.substring(0, 40));
        }
        payload += this.makeField(ID_MERCHANT_ACCOUNT, merchantAccount);
        
        // Merchant Category Code (0000 = não especificado)
        payload += this.makeField(ID_MERCHANT_CATEGORY, '0000');
        
        // Transaction Currency (986 = BRL)
        payload += this.makeField(ID_TRANSACTION_CURRENCY, '986');
        
        // Transaction Amount
        payload += this.makeField(ID_TRANSACTION_AMOUNT, amountStr);
        
        // Country Code
        payload += this.makeField(ID_COUNTRY_CODE, 'BR');
        
        // Merchant Name
        payload += this.makeField(ID_MERCHANT_NAME, merchantName.substring(0, 25));
        
        // Merchant City (fixo ou dinâmico)
        payload += this.makeField(ID_MERCHANT_CITY, 'SAOPAULO');
        
        // Additional Data (TXID)
        if (transactionId) {
            let additionalData = this.makeField(ID_ADDITIONAL_DATA_TXID, transactionId.substring(0, 25));
            payload += this.makeField(ID_ADDITIONAL_DATA, additionalData);
        }
        
        // CRC16
        payload += ID_CRC16 + '04';
        const crc = this.calculateCRC16(payload);
        payload += crc;

        return payload;
    },

    makeField(id, value) {
        const length = value.length.toString().padStart(2, '0');
        return id + length + value;
    },

    calculateCRC16(payload) {
        let crc = 0xFFFF;
        for (let i = 0; i < payload.length; i++) {
            crc ^= payload.charCodeAt(i) << 8;
            for (let j = 0; j < 8; j++) {
                crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
            }
        }
        return (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
    },

    generateQRCodeImage(payload) {
        // Retorna data URL do QR code (será gerado no frontend com biblioteca)
        return null; // A biblioteca QRCode.js vai gerar no elemento canvas
    },

    // Webhook handlers
    async handleWebhook(gateway, payload) {
        switch(gateway) {
            case 'mercadopago':
                return this.handleMPWebhook(payload);
            case 'asaas':
                return this.handleAsaasWebhook(payload);
            case 'picpay':
                return this.handlePicPayWebhook(payload);
        }
    },

    handleAsaasWebhook(payload) {
        // Processar notificação do Asaas
        const { event, payment } = payload;
        
        if (event === 'PAYMENT_RECEIVED' || event === 'PAYMENT_CONFIRMED') {
            return {
                status: 'paid',
                orderId: payment.externalReference,
                gatewayId: payment.id,
                amount: payment.value
            };
        }
        
        if (event === 'PAYMENT_OVERDUE') {
            return {
                status: 'overdue',
                orderId: payment.externalReference
            };
        }

        return null;
    }
};

window.Gateways = Gateways;
export default Gateways;