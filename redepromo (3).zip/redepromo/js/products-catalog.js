// ==========================================
// CATÁLOGO DE PRODUTOS - MARKETPLACE
// ==========================================

import { collection, query, where, orderBy, limit, startAfter, getDocs, onSnapshot } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const db = window.firebaseDb;

const ProductsCatalog = {
    allProducts: [],
    filteredProducts: [],
    displayedProducts: [],
    lastVisible: null,
    productsPerPage: 20,
    currentFilter: 'all',
    
    async init() {
        await this.loadAllProducts();
        this.setupRealtimeListeners();
    },

    async loadAllProducts() {
        try {
            // Buscar todas as lojas ativas com produtos
            const storesQuery = query(
                collection(db, 'stores'),
                where('active', '!=', false),
                orderBy('active'),
                orderBy('name')
            );
            
            const storesSnapshot = await getDocs(storesQuery);
            const allProducts = [];
            
            storesSnapshot.forEach(doc => {
                const store = { id: doc.id, ...doc.data() };
                const items = store.items || [];
                
                items.forEach(item => {
                    if (item.active !== false) {
                        allProducts.push({
                            ...item,
                            storeId: store.id,
                            storeName: store.name,
                            storeLogo: store.logo || store.image,
                            cityId: store.cityId,
                            cityName: window.Cities?.data?.find(c => c.id === store.cityId)?.name || ''
                        });
                    }
                });
            });
            
            // Ordenar por mais recente (assumindo que ID tem timestamp)
            this.allProducts = allProducts.sort((a, b) => {
                // Se tiver updatedAt, usar ele, senão usar ID
                const dateA = a.updatedAt ? new Date(a.updatedAt) : new Date(parseInt(a.id) || 0);
                const dateB = b.updatedAt ? new Date(b.updatedAt) : new Date(parseInt(b.id) || 0);
                return dateB - dateA;
            });
            
            this.filteredProducts = [...this.allProducts];
            this.displayedProducts = this.filteredProducts.slice(0, this.productsPerPage);
            
            this.renderAllProducts();
            this.renderSaleProducts();
            
        } catch (error) {
            console.error('Erro ao carregar produtos:', error);
        }
    },

    renderAllProducts() {
        const container = document.getElementById('allProductsGrid');
        if (!container) return;
        
        if (this.displayedProducts.length === 0) {
            container.innerHTML = `
                <div class="col-span-full text-center py-12 text-gray-500">
                    <i class="fas fa-box-open text-4xl mb-4 opacity-50"></i>
                    <p>Nenhum produto encontrado</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = this.displayedProducts.map(product => this.createProductCard(product)).join('');
        
        // Mostrar/ocultar botão "Carregar mais"
        const loadMoreBtn = document.getElementById('loadMoreProducts');
        if (loadMoreBtn) {
            loadMoreBtn.classList.toggle('hidden', this.displayedProducts.length >= this.filteredProducts.length);
        }
    },

    renderSaleProducts() {
        const container = document.getElementById('saleProductsGrid');
        if (!container) return;
        
        // Produtos com desconto (oldPrice > price) ou promoções ativas
        const saleProducts = this.allProducts.filter(p => {
            const hasDiscount = p.oldPrice && p.oldPrice > p.price;
            const hasActivePromo = p.promotions?.some(promo => promo.active);
            return hasDiscount || hasActivePromo;
        }).slice(0, 8);
        
        if (saleProducts.length === 0) {
            container.innerHTML = `
                <div class="col-span-full text-center py-8 text-gray-500">
                    <p>Sem produtos em oferta no momento</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = saleProducts.map(product => this.createProductCard(product, true)).join('');
    },

    createProductCard(product, isSale = false) {
        const discount = product.oldPrice ? Math.round((1 - product.price/product.oldPrice) * 100) : 0;
        const activePromo = product.promotions?.find(p => p.active);
        
        return `
            <div class="glass rounded-2xl overflow-hidden group hover:ring-2 ring-primary/50 transition-all cursor-pointer animate-fade-in"
                 onclick="ProductsCatalog.openProductDetail('${product.id}', '${product.storeId}')">
                <div class="relative aspect-square overflow-hidden">
                    <img src="${product.image || 'https://via.placeholder.com/300'}" 
                        alt="${product.name}" 
                        class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                        loading="lazy">
                    
                    ${discount > 0 ? `
                        <div class="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-lg">
                            -${discount}%
                        </div>
                    ` : ''}
                    
                    ${activePromo ? `
                        <div class="absolute top-2 right-2 bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded-lg animate-pulse">
                            ${activePromo.highlight}
                        </div>
                    ` : ''}
                    
                    ${product.featured ? `
                        <div class="absolute bottom-2 left-2 bg-primary/80 text-white text-[10px] font-bold px-2 py-1 rounded backdrop-blur-sm">
                            <i class="fas fa-star mr-1"></i>DESTAQUE
                        </div>
                    ` : ''}
                    
                    <!-- Quick Actions -->
                    <div class="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <button onclick="event.stopPropagation(); ProductsCatalog.addToCart('${product.id}')" 
                            class="w-10 h-10 rounded-full bg-white/20 hover:bg-primary text-white flex items-center justify-center backdrop-blur-sm transition-colors">
                            <i class="fas fa-shopping-cart"></i>
                        </button>
                        <button onclick="event.stopPropagation(); ProductsCatalog.quickView('${product.id}')" 
                            class="w-10 h-10 rounded-full bg-white/20 hover:bg-white text-gray-900 flex items-center justify-center backdrop-blur-sm transition-colors">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                
                <div class="p-4">
                    <!-- Loja -->
                    <div class="flex items-center gap-2 mb-2">
                        <img src="${product.storeLogo || 'https://via.placeholder.com/30'}" 
                            class="w-5 h-5 rounded-full object-cover">
                        <span class="text-xs text-gray-400 truncate">${product.storeName}</span>
                    </div>
                    
                    <!-- Nome -->
                    <h3 class="font-semibold text-sm mb-1 line-clamp-2 group-hover:text-primary transition-colors">
                        ${product.name}
                    </h3>
                    
                    <!-- Descrição -->
                    <p class="text-xs text-gray-500 line-clamp-1 mb-2">${product.description || ''}</p>
                    
                    <!-- Preço -->
                    <div class="flex items-end gap-2">
                        <span class="text-lg font-bold text-primary">R$ ${product.price.toFixed(2)}</span>
                        ${product.oldPrice ? `
                            <span class="text-sm text-gray-500 line-through">R$ ${product.oldPrice.toFixed(2)}</span>
                        ` : ''}
                    </div>
                    
                    <!-- Variações -->
                    ${product.variations?.length > 0 ? `
                        <div class="flex flex-wrap gap-1 mt-2">
                            ${product.variations.slice(0, 3).map(v => `
                                <span class="text-[10px] px-2 py-0.5 rounded bg-gray-700/50 text-gray-300">
                                    ${v.name}
                                </span>
                            `).join('')}
                            ${product.variations.length > 3 ? `
                                <span class="text-[10px] px-2 py-0.5 rounded bg-gray-700/50 text-gray-300">
                                    +${product.variations.length - 3}
                                </span>
                            ` : ''}
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    },

    // Busca de produtos
    searchProducts(searchTerm) {
        if (!searchTerm.trim()) {
            this.clearSearch();
            return;
        }
        
        const term = searchTerm.toLowerCase();
        this.filteredProducts = this.allProducts.filter(p => 
            p.name.toLowerCase().includes(term) ||
            p.description?.toLowerCase().includes(term) ||
            p.category?.toLowerCase().includes(term) ||
            p.storeName.toLowerCase().includes(term)
        );
        
        this.displayedProducts = this.filteredProducts.slice(0, this.productsPerPage);
        this.renderAllProducts();
        
        // Mostrar seção de busca
        const searchSection = document.getElementById('searchSection');
        const searchCount = document.getElementById('searchResultsCount');
        const searchGrid = document.getElementById('searchResultsGrid');
        
        if (searchSection) {
            searchSection.classList.remove('hidden');
            if (searchCount) searchCount.textContent = `${this.filteredProducts.length} produto(s) encontrado(s)`;
            if (searchGrid) {
                searchGrid.innerHTML = this.displayedProducts.map(p => this.createProductCard(p)).join('');
            }
        }
    },

    clearSearch() {
        document.getElementById('productSearchInput').value = '';
        document.getElementById('searchSection').classList.add('hidden');
        this.filteredProducts = [...this.allProducts];
        this.displayedProducts = this.filteredProducts.slice(0, this.productsPerPage);
        this.renderAllProducts();
    },

    // Filtros
    filterProductsByCategory(category) {
        if (!category) {
            this.filteredProducts = [...this.allProducts];
        } else {
            this.filteredProducts = this.allProducts.filter(p => p.category === category);
        }
        this.displayedProducts = this.filteredProducts.slice(0, this.productsPerPage);
        this.renderAllProducts();
    },

    filterProductsByPromotion() {
        this.filteredProducts = this.allProducts.filter(p => {
            const hasDiscount = p.oldPrice && p.oldPrice > p.price;
            const hasActivePromo = p.promotions?.some(promo => promo.active);
            return hasDiscount || hasActivePromo;
        });
        this.displayedProducts = this.filteredProducts.slice(0, this.productsPerPage);
        this.renderAllProducts();
        document.getElementById('productCategoryFilter').value = '';
    },

    sortProducts(sortBy) {
        switch(sortBy) {
            case 'price-low':
                this.filteredProducts.sort((a, b) => a.price - b.price);
                break;
            case 'price-high':
                this.filteredProducts.sort((a, b) => b.price - a.price);
                break;
            case 'name':
                this.filteredProducts.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'newest':
            default:
                this.filteredProducts.sort((a, b) => {
                    const dateA = a.updatedAt ? new Date(a.updatedAt) : new Date(parseInt(a.id) || 0);
                    const dateB = b.updatedAt ? new Date(b.updatedAt) : new Date(parseInt(b.id) || 0);
                    return dateB - dateA;
                });
        }
        this.displayedProducts = this.filteredProducts.slice(0, this.productsPerPage);
        this.renderAllProducts();
    },

    loadMoreProducts() {
        const currentLength = this.displayedProducts.length;
        const nextBatch = this.filteredProducts.slice(currentLength, currentLength + this.productsPerPage);
        this.displayedProducts = [...this.displayedProducts, ...nextBatch];
        this.renderAllProducts();
    },

    // Ações
    openProductDetail(productId, storeId) {
        // Abrir modal de detalhe do produto ou redirecionar para loja
        window.Stores.openProductDetail(productId, storeId);
    },

    addToCart(productId) {
        // Implementar carrinho
        Utils.showToast('Info', 'Adicionado ao carrinho!', 'success');
    },

    quickView(productId) {
        // Implementar visualização rápida
        const product = this.allProducts.find(p => p.id === productId);
        if (product) {
            // Abrir modal rápido
            console.log('Quick view:', product);
        }
    },

    setupRealtimeListeners() {
        // Atualizar quando lojas mudarem
        onSnapshot(collection(db, 'stores'), (snapshot) => {
            this.loadAllProducts();
        });
    }
};

window.ProductsCatalog = ProductsCatalog;
export default ProductsCatalog;