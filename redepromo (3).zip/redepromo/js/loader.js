const ModuleLoader = {
    loadOrder: [
        'firebase-config.js',
        'utils.js', 
        'cities.js',
        'auth.js',
        'stores.js',
        'products.js',
        'payment.js',
        'owner.js',
        'admin.js',
        'app.js' // SEMPRE por último
    ],

    async init() {
        const basePath = './js/';
        
        for (const file of this.loadOrder) {
            await this.loadModule(basePath + file);
            console.log(`✅ ${file} carregado`);
        }
    },

    loadModule(url) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.type = 'module';
            script.src = url;
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }
};

ModuleLoader.init();