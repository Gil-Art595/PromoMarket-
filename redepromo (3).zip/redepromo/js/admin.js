// ==========================================
// PAINEL ADMINISTRATIVO
// ==========================================

import { collection, doc, getDocs, getDoc, setDoc, updateDoc, deleteDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const db = window.firebaseDb;

const Admin = {
    currentTab: 'dashboard',
    selectedStoreId: null,

    toggle() {
        const modal = document.getElementById('adminModal');
        
        if (modal.classList.contains('hidden')) {
            if (!Auth.isAdmin()) {
                Utils.showToast('Erro', 'Acesso negado', 'error');
                return;
            }
            
            modal.classList.remove('hidden');
            setTimeout(() => {
                document.getElementById('adminModalContent').classList.add('show');
            }, 10);
            
            this.showTab('dashboard');
        } else {
            const content = document.getElementById('adminModalContent');
            content.classList.remove('show');
            setTimeout(() => {
                modal.classList.add('hidden');
            }, 300);
        }
    },

    showTab(tab) {
        this.currentTab = tab;
        
        document.querySelectorAll('.admin-tab').forEach(t => {
            t.classList.remove('active', 'text-white');
            t.classList.add('text-gray-300');
        });
        document.querySelector(`.admin-tab[data-tab="${tab}"]`)?.classList.add('active', 'text-white');
        document.querySelector(`.admin-tab[data-tab="${tab}"]`)?.classList.remove('text-gray-300');
        
        const content = document.getElementById('adminContent');
        
        switch(tab) {
            case 'dashboard':
                this.renderDashboard(content);
                break;
            case 'cities':
                this.renderCities(content);
                break;
            case 'stores':
                this.renderStores(content);
                break;
            case 'owners':
                this.renderOwners(content);
                break;
            case 'payments':
                this.renderPayments(content);
                break;
            // ✅ NOVO: Case para rentals adicionado
            case 'rentals':
                this.renderRentals(content);
                break;
            case 'users':
                this.renderUsers(content);
                break;
        }
    },

    renderDashboard(container) {
        const stats = {
            stores: Stores.data.length,
            users: 0,
            cities: Cities.data.length,
            orders: 0
        };

        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <h2 class="text-2xl font-bold">Dashboard</h2>
                
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div class="glass rounded-2xl p-6 text-center">
                        <div class="text-3xl font-bold text-primary">${stats.stores}</div>
                        <div class="text-sm text-gray-400">Lojas</div>
                    </div>
                    <div class="glass rounded-2xl p-6 text-center">
                        <div class="text-3xl font-bold text-green-400">${stats.cities}</div>
                        <div class="text-sm text-gray-400">Cidades</div>
                    </div>
                    <div class="glass rounded-2xl p-6 text-center">
                        <div class="text-3xl font-bold text-orange-400">-</div>
                        <div class="text-sm text-gray-400">Usuários</div>
                    </div>
                    <div class="glass rounded-2xl p-6 text-center">
                        <div class="text-3xl font-bold text-accent">-</div>
                        <div class="text-sm text-gray-400">Pedidos</div>
                    </div>
                </div>
            </div>
        `;
    },

    renderCities(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <h2 class="text-2xl font-bold">Gerenciar Cidades</h2>
                
                <div id="cityFormContainer"></div>
                <div id="cityListContainer" class="mt-6"></div>
            </div>
        `;
        
        Cities.renderCreateForm('cityFormContainer');
        Cities.renderAdminList('cityListContainer');
    },

    renderStores(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between">
                    <h2 class="text-2xl font-bold">Gerenciar Lojas</h2>
                    <button onclick="Admin.createStore()" class="btn btn-primary">
                        <i class="fas fa-plus mr-2"></i> Nova Loja
                    </button>
                </div>
                
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Loja</th>
                                <th>Cidade</th>
                                <th>Dono</th>
                                <th>Produtos</th>
                                <th>Pagamento</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${Stores.data.map(store => {
                                const city = Cities.data.find(c => c.id === store.cityId);
                                const hasPayment = store.mercadoPago?.accessToken ? 
                                    '<span class="text-green-400"><i class="fas fa-check"></i> Configurado</span>' : 
                                    '<span class="text-red-400"><i class="fas fa-times"></i> Pendente</span>';
                                
                                return `
                                    <tr>
                                        <td>
                                            <div class="flex items-center gap-2">
                                                <img src="${store.logo}" class="w-8 h-8 rounded-full">
                                                <span class="font-medium">${store.name}</span>
                                            </div>
                                        </td>
                                        <td>${city?.name || '-'}</td>
                                        <td>${store.ownerName || '-'}</td>
                                        <td>${store.items?.length || 0}</td>
                                        <td>${hasPayment}</td>
                                        <td>
                                            <button onclick="Admin.configurePayment('${store.id}')" class="text-primary hover:text-white mr-2" title="Configurar Pagamento">
                                                <i class="fas fa-credit-card"></i>
                                            </button>
                                            <button onclick="Admin.editStore('${store.id}')" class="text-blue-400 hover:text-white mr-2">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button onclick="Admin.deleteStore('${store.id}')" class="text-red-400 hover:text-white">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    },

    renderOwners(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <h2 class="text-2xl font-bold">Promover a Dono</h2>
                <p class="text-gray-400">Selecione um usuário para tornar dono de loja</p>
                
                <div id="usersListForOwner" class="space-y-2">
                    <p class="text-center text-gray-500 py-8">Carregando usuários...</p>
                </div>
            </div>
        `;
        
        this.loadUsersForOwner();
    },

    async loadUsersForOwner() {
        const snapshot = await getDocs(collection(db, 'users'));
        const users = snapshot.docs.map(d => ({ id: d.id, ...d.data() })).filter(u => u.type === 'customer');
        
        const container = document.getElementById('usersListForOwner');
        if (!container) return;
        
        container.innerHTML = users.map(user => `
            <div class="glass rounded-xl p-4 flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <img src="${user.avatar}" class="w-10 h-10 rounded-full">
                    <div>
                        <p class="font-medium">${user.name}</p>
                        <p class="text-sm text-gray-400">${user.email}</p>
                    </div>
                </div>
                <button onclick="Admin.promoteToOwner('${user.id}')" class="btn btn-success text-sm">
                    <i class="fas fa-crown mr-1"></i> Tornar Dono
                </button>
            </div>
        `).join('');
    },

    renderPayments(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <h2 class="text-2xl font-bold">Configurar Pagamentos</h2>
                <p class="text-gray-400 mb-4">Gerencie as chaves API do Mercado Pago das lojas</p>
                
                ${this.selectedStoreId ? this.renderPaymentForm() : this.renderPaymentStoreList()}
            </div>
        `;
    },

    renderPaymentStoreList() {
        return `
            <div class="space-y-2">
                ${Stores.data.map(store => {
                    const configured = store.mercadoPago?.accessToken;
                    return `
                        <div class="glass rounded-xl p-4 flex items-center justify-between cursor-pointer hover:bg-white/5" onclick="Admin.selectStoreForPayment('${store.id}')">
                            <div class="flex items-center gap-3">
                                <img src="${store.logo}" class="w-10 h-10 rounded-full">
                                <div>
                                    <p class="font-medium">${store.name}</p>
                                    <p class="text-sm ${configured ? 'text-green-400' : 'text-red-400'}">
                                        ${configured ? '✅ Configurado' : '❌ Não configurado'}
                                    </p>
                                </div>
                            </div>
                            <i class="fas fa-chevron-right text-gray-400"></i>
                        </div>
                    `;
                }).join('')}
            </div>
        `;
    },

    renderPaymentForm() {
        const store = Stores.data.find(s => s.id === this.selectedStoreId);
        if (!store) return '<p>Loja não encontrada</p>';
        
        return `
            <div class="glass rounded-xl p-6 space-y-4">
                <div class="flex items-center gap-3 mb-4">
                    <button onclick="Admin.selectedStoreId = null; Admin.showTab('payments')" class="text-gray-400 hover:text-white">
                        <i class="fas fa-arrow-left"></i>
                    </button>
                    <img src="${store.logo}" class="w-10 h-10 rounded-full">
                    <h3 class="font-bold text-lg">${store.name}</h3>
                </div>
                
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    <div>
                        <p class="font-medium">Como obter as chaves:</p>
                        <ol class="text-sm mt-1 list-decimal list-inside">
                            <li>Acesse <a href="https://www.mercadopago.com.br/developers" target="_blank" class="underline">developers.mercadopago.com.br</a></li>
                            <li>Crie uma aplicação ou acesse existente</li>
                            <li>Copie o Access Token (produção)</li>
                            <li>Cole abaixo</li>
                        </ol>
                    </div>
                </div>

                <div>
                    <label class="form-label">Access Token *</label>
                    <input type="password" id="mpAccessToken" class="input-field w-full rounded-xl px-4 py-3" 
                           placeholder="APP_USR-..." value="${store.mercadoPago?.accessToken || ''}">
                    <p class="text-xs text-gray-500 mt-1">Começa com APP_USR-</p>
                </div>

                <div>
                    <label class="form-label">Public Key</label>
                    <input type="text" id="mpPublicKey" class="input-field w-full rounded-xl px-4 py-3" 
                           placeholder="APP_USR-..." value="${store.mercadoPago?.publicKey || ''}">
                </div>

                <div>
                    <label class="form-label">Chave PIX do Lojista (para fallback)</label>
                    <input type="text" id="mpPixKey" class="input-field w-full rounded-xl px-4 py-3" 
                           placeholder="CPF, CNPJ, email ou celular" value="${store.mercadoPago?.pixKey || ''}">
                </div>

                <div class="flex gap-3">
                    <button onclick="Admin.savePaymentConfig()" class="btn btn-primary flex-1">
                        <i class="fas fa-save mr-2"></i> Salvar Configuração
                    </button>
                    <button onclick="Admin.testPaymentConnection()" class="btn btn-secondary">
                        <i class="fas fa-plug"></i> Testar
                    </button>
                </div>
            </div>
        `;
    },

    selectStoreForPayment(storeId) {
        this.selectedStoreId = storeId;
        this.showTab('payments');
    },

    async savePaymentConfig() {
        const btn = event.target;
        btn.classList.add('btn-loading');

        try {
            const config = {
                accessToken: document.getElementById('mpAccessToken').value.trim(),
                publicKey: document.getElementById('mpPublicKey').value.trim(),
                pixKey: document.getElementById('mpPixKey').value.trim(),
                configuredAt: serverTimestamp()
            };

            await updateDoc(doc(db, 'stores', this.selectedStoreId), {
                mercadoPago: config,
                updatedAt: serverTimestamp()
            });

            Utils.showToast('Sucesso', 'Configuração de pagamento salva!');
            
            // Atualizar dados locais
            const storeIndex = Stores.data.findIndex(s => s.id === this.selectedStoreId);
            if (storeIndex !== -1) {
                Stores.data[storeIndex].mercadoPago = config;
            }

        } catch (error) {
            console.error(error);
            Utils.showToast('Erro', 'Erro ao salvar configuração', 'error');
        } finally {
            btn.classList.remove('btn-loading');
        }
    },

    async testPaymentConnection() {
        Utils.showToast('Info', 'Teste de conexão em desenvolvimento');
    },

    async promoteToOwner(userId) {
        const storeName = prompt('Nome da nova loja:');
        if (!storeName) return;

        const cityId = prompt('ID da cidade:');
        if (!cityId) return;

        try {
            // Criar loja
            const storeRef = doc(collection(db, 'stores'));
            await setDoc(storeRef, {
                name: storeName,
                cityId: cityId,
                ownerId: userId,
                ownerName: '-',
                items: [],
                orders: [],
                deliveryOptions: { allowDelivery: true, allowPickup: true, deliveryFee: 0 },
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            });

            // Atualizar usuário
            await updateDoc(doc(db, 'users', userId), {
                type: 'owner',
                storeId: storeRef.id,
                updatedAt: serverTimestamp()
            });

            Utils.showToast('Sucesso', 'Usuário promovido a dono!');
            this.showTab('owners');

        } catch (error) {
            Utils.showToast('Erro', 'Erro ao promover usuário', 'error');
        }
    },

    async createStore() {
        Utils.showToast('Info', 'Use "Promover a Dono" para criar loja vinculada a um usuário');
        this.showTab('owners');
    },

    configurePayment(storeId) {
        this.selectedStoreId = storeId;
        this.showTab('payments');
    },

    editStore(storeId) {
        Utils.showToast('Info', 'Edição de loja em desenvolvimento');
    },

    async deleteStore(storeId) {
        if (!confirm('Tem certeza? Isso remove TODOS os produtos e pedidos da loja!')) return;

        try {
            await deleteDoc(doc(db, 'stores', storeId));
            Utils.showToast('Sucesso', 'Loja removida');
        } catch (error) {
            Utils.showToast('Erro', 'Erro ao remover loja', 'error');
        }
    },

    // ✅ NOVO: Função renderRentals adicionada
    renderRentals(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <div class="flex items-center justify-between">
                    <h2 class="text-2xl font-bold">Gerenciar Aluguéis</h2>
                    <button onclick="Rental.checkOverdueRentals()" class="btn btn-primary">
                        <i class="fas fa-sync mr-2"></i> Verificar Atrasados
                    </button>
                </div>
                <div id="rentalDashboard"></div>
            </div>
        `;
        
        Rental.renderRentalDashboard('rentalDashboard');
    },

    renderUsers(container) {
        container.innerHTML = `
            <div class="space-y-6 animate-fade-in">
                <h2 class="text-2xl font-bold">Todos os Usuários</h2>
                <p class="text-gray-400">Funcionalidade em desenvolvimento</p>
            </div>
        `;
    }
};

window.Admin = Admin;
export default Admin;