// ==========================================
// CHAT ENTRE CLIENTE E LOJISTA
// ==========================================

import { collection, doc, getDocs, getDoc, setDoc, updateDoc, query, where, orderBy, onSnapshot, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.9.0/firebase-firestore.js";

const db = window.firebaseDb;

const Chat = {
    currentChatId: null,
    currentChatData: null,
    unsubscribe: null,

    // Iniciar ou retomar chat
    async startChat(storeId, productId = null, initialMessage = null) {
        const userId = Auth.userData?.id;
        if (!userId) {
            Utils.showToast('Erro', 'Faça login para iniciar chat', 'error');
            return;
        }

        // Verificar se já existe chat
        const existingChat = await this.findExistingChat(userId, storeId);
        
        if (existingChat) {
            this.openChat(existingChat.id);
        } else {
            // Criar novo chat
            const store = Stores.data.find(s => s.id === storeId);
            
            const chatData = {
                id: Utils.generateId(),
                participants: [userId, store.ownerId],
                storeId: storeId,
                storeName: store.name,
                storeLogo: store.logo,
                customerId: userId,
                customerName: Auth.userData.name,
                customerAvatar: Auth.userData.avatar,
                productId: productId,
                lastMessage: initialMessage || null,
                lastMessageAt: serverTimestamp(),
                unreadCount: {
                    [userId]: 0,
                    [store.ownerId]: initialMessage ? 1 : 0
                },
                status: 'active', // active, closed, blocked
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
            };

            await setDoc(doc(db, 'chats', chatData.id), chatData);

            if (initialMessage) {
                await this.sendMessage(chatData.id, initialMessage, 'text');
            }

            this.openChat(chatData.id);
        }
    },

    // Buscar chat existente
    async findExistingChat(userId, storeId) {
        const q = query(
            collection(db, 'chats'),
            where('customerId', '==', userId),
            where('storeId', '==', storeId),
            where('status', '==', 'active')
        );

        const snapshot = await getDocs(q);
        return snapshot.empty ? null : { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
    },

    // Abrir chat
    async openChat(chatId) {
        this.currentChatId = chatId;
        
        const chatDoc = await getDoc(doc(db, 'chats', chatId));
        this.currentChatData = { id: chatDoc.id, ...chatDoc.data() };

        this.renderChatWindow();
        this.setupRealtimeMessages(chatId);
        this.markAsRead(chatId);
    },

    // Setup listener de mensagens em tempo real
    setupRealtimeMessages(chatId) {
        if (this.unsubscribe) {
            this.unsubscribe();
        }

        const q = query(
            collection(db, 'chats', chatId, 'messages'),
            orderBy('createdAt', 'asc')
        );

        this.unsubscribe = onSnapshot(q, (snapshot) => {
            const messages = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
            this.renderMessages(messages);
            
            // Scroll to bottom
            const container = document.getElementById('chatMessages');
            if (container) {
                container.scrollTop = container.scrollHeight;
            }
        });
    },

    // Enviar mensagem
    async sendMessage(chatId = this.currentChatId, content, type = 'text', metadata = null) {
        if (!chatId || !content.trim()) return;

        const messageData = {
            id: Utils.generateId(),
            chatId: chatId,
            senderId: Auth.userData.id,
            senderName: Auth.userData.name,
            senderAvatar: Auth.userData.avatar,
            type: type, // text, image, product, order
            content: content,
            metadata: metadata,
            read: false,
            createdAt: serverTimestamp()
        };

        // Salvar mensagem
        await setDoc(doc(db, 'chats', chatId, 'messages', messageData.id), messageData);

        // Atualizar chat
        const otherUserId = this.getOtherParticipant();
        const currentUnread = this.currentChatData?.unreadCount?.[otherUserId] || 0;

        await updateDoc(doc(db, 'chats', chatId), {
            lastMessage: type === 'text' ? content : `[${type}]`,
            lastMessageAt: serverTimestamp(),
            [`unreadCount.${otherUserId}`]: currentUnread + 1,
            updatedAt: serverTimestamp()
        });

        // Notificar receptor
        Notifications.sendPush('Nova mensagem', {
            body: `${Auth.userData.name}: ${content.substring(0, 50)}${content.length > 50 ? '...' : ''}`,
            tag: `chat-${chatId}`
        });
    },

    getOtherParticipant() {
        if (!this.currentChatData) return null;
        return this.currentChatData.participants.find(id => id !== Auth.userData.id);
    },

    // Marcar mensagens como lidas
    async markAsRead(chatId) {
        const userId = Auth.userData.id;
        
        await updateDoc(doc(db, 'chats', chatId), {
            [`unreadCount.${userId}`]: 0,
            updatedAt: serverTimestamp()
        });

        // Marcar mensagens individuais como lidas
        const q = query(
            collection(db, 'chats', chatId, 'messages'),
            where('senderId', '!=', userId),
            where('read', '==', false)
        );

        const snapshot = await getDocs(q);
        const batch = [];

        snapshot.forEach(docSnap => {
            batch.push(updateDoc(doc(db, 'chats', chatId, 'messages', docSnap.id), {
                read: true,
                readAt: serverTimestamp()
            }));
        });

        await Promise.all(batch);
    },

    // Renderizar janela de chat
    renderChatWindow() {
        const isStore = Auth.userData?.type === 'owner';
        const otherParty = isStore ? {
            name: this.currentChatData.customerName,
            avatar: this.currentChatData.customerAvatar
        } : {
            name: this.currentChatData.storeName,
            avatar: this.currentChatData.storeLogo
        };

        const modal = document.createElement('div');
        modal.id = 'chatModal';
        modal.className = 'fixed inset-0 z-[80] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4';
        modal.innerHTML = `
            <div class="glass-strong w-full max-w-2xl h-[80vh] rounded-2xl flex flex-col animate-scale-in">
                <!-- Header -->
                <div class="p-4 border-b border-gray-700 flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <img src="${otherParty.avatar}" class="w-10 h-10 rounded-full">
                        <div>
                            <h3 class="font-bold">${otherParty.name}</h3>
                            <p class="text-xs text-green-400 flex items-center gap-1">
                                <span class="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                                Online
                            </p>
                        </div>
                    </div>
                    <div class="flex items-center gap-2">
                        ${this.currentChatData.productId ? `
                            <button onclick="Chat.showProductInfo()" class="p-2 glass rounded-lg hover:bg-white/10" title="Ver produto">
                                <i class="fas fa-box"></i>
                            </button>
                        ` : ''}
                        <button onclick="Chat.closeChat()" class="p-2 glass rounded-lg hover:bg-red-500/20 text-red-400">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>

                <!-- Messages -->
                <div id="chatMessages" class="flex-1 overflow-y-auto p-4 space-y-3">
                    <div class="text-center text-gray-500 text-sm">
                        <p>Início da conversa</p>
                        <p class="text-xs">${Utils.formatDate(this.currentChatData.createdAt)}</p>
                    </div>
                </div>

                <!-- Input -->
                <div class="p-4 border-t border-gray-700">
                    <form onsubmit="Chat.handleSubmit(event)" class="flex gap-2">
                        <button type="button" onclick="Chat.attachImage()" class="p-3 glass rounded-xl hover:bg-white/10">
                            <i class="fas fa-image"></i>
                        </button>
                        <input type="text" id="chatInput" placeholder="Digite sua mensagem..." 
                               class="input-field flex-1 rounded-xl px-4 py-3" autocomplete="off">
                        <button type="submit" class="p-3 bg-primary rounded-xl hover:bg-primary/80">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </form>
                </div>
            </div>
        `;

        // Fechar ao clicar fora
        modal.addEventListener('click', (e) => {
            if (e.target === modal) this.closeChat();
        });

        document.body.appendChild(modal);
        document.getElementById('chatInput').focus();
    },

    // Renderizar mensagens
    renderMessages(messages) {
        const container = document.getElementById('chatMessages');
        if (!container) return;

        const userId = Auth.userData.id;

        container.innerHTML = `
            <div class="text-center text-gray-500 text-sm mb-4">
                <p>Início da conversa</p>
            </div>
            ${messages.map(msg => {
                const isMe = msg.senderId === userId;
                const time = msg.createdAt?.toDate ? msg.createdAt.toDate().toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'}) : '';

                let content = '';
                switch(msg.type) {
                    case 'text':
                        content = `<p>${msg.content}</p>`;
                        break;
                    case 'image':
                        content = `<img src="${msg.content}" class="max-w-xs rounded-lg cursor-pointer" onclick="window.open('${msg.content}')">`;
                        break;
                    case 'product':
                        content = `
                            <div class="glass rounded-lg p-2 flex gap-2 cursor-pointer hover:bg-white/5" onclick="Stores.openProductDetail('${msg.metadata.productId}', '${msg.metadata.storeId}')">
                                <img src="${msg.metadata.image}" class="w-12 h-12 object-cover rounded">
                                <div>
                                    <p class="text-sm font-medium">${msg.metadata.name}</p>
                                    <p class="text-xs text-primary">R$ ${msg.metadata.price.toFixed(2)}</p>
                                </div>
                            </div>
                        `;
                        break;
                    case 'order':
                        content = `
                            <div class="glass rounded-lg p-2 border-l-2 border-green-500">
                                <p class="text-sm font-medium">Pedido #${msg.metadata.orderId.slice(-6)}</p>
                                <p class="text-xs text-gray-400">Status: ${msg.metadata.status}</p>
                            </div>
                        `;
                        break;
                }

                return `
                    <div class="flex ${isMe ? 'justify-end' : 'justify-start'}">
                        <div class="max-w-[70%] ${isMe ? 'bg-primary/20 rounded-2xl rounded-tr-sm' : 'glass rounded-2xl rounded-tl-sm'} px-4 py-2">
                            ${!isMe ? `<p class="text-xs text-primary mb-1">${msg.senderName}</p>` : ''}
                            ${content}
                            <div class="flex items-center justify-end gap-1 mt-1">
                                <span class="text-xs text-gray-500">${time}</span>
                                ${isMe ? `<i class="fas fa-${msg.read ? 'check-double text-blue-400' : 'check text-gray-500'} text-xs"></i>` : ''}
                            </div>
                        </div>
                    </div>
                `;
            }).join('')}
        `;

        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    },

    async handleSubmit(e) {
        e.preventDefault();
        const input = document.getElementById('chatInput');
        const message = input.value.trim();
        
        if (!message) return;

        input.value = '';
        await this.sendMessage(this.currentChatId, message, 'text');
    },

    async attachImage() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            Utils.showToast('Info', 'Enviando imagem...', 'info');
            
            const optimized = await Products.optimizeAndUpload(file);
            await this.sendMessage(this.currentChatId, optimized.url, 'image');
        };

        input.click();
    },

    // Compartilhar produto no chat
    async shareProduct(productId, storeId) {
        const store = Stores.data.find(s => s.id === storeId);
        const product = store.items.find(i => i.id === productId);

        await this.sendMessage(this.currentChatId, null, 'product', {
            productId: product.id,
            storeId: store.id,
            name: product.name,
            price: product.price,
            image: product.image
        });
    },

    showProductInfo() {
        if (this.currentChatData.productId) {
            Stores.openProductDetail(this.currentChatData.productId, this.currentChatData.storeId);
        }
    },

    // Renderizar lista de chats (para lojista)
    async renderChatList(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const userId = Auth.userData.id;
        const isStore = Auth.userData?.type === 'owner';

        let q;
        if (isStore) {
            q = query(
                collection(db, 'chats'),
                where('storeId', '==', window.currentUserStore?.id),
                orderBy('lastMessageAt', 'desc')
            );
        } else {
            q = query(
                collection(db, 'chats'),
                where('customerId', '==', userId),
                orderBy('lastMessageAt', 'desc')
            );
        }

        const snapshot = await getDocs(q);
        const chats = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));

        if (chats.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-comments text-3xl mb-3"></i>
                    <p>Sem conversas ainda</p>
                    <p class="text-sm">Inicie uma conversa com uma loja!</p>
                </div>
            `;
            return;
        }

        container.innerHTML = chats.map(chat => {
            const otherParty = isStore ? {
                name: chat.customerName,
                avatar: chat.customerAvatar
            } : {
                name: chat.storeName,
                avatar: chat.storeLogo
            };

            const unread = chat.unreadCount?.[userId] || 0;

            return `
                <div onclick="Chat.openChat('${chat.id}')" 
                     class="glass rounded-xl p-3 flex items-center gap-3 cursor-pointer hover:bg-white/5 transition-colors ${unread > 0 ? 'border-l-4 border-primary' : ''}">
                    <img src="${otherParty.avatar}" class="w-12 h-12 rounded-full">
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center justify-between">
                            <h4 class="font-medium truncate">${otherParty.name}</h4>
                            <span class="text-xs text-gray-500">${chat.lastMessageAt?.toDate ? Utils.formatDate(chat.lastMessageAt) : ''}</span>
                        </div>
                        <p class="text-sm text-gray-400 truncate ${unread > 0 ? 'font-medium text-white' : ''}">
                            ${chat.lastMessage || 'Sem mensagens'}
                        </p>
                    </div>
                    ${unread > 0 ? `<span class="w-5 h-5 bg-primary rounded-full text-xs flex items-center justify-center">${unread}</span>` : ''}
                </div>
            `;
        }).join('');
    },

    closeChat() {
        if (this.unsubscribe) {
            this.unsubscribe();
            this.unsubscribe = null;
        }
        
        const modal = document.getElementById('chatModal');
        if (modal) {
            modal.remove();
        }
        
        this.currentChatId = null;
        this.currentChatData = null;
    },

    // Botão flutuante de chat (para clientes)
    renderChatButton(containerId, storeId) {
        const container = document.getElementById(containerId);
        if (!container || Auth.userData?.type === 'owner') return;

        container.innerHTML = `
            <button onclick="Chat.startChat('${storeId}')" 
                    class="fixed bottom-24 right-4 w-14 h-14 bg-primary rounded-full shadow-lg shadow-primary/50 flex items-center justify-center text-white text-xl hover:scale-110 transition-transform z-30">
                <i class="fas fa-comment-dots"></i>
            </button>
        `;
    }
};

window.Chat = Chat;
export default Chat;