// ==========================================
// APLICAÇÃO PRINCIPAL - REDEPROMO (CORRIGIDO)
// ==========================================

const App = {
    initialized: false,

    async init() {
        if (this.initialized) {
            console.log('App já inicializado');
            return;
        }
        
        console.log('🚀 Inicializando RedePromo...');
        
        try {
            // 1. Aguardar Firebase
            await this.waitForFirebase();
            console.log('✅ Firebase pronto');
            
            // 2. Inicializar módulos na ordem correta
            await this.initializeModules();
            
            // 3. Configurar eventos globais
            this.setupGlobalEvents();
            
            this.initialized = true;
            console.log('✅ RedePromo inicializado com sucesso!');
            
        } catch (error) {
            console.error('❌ Erro na inicialização:', error);
            alert('Erro ao carregar: ' + error.message);
        }
    },

    async waitForFirebase() {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const maxAttempts = 100; // 10 segundos
            
            const check = () => {
                attempts++;
                
                if (window.firebaseDb && window.firebaseAuth) {
                    console.log('✅ Firebase detectado');
                    resolve();
                } else if (attempts >= maxAttempts) {
                    reject(new Error('Firebase não carregou após 10s. Verifique sua conexão.'));
                } else {
                    if (attempts % 10 === 0) {
                        console.log(`⏳ Aguardando Firebase... (${attempts/10}s)`);
                    }
                    setTimeout(check, 100);
                }
            };
            
            check();
        });
    },

    async initializeModules() {
        // Lista de módulos e se são obrigatórios
        const modules = [
            { name: 'Utils', required: true },
            { name: 'Auth', required: true },
            { name: 'Cities', required: false },
            { name: 'Stores', required: false },
            { name: 'Products', required: false },
            { name: 'ProductsCatalog', required: false },  // ✅ NOVO
            { name: 'Payment', required: false },
            { name: 'Owner', required: false },
            { name: 'Admin', required: false }
        ];
        
        for (const { name, required } of modules) {
            const mod = window[name];
            
            if (mod && typeof mod.init === 'function') {
                try {
                    await mod.init();
                    console.log(`✅ ${name} inicializado`);
                } catch (err) {
                    console.error(`❌ Erro em ${name}:`, err);
                    if (required) {
                        throw new Error(`Falha ao inicializar ${name}: ${err.message}`);
                    }
                }
            } else if (required) {
                throw new Error(`Módulo ${name} não encontrado ou sem função init()`);
            } else {
                console.log(`⚠️ ${name} não encontrado (opcional)`);
            }
        }
    },

    setupGlobalEvents() {
        // Fechar modais com ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
        
        // Evento quando usuário loga
        window.addEventListener('user-logged-in', (e) => {
            console.log('🎉 Evento: usuário logado', e.detail.email);
        });
    },

    closeAllModals() {
        const modals = [
            'loginModal', 
            'checkoutModal', 
            'storeModal', 
            'ownerModal', 
            'adminModal'
        ];
        
        modals.forEach(id => {
            const modal = document.getElementById(id);
            if (modal) {
                modal.classList.add('hidden');
            }
        });
    },

    showSection(section) {
        const el = document.getElementById(section);
        if (el) {
            el.scrollIntoView({ behavior: 'smooth' });
        } else if (section === 'home') {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    },

    showToast(title, message, type = 'success') {
        if (window.Utils?.showToast) {
            window.Utils.showToast(title, message, type);
        } else {
            alert(`${title}: ${message}`);
        }
    }
};

// Iniciar aplicação
const startApp = () => {
    App.init().catch(err => {
        console.error('Falha ao iniciar app:', err);
    });
};

// Verificar se DOM já carregou
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startApp);
} else {
    startApp();
}

// Expor globalmente
window.App = App;
export default App;